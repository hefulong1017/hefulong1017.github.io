"""LaTeX-first interface over preserved solvers and V7/V8 research prototypes."""
from __future__ import annotations

from dataclasses import asdict
import importlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import threading

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import pandas as pd
import streamlit as st
import yaml

from interface_v5.app import numerical_app, _result_header
from research_v5 import solver as v5
from pde_frontend.bridge import compile_problem, names, parameter_values
from pde_frontend.analysis import inspect_problem
from pde_frontend.catalog import (
    dimension_template_families,
    get_dimension_template,
    get_template,
    list_templates,
)

PUBLIC_MODE = os.environ.get('PINNLAB_PUBLIC_MODE', '').strip() == '1'
PUBLIC_MAX_SECONDS = 20.0


@st.cache_resource
def _solver_gate():
    return threading.BoundedSemaphore(1)


def _limit_public_config(config):
    if not PUBLIC_MODE:
        return config
    requested_budget = float(getattr(config, 'budget_seconds', PUBLIC_MAX_SECONDS))
    config.budget_seconds = min(requested_budget if requested_budget > 0 else PUBLIC_MAX_SECONDS,
                                PUBLIC_MAX_SECONDS)
    for name, limit in (('iterations', 120), ('interior', 256), ('guard', 512),
                        ('condition_points', 128), ('max_features', 128),
                        ('max_births', 12), ('candidate_limit', 256),
                        ('adaptive_candidates', 128), ('curvature_candidates', 128),
                        ('delay_curvature_candidates', 64), ('threads', 1)):
        if hasattr(config, name):
            setattr(config, name, min(int(getattr(config, name)), limit))
    return config


def _run_solver(solver, *args):
    if not PUBLIC_MODE:
        return solver(*args)
    gate = _solver_gate()
    if not gate.acquire(blocking=False):
        raise RuntimeError('演示服务器正在计算另一个任务，请稍后重试。')
    try:
        return solver(*args)
    finally:
        gate.release()

_base_result_header = _result_header
_base_analyze = numerical_app.analyze


def _result_header(bundle):
    result = bundle['result']
    if result is None or not result.problem.get('delays'):
        return _base_result_header(bundle)
    st.subheader('2 · 求解前检查')
    numerical_app._show_analysis(bundle['analysis'])
    st.subheader('3 · 延迟方程数值候选')
    st.caption(f"当前输入：{result.problem['name']}；已配置 {len(result.problem['delays'])} 个延迟算子。")
    columns = st.columns(4)
    labels = {'iteration_limit': '达到迭代上限', 'inconclusive': '暂未找到可接受校正',
              'budget': '达到计算预算'}
    columns[0].metric('计算状态', labels.get(result.status, result.status))
    columns[1].metric('训练残差', f"{result.diagnostics['training_score']:.3e}")
    columns[2].metric('控制残差', f"{result.diagnostics['guard_score']:.3e}")
    columns[3].metric('求解耗时', f'{result.seconds:.2f} 秒')
    st.warning('这些数值是有限配点上的延迟残差，不是独立解误差审计，也不证明方程有解、收敛或唯一。')


def _analyze(problem):
    if problem.get('delays'):
        from pde_frontend.delay_spec import validate_delay_problem
        validate_delay_problem(problem)
        return {'incompatible': False, 'certificates': [], 'symmetries': [],
                'stability_warnings': [],
                'limitations': ['Delay input is experimental and requires independent validation.']}
    return _base_analyze(problem)


numerical_app.analyze = _analyze


if not hasattr(numerical_app, '_v6_original_model_json'):
    numerical_app._v6_original_model_json = numerical_app.model_json


def _read(path):
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except (FileNotFoundError, ValueError):
        return None


def _blank(value):
    return value is None or bool(pd.isna(value)) or not str(value).strip()


def _populate_template(template, status):
    st.session_state['latex_variables'] = ','.join(template['variables'])
    st.session_state['latex_fields'] = ','.join(template['fields'])
    equations = template['latex_equations']
    st.session_state['latex_equations'] = '\n'.join(equations) if isinstance(equations, list) else equations
    st.session_state['latex_domain_seed'] = template['domain']
    st.session_state['latex_condition_seed'] = template['conditions']
    st.session_state['latex_parameter_seed'] = template.get('parameters', {})
    st.session_state['latex_branch_seed'] = template.get('branches', [])
    st.session_state['latex_name'] = template['label']
    st.session_state['latex_template_status'] = status
    st.session_state['latex_editor_revision'] = st.session_state.get('latex_editor_revision', 0) + 1


def _apply_template():
    template = get_template(st.session_state['latex_template'])
    _populate_template(template, '编辑示例；精度结论只适用于原始冻结案例。')


def _apply_dimension_template():
    family = st.session_state['dimension_template_family']
    dimension = int(st.session_state['dimension_template_dimension'])
    variable_coefficients = bool(st.session_state['dimension_template_variable'])
    template = get_dimension_template(family, dimension, variable_coefficients=variable_coefficients)
    _populate_template(template, template['wellposedness_notes'])


def _ensure_template():
    if 'latex_equations' in st.session_state:
        return
    templates = list_templates()
    preferred = next((t['id'] for t in templates if t['id'] in ('heat', 'heat_1d')), templates[0]['id'])
    st.session_state['latex_template'] = preferred
    _apply_template()


def _latex_input():
    _ensure_template()
    templates = list_templates()
    labels = {t['id']: t['label'] for t in templates}
    left, right = st.columns([4, 1])
    left.selectbox('从模板开始，也可完全自行修改', list(labels), format_func=labels.get, key='latex_template')
    right.button('应用模板', on_click=_apply_template, key='apply_template', width='stretch')
    with st.expander('已通过方程族的 1D–3D 模板', expanded=False):
        st.caption('V6 通过的 19 个规范方程族提供扩维输入模板。扩维模板是结构示例，原维度的通过记录不会转移到新维度。Goursat 方程需要两个特征坐标，因此仅提供二维模板。')
        dimensional_families = dimension_template_families()
        family_labels = {item['id']: item['label'] for item in dimensional_families}
        dim_left, dim_middle, dim_right = st.columns([2, 1, 1])
        dim_left.selectbox('方程族', list(family_labels), format_func=family_labels.get,
                           key='dimension_template_family')
        dim_middle.selectbox('空间维数', [1, 2, 3], key='dimension_template_dimension')
        dim_right.checkbox('空间变系数', key='dimension_template_variable',
                           help='Black–Scholes 与变系数椭圆模板本身含坐标系数；其他模板可按此选项加入空间变系数。')
        selected_family = st.session_state.get('dimension_template_family', 'heat')
        selected_dimension = st.session_state.get('dimension_template_dimension', 1)
        st.button('载入维度模板', on_click=_apply_dimension_template,
                  disabled=(selected_family == 'goursat' and selected_dimension != 2),
                  key='apply_dimension_template', width='stretch')
    st.caption(st.session_state.get('latex_template_status', '模板提供输入起点；新维度与参数组合不自动继承精度验证。'))
    one, two = st.columns(2)
    variable_text = one.text_input('坐标（逗号分隔）', key='latex_variables', help='例如 x,t 或 x,y,z,t。t 作为时间，其他坐标用于梯度、散度与 Laplace 展开。')
    field_text = two.text_input('未知函数（逗号分隔）', key='latex_fields', help='例如 u，或 u,v,p。当前内核最多四个实值场。')
    with st.expander('从方程图片识别 LaTeX', expanded=False):
        ocr_available = importlib.util.find_spec('pix2tex') is not None
        image = st.file_uploader('上传清晰的方程截图', type=['png', 'jpg', 'jpeg', 'webp'],
                                 key=f'equation_image_{st.session_state.get("latex_editor_revision", 0)}')
        if image is not None:
            st.image(image, caption=image.name, width='stretch')
            st.caption('图片会发送到当前运行 PINNLab 的服务器进行识别；公开部署时请勿上传敏感图片。识别结果会填入下方方程框，仍需人工核对符号、上下标和分数。')
            if not ocr_available:
                st.caption('当前部署未安装图像识别组件；请直接粘贴 LaTeX 公式。')
            if st.button('识别并填入方程框', key='recognize_equation_image', disabled=not ocr_available):
                try:
                    from pde_frontend.image_ocr import recognize_equation_image
                    with st.spinner('正在加载公式识别模型并识别图片…'):
                        recognized = recognize_equation_image(image.getvalue())
                    st.session_state['latex_equations'] = recognized
                    st.rerun()
                except (RuntimeError, ValueError) as exc:
                    st.error(str(exc))
    text = st.text_area('偏微分方程（LaTeX，每行一条）', height=165, key='latex_equations',
                        help=r'可直接粘贴 u_t-\nu u_{xx}=0 或 \frac{\partial u}{\partial t}=\nu\Delta u；无需 JSON。')
    revision = st.session_state.get('latex_editor_revision', 0)
    try:
        variables, fields = names(variable_text), names(field_text)
        domain_seed = st.session_state['latex_domain_seed']
        domain_rows = [{'坐标': v, '下界': float(domain_seed.get(v, [0, 1])[0]),
                        '上界': float(domain_seed.get(v, [0, 1])[1])} for v in variables]
        with st.expander('求解域与参数', expanded=True):
            domain_frame = st.data_editor(pd.DataFrame(domain_rows), hide_index=True, disabled=['坐标'],
                                         key=f'latex_domain_{revision}_' + ''.join(variables), width='stretch')
            parameter_rows = [{'参数': str(k), '数值': float(v)} for k, v in st.session_state['latex_parameter_seed'].items()]
            parameter_frame = st.data_editor(pd.DataFrame(parameter_rows, columns=['参数', '数值']),
                                             num_rows='dynamic', hide_index=True, key=f'latex_parameters_{revision}', width='stretch',
                                             column_config={'参数': st.column_config.TextColumn('参数，例如 nu 或 \\nu'),
                                                            '数值': st.column_config.NumberColumn('数值', format='%.8g')})
        parameters = {}
        for row in parameter_frame.to_dict('records'):
            if _blank(row.get('参数')):
                if _blank(row.get('数值')):
                    continue
                raise ValueError('参数行已经填写数值，请同时填写参数名称。')
            if _blank(row.get('数值')):
                raise ValueError('参数 ' + str(row['参数']) + ' 需要填写有限数值。')
            if str(row['参数']) in parameters:
                raise ValueError('参数名称重复。')
            parameters[str(row['参数'])] = row['数值']
        parameters = parameter_values(parameters)
        condition_rows = []
        for condition in st.session_state['latex_condition_seed']:
            where = ','.join(f'{k}={float(v):.14g}' for k, v in condition['where'].items())
            condition_rows.append({'左侧（LaTeX）': condition['operator'], '右侧（LaTeX）': str(condition['target']),
                                   '位置': where, '类型': '周期配对' if condition.get('kind') == 'periodic' else '值/导数',
                                   '配对轴': condition.get('pair_axis', '')})
        st.write('**初始与边界条件**')
        st.caption(r'例如左侧 u、右侧 \sin(\pi x)、位置 t=0；导数条件可写 u_x 或 u_{xx}。周期配对位置填该轴下界，右侧是两侧之差。')
        condition_frame = st.data_editor(pd.DataFrame(condition_rows), hide_index=True, num_rows='dynamic',
                                         key=f'latex_conditions_{revision}', width='stretch',
                                         column_config={'类型': st.column_config.SelectboxColumn('类型', options=['值/导数', '周期配对']),
                                                        '配对轴': st.column_config.TextColumn('配对轴（周期条件）')})
        conditions = []
        for row in condition_frame.to_dict('records'):
            if _blank(row.get('左侧（LaTeX）')):
                if all(_blank(row.get(key)) for key in ('右侧（LaTeX）', '位置', '配对轴')) and row.get('类型') != '周期配对':
                    continue
                raise ValueError('条件行已填写值或位置，请同时填写左侧算子。')
            target = row.get('右侧（LaTeX）', '0')
            conditions.append({'operator': str(row['左侧（LaTeX）']), 'target': '0' if pd.isna(target) else str(target),
                               'where': row.get('位置', ''),
                               'kind': 'periodic' if row.get('类型') == '周期配对' else 'value',
                               'pair_axis': '' if pd.isna(row.get('配对轴')) else str(row.get('配对轴', ''))})
        branch_rows = [{'算子（LaTeX）': b['operator'], '界限类型': '下界' if 'min' in b else '上界',
                        '数值': float(b.get('min', b.get('max')))} for b in st.session_state.get('latex_branch_seed', [])]
        with st.expander('分支约束（可选；如凸性、导数符号）', expanded=bool(branch_rows)):
            st.caption('log、sqrt 和除法需要有效实分支；算子展开不证明光滑性。请给出物理需要的符号、凸性等约束。')
            branch_frame = st.data_editor(pd.DataFrame(branch_rows, columns=['算子（LaTeX）', '界限类型', '数值']),
                                          hide_index=True, num_rows='dynamic', key=f'latex_branches_{revision}', width='stretch',
                                          column_config={'界限类型': st.column_config.SelectboxColumn('界限类型', options=['下界', '上界']),
                                                         '数值': st.column_config.NumberColumn('数值')})
        branches = []
        for row in branch_frame.to_dict('records'):
            if _blank(row.get('算子（LaTeX）')):
                if _blank(row.get('数值')) and _blank(row.get('界限类型')):
                    continue
                raise ValueError('分支行已填写界限，请同时填写约束算子。')
            if row.get('界限类型') not in ('下界', '上界'):
                raise ValueError('分支约束请选择下界或上界。')
            branches.append({'operator': str(row['算子（LaTeX）']),
                             'min' if row['界限类型'] == '下界' else 'max': row.get('数值')})

        delay_columns = ['符号', '类型', '未知函数', '延迟或下限', '上限', '核函数 K(x,t,s)', '积分阶数']
        with st.expander('延迟算子（可选）', expanded=False):
            st.caption('方程中用 d1 引用点时滞，用 m1 引用分布时滞。函数表达式使用 sin(pi*x)、exp(-lambda*s) 这类安全语法；时滞函数与核须为已知量。')
            delay_frame = st.data_editor(pd.DataFrame(columns=delay_columns), num_rows='dynamic',
                                         hide_index=True, key=f'delay_specs_{revision}', width='stretch',
                                         column_config={
                                             '类型': st.column_config.SelectboxColumn('类型', options=['点时滞', '分布时滞']),
                                             '未知函数': st.column_config.SelectboxColumn('未知函数', options=fields),
                                             '积分阶数': st.column_config.NumberColumn('积分阶数', min_value=4, max_value=64, step=4, default=16),
                                         })
            history_frame = st.data_editor(
                pd.DataFrame([{'未知函数': field, '历史函数（t≤起始时刻）': ''} for field in fields]),
                hide_index=True, disabled=['未知函数'], key=f'delay_history_{revision}', width='stretch',
                column_config={'未知函数': st.column_config.SelectboxColumn('未知函数', options=fields)})
        delay_specs, history = [], {}
        for row in delay_frame.to_dict('records'):
            values = [row.get(column) for column in delay_columns]
            if all(_blank(value) for value in values):
                continue
            symbol = row.get('符号')
            kind = row.get('类型')
            field = row.get('未知函数')
            if _blank(symbol) or _blank(kind) or _blank(field):
                raise ValueError('每条延迟项都需要填写符号、类型和未知函数。')
            if kind == '点时滞':
                delay_specs.append({'symbol': str(symbol).strip(), 'kind': 'point', 'field': str(field),
                                    'delay': str(row.get('延迟或下限', '')).strip()})
            else:
                delay_specs.append({'symbol': str(symbol).strip(), 'kind': 'distributed', 'field': str(field),
                                    'lower': str(row.get('延迟或下限', '')).strip(),
                                    'upper': str(row.get('上限', '')).strip(),
                                    'kernel': str(row.get('核函数 K(x,t,s)', '')).strip(),
                                    'quadrature': 16 if _blank(row.get('积分阶数')) else int(row['积分阶数'])})
        for row in history_frame.to_dict('records'):
            expression = row.get('历史函数（t≤起始时刻）')
            if not _blank(expression):
                history[str(row['未知函数'])] = str(expression).strip()
        domain = {str(row['坐标']): [row['下界'], row['上界']] for row in domain_frame.to_dict('records')}
        problem = compile_problem(equations=text, variables=variables, fields=fields, domain=domain,
                                  parameters=parameters, conditions=conditions,
                                  branches=branches,
                                  delays=delay_specs, history=history,
                                  name=st.session_state.get('latex_name', 'LaTeX 自定义方程'))
        st.success(f"已识别 {len(problem['equations'])} 条方程、{len(fields)} 个未知函数、{len(conditions)} 条条件和 {len(problem.get('delays', []))} 个延迟算子。")
        with st.expander('公式预览与识别结果', expanded=True):
            for line in text.splitlines():
                if line.strip():
                    st.latex(line.strip())
            st.caption('求解将采用以下已展开表达式。请核对导数、正负号及初边值位置。')
            for expression in problem['equations']:
                st.code(expression + ' = 0', language=None)
            st.json({'variables': variables, 'fields': fields, 'domain': problem['domain'],
                     'conditions': problem['conditions'], 'branches': problem['branches'],
                     'parameters': parameters, 'delays': problem.get('delays', []),
                     'history': problem.get('history', {})}, expanded=False)
            st.download_button('下载识别后的方程输入', json.dumps(problem, ensure_ascii=False, indent=2, allow_nan=False),
                               file_name='problem.json', mime='application/json', key='download_compiled_latex')
        return problem
    except (ValueError, TypeError, KeyError, SyntaxError, ArithmeticError) as exc:
        st.error(f'公式或条件需要修改：{exc}')
        st.caption('支持常见局部偏导、混合导数、梯度、散度和 Laplace；延迟项需在“延迟算子”中定义符号、时滞函数、历史函数和积分核。')
        return None


def _input_panel():
    mode = st.radio('输入方式', ['LaTeX 公式', '已验证案例', 'JSON / YAML'], horizontal=True, key='v6_input_mode')
    if mode == 'LaTeX 公式':
        return _latex_input()
    if mode == '已验证案例':
        labels = numerical_app.CASE_LABELS
        identifier = st.selectbox('研究案例', list(labels), format_func=labels.get,
                                  index=list(labels).index('challenges/heat_high_frequency'), key='case_id')
        st.caption('这里保留 V5 已审计目录及挑战；具体案例是否通过，以独立审计记录为准。')
        return numerical_app.make_problem(identifier)
    text = st.text_area('物理输入配置', json.dumps(numerical_app.make_problem('challenges/heat_high_frequency'), ensure_ascii=False, indent=2),
                        height=340, key='custom_input')
    try:
        raw = yaml.safe_load(text)
        if isinstance(raw, dict) and raw.get('delays'):
            from pde_frontend.delay_spec import validate_delay_problem
            return validate_delay_problem(raw)
        return numerical_app.parse_problem(text)
    except Exception as exc:
        st.error(f'配置需要修改：{exc}')
        return None


def _algorithm_panel():
    st.subheader('从小残差到有效修正')
    st.write('页面同时保留已冻结的 V5、V6 证据，并加入 V7 曲率闭合自适应校正原型。V7 先测量非线性残差的二阶 secant 余项，再从当前特征代数中构造混合方向，并在每一步重新校正。')
    st.write('V8 延迟原型对点时滞和分布时滞在训练、控制点上直接计算历史依赖残差，并按该残差的二阶 secant 闭合乘积特征。当前只支持已知的时空延迟函数与核函数。')
    st.latex(r'u_a(x)=\sum_j c_{aj}\phi_j(x),\qquad \delta c=-T\,(W_r^{1/2}JT)^\dagger W_r^{1/2}r')
    st.latex(r'e=r+J\delta c,\qquad B_{\perp}=(I-AA^\dagger)B,\qquad q_\alpha=\frac{R(c+\alpha d)-R(c)-\alpha J(c)d}{\alpha^2},\qquad \phi_{ij}=\phi_i\phi_j')
    st.latex(r'\rho=\min_{s\in\{\mathrm{train},\mathrm{control}\}}\frac{\text{实际非线性残差降幅}_s}{\text{线性预测降幅}_s},\qquad \mathcal S(\phi_{ij})=\frac{|\langle (I-QQ^\top)J\phi_{ij},(I-QQ^\top)q\rangle|}{\|(I-QQ^\top)J\phi_{ij}\|}+\beta\,\frac{|\langle (I-QQ^\top)J\phi_{ij},(I-QQ^\top)r\rangle|}{\|(I-QQ^\top)J\phi_{ij}\|}')
    st.caption('A 是当前可行切空间的残差雅可比，B 是候选响应；投影去掉已有方向。control 点参与适配，独立精度检查必须另用新点。')
    steps = [
        ('结构提案', '从方程、源项和条件提取频率与衰减尺度。', 'V5 已实现并有部分消融证据。'),
        ('缺陷定位', '用当前修正后的剩余残差与采样组之间的分歧定位欠分辨区域。', 'V6 实验机制；须看本轮实际日志。'),
        ('候选筛选', '优先测试当前雅可比空间之外、在接纳点也能带来收益的响应。', '预测指标只用于筛选，不能替代实际验收。'),
        ('非线性验收', '比较实际与预测降幅，决定接纳、收缩尺度或保留未决。', '不依赖参考解挑选候选。'),
        ('V7 曲率闭合', '沿当前系数的 secant 测量残差曲率，优先补充现有特征的乘积和混合 jet 方向。', '新研究原型；目前只有小规模对照，不能继承 V6 的正式通过率。'),
        ('V7 曲率校正', '按函数范数测量残差曲率，闭合乘积特征，再用回溯 Gauss–Newton 同时检查训练组、控制组和分支。', '研究原型；局部模型，不是全局 Hessian 或误差定理。'),
        ('V8 延迟曲率闭合', '在真实历史依赖残差上估计二阶 secant，按延迟响应增广乘积特征，并用训练组和控制组回溯验收。', '新研究原型；目前不支持依赖未知解的时滞函数，尚无独立参考误差审计。'),
    ]
    st.dataframe(pd.DataFrame(steps, columns=['环节', '作用', '证据与边界']), hide_index=True, width='stretch')
    st.info('V7 的可检验贡献假设是“残差曲率驱动的特征代数闭合”能够补上完全非线性方程的混合方向。secant、乘积特征和自适应采样均有先例，不能保证全球首创。')
    st.write('**兼容调度**：新路径未通过自身检查且仍有预算时，才重试保留的 V5 路径；只在重试通过自身物理停止门时采用它。两次候选和失败原因都保留，这属于能力保留措施，不单独算作新算法创新。')
    routed = _read(PROJECT_ROOT/'pinn_engine/validation/compatibility/results_final.json')
    if routed:
        st.write('**可选兼容调度的独立审计记录**')
        st.json(routed.get('summary', routed), expanded=False)
        st.caption('该证据是固定主模型的历史重放与新点审计；时间为原主模型耗时加新重试耗时，不是同时重新计时的速度比较。')
        st.caption('本轮 12 秒配置未增加通过案例，部分失败输入花费更多时间；兼容调度保留为可选项，默认使用纯 V6。')
    evidence = _read(PROJECT_ROOT/'research_v6/validation/formal/results_final.json')
    if evidence:
        st.write('**V6 本轮独立审计记录**')
        st.json(evidence.get('summary', evidence), expanded=False)
    else:
        st.caption('V6 的最终证据尚未载入。下面的 V5 结果不能视作新算法的覆盖证明。')
    v5_final = _read(PROJECT_ROOT/'research_v5/validation/results_final.json')
    if v5_final:
        summary = v5_final['summary']['catalog']
        st.metric('V5 指定案例验证通过的方程族', f"{summary['passed_families']} / {summary['canonical_families']}")
        st.caption('来源为冻结 V5 模型的 8,192 新点审计。V6 修改需要单独验证，不自动继承这个计数。')


def _coverage_panel(problem):
    st.subheader('按数学结构扩展')
    st.write('统一编译局部有限阶方程，避免为每个方程名称单独编写输入逻辑。可识别表达式、可送入当前内核、已有精度证据是三个不同层次。')
    rows = [
        ['局部有限阶 PDE', '标量或 1–4 场耦合；线性、拟线性、完全非线性', '表达式符合限制时可提交数值内核；不保证收敛。'],
        ['时空与导数', 'x/y/z/t 中 1–4 坐标；混合导数最高六阶', '梯度、散度、Laplace 会展开为一致偏导。'],
        ['初边值', '值、导数、Robin 组合与周期配对', '需要完整给定位置、求解域和参数。'],
        ['向量与复数', '向量系统按分量；复数可手动拆为实部／虚部', '当前没有自动复数拆分器；最多四个实值场。'],
        ['已知点延迟与分布延迟', 'V8 结构化 d1/m1 通道；显式历史、变量滞后与核函数', '研究原型；未知解依赖延迟、延迟导数未支持，误差尚无独立审计。'],
        ['分数阶与其他积分/非局部', '需要专门算子、历史记忆及积分策略', '当前明确拒绝；不是添加模板即可求解。'],
        ['激波、熵解、复杂几何', '需要弱形式、熵条件、网格／几何与额外验证', '当前强形式盒域内核未普遍解决。'],
    ]
    st.dataframe(pd.DataFrame(rows, columns=['结构', '可表达范围', '实际边界']), hide_index=True, width='stretch')
    if problem:
        if problem.get('delays'):
            st.write('**当前延迟输入的检查**')
            st.json({'delay_operators': problem['delays'], 'history_fields': list(problem['history']),
                     'state_dependent_delay': 'unsupported'}, expanded=True)
        else:
            analysis = inspect_problem(problem)
            st.write('**当前输入的结构检查**')
            st.json(analysis, expanded=True)
    st.caption('模板数和表达式种类不计作数值解通过率。“几乎所有方程”是扩展方向，不能作为当前版本的精度保证。')


def _model_json(result):
    if hasattr(result, 'to_dict'):
        return json.dumps(result.to_dict(), ensure_ascii=False, indent=2, allow_nan=False)
    return numerical_app._v6_original_model_json(result)


def _v6_settings(module):
    with st.sidebar:
        st.header('求解设置')
        budget_limit = int(PUBLIC_MAX_SECONDS) if PUBLIC_MODE else 60
        iteration_limit = 120 if PUBLIC_MODE else 300
        budget = st.number_input('计算预算（秒）', min_value=1, max_value=budget_limit, value=12, key='v6_budget_seconds')
        iterations = st.number_input('最多迭代次数', min_value=1, max_value=iteration_limit,
                                     value=min(100, iteration_limit), key='v6_iterations')
        tolerance = st.selectbox('采样残差目标', [1e-4, 1e-6, 1e-8], index=1,
                                 format_func=lambda value: f'{value:.0e}', key='v6_tolerance')
        with st.expander('研究设置'):
            interior_options = [32, 64, 128, 256] if PUBLIC_MODE else [32, 64, 128, 256, 512]
            guard_options = [32, 64, 128, 256, 512] if PUBLIC_MODE else [32, 64, 128, 256, 512, 1024]
            features_limit = 128 if PUBLIC_MODE else 192
            batch_limit = 8 if PUBLIC_MODE else 12
            interior = st.select_slider('内部训练点', interior_options, value=128, key='v6_interior')
            guard = st.select_slider('适配控制点', guard_options, value=256, key='v6_guard')
            features = st.slider('函数数量上限', 32, features_limit, min(112, features_limit), step=8, key='v6_max_features')
            batch = st.slider('每次增广函数数', 1, batch_limit, min(6, batch_limit), key='v6_birth_batch')
            informed = st.checkbox('提取方程结构尺度', value=True, key='v6_informed')
            adaptive = st.checkbox('启用缺陷驱动增广', value=True, key='v6_adaptive_birth')
            stability = st.checkbox('检查函数修正量后再停止', value=True, key='v6_stability_control')
            correction = st.selectbox('函数修正目标', [1e-4, 1e-6, 1e-8], index=1, key='v6_value_tolerance')
            seed = st.number_input('随机种子', min_value=0, max_value=2147483647, value=42, key='v6_seed')
        st.caption('控制点用于特征筛选和修正，不能充当最终精度证据。时间为软预算，单步运算可能超时。')
        if PUBLIC_MODE:
            st.caption('公开演示采用单任务计算；单次计算软预算最多 20 秒。')
    return module.SolverConfig(budget_seconds=float(budget), iterations=int(iterations), tolerance=tolerance,
                               interior=interior, guard=guard, max_features=features, birth_batch=batch,
                               informed_features=informed, adaptive_birth=adaptive,
                               stability_control=stability, value_tolerance=correction, seed=int(seed))


def main():
    st.set_page_config(page_title='PINNLab · LaTeX 与自适应算法', page_icon='∂', layout='wide')
    st.title('PINNLab · LaTeX 方程与自适应求解')
    st.write('直接输入数学公式，核对识别结果，再计算点值、导数与曲线／曲面。')
    try:
        v6 = importlib.import_module('research_v6.solver')
    except ImportError:
        v6 = None
    try:
        dispatch = importlib.import_module('pinn_engine.dispatch')
    except ImportError:
        dispatch = None
    try:
        v7 = importlib.import_module('research_v7.solver')
    except ImportError:
        v7 = None
    try:
        v8 = importlib.import_module('research_v8.solver')
    except ImportError:
        v8 = None
    numerical_app.STATUS_TEXT.update({'inconclusive': '当前搜索未找到可接受方向',
                                      'budget': '达到计算时间预算',
                                      'iteration_limit': '达到迭代上限'})
    numerical_app.ACTION_TEXT.update({'delay_joint_correction': '延迟残差联合校正',
                                      'delay_curvature_closure': '延迟曲率闭合增广',
                                      'no_accepted_delay_correction': '暂无可接受延迟校正'})
    with st.sidebar:
        choices = []
        if v6:
            choices.append('V6 · 缺陷驱动自适应（实验）')
        if v7:
            choices.append('V7 · 曲率闭合自适应校正（新研究原型）')
        if v8:
            choices.append('V8 · 延迟曲率闭合（新研究原型）')
        choices.append('V5 · 冻结算法')
        if dispatch:
            choices.append('自适应求解 · 保留兼容路径')
        algorithm = st.selectbox('数值算法', choices, key='v6_algorithm')
    active = (v8 if v8 and algorithm.startswith('V8') else
              v7 if v7 and algorithm.startswith('V7') else
              dispatch if dispatch and algorithm.startswith('自适应') else
              v6 if v6 and algorithm.startswith('V6') else v5)
    numerical_app.SolverConfig = active.SolverConfig
    config = _v6_settings(active) if active is not v5 else numerical_app._settings()

    def run_problem(problem, config, callback=None):
        if problem.get('delays'):
            if v8 is None:
                raise RuntimeError('延迟方程求解模块未加载。')
            physical = v8.validate_delay_problem(problem)
            analysis = {'incompatible': False, 'certificates': [], 'symmetries': [],
                        'stability_warnings': [],
                        'limitations': ['V8 delay equations are experimental; final independent error checks are required.']}
            result = _run_solver(v8.solve, physical, _limit_public_config(config), callback)
            return {'analysis': analysis, 'result': result, 'problem': physical,
                    'algorithm': 'V8 · 延迟曲率闭合（新研究原型）'}
        physical = v5.physical_input(problem)
        analysis = v5.analyze(physical)
        result = None if analysis['incompatible'] else _run_solver(
            active.solve, physical, _limit_public_config(config), callback)
        return {'analysis': analysis, 'result': result, 'problem': physical, 'algorithm': algorithm}

    numerical_app.run_problem = run_problem
    numerical_app.model_json = _model_json
    solve_tab, method_tab, scope_tab = st.tabs(['公式与数值解', '算法与创新证据', '结构覆盖与边界'])
    with solve_tab:
        problem = _input_panel()
        if problem:
            if problem.get('delays'):
                st.info('检测到延迟算子，将调用 V8 延迟求解器；本轮结果需再做独立参考解验证。')
            else:
                inspection = inspect_problem(problem)
                if not inspection.get('admission', {}).get('eligible', True):
                    st.error('当前输入超出数值内核准入范围。请查看“结构覆盖与边界”。')
                    problem = None
        numerical_app._run_controls(problem, config)
        if 'v5_check' in st.session_state:
            st.subheader('本次输入检查')
            numerical_app._show_analysis(st.session_state['v5_check'])
        bundle = st.session_state.get('v5_bundle')
        if bundle:
            st.caption('最近一次计算采用：' + bundle.get('algorithm', 'V5'))
            if 'v5_check' not in st.session_state:
                _result_header(bundle)
            result = bundle['result']
            if result is not None:
                if hasattr(result, 'routing'):
                    st.caption('本次数值候选来自：' + ('V5 兼容重试' if result.chosen == 'retry' else 'V6 主路径') + '。原始路径记录可在求解统计和下载模型中查看。')
                sign = numerical_app._branch_choice(result, bundle['analysis'])
                tabs = st.tabs(['曲线 / 曲面', '逐点 / 批量数值', '求解记录 / 下载'])
                with tabs[0]: numerical_app._plot_panel(result, sign)
                with tabs[1]: numerical_app._query_panel(result, sign)
                with tabs[2]: numerical_app._history_panel(result)
        else:
            st.info('完成公式、求解域和初边值输入后，可以先检查条件，再开始求解。')
    with method_tab:
        _algorithm_panel()
    with scope_tab:
        _coverage_panel(problem)


if __name__ == '__main__':
    main()
