"""Safe mathematical input adapters; frozen numerical solvers remain unchanged."""
from .latex import (
    LatexParseError,
    SYMBOL_ALIASES,
    normalize_symbol,
    parse_equation,
    parse_equations,
    parse_expression,
)
from .catalog import dimension_template_families, get_dimension_template

__all__ = [
    "LatexParseError", "SYMBOL_ALIASES", "normalize_symbol",
    "parse_expression", "parse_equation", "parse_equations",
    "dimension_template_families", "get_dimension_template",
]
