"""Compile editable mathematical inputs into the frozen physical schema.

The boundary location is explicit: a displayed trace is never silently
extended into the interior. No reference or evaluation field crosses this
boundary into the solver.
"""
from __future__ import annotations

import math
from typing import Mapping
import numpy as np

from .latex import normalize_symbol, parse_equations, parse_expression
from research_v4.spec import Formula, validate_problem
from research_v5.solver import physical_input


def names(text_or_names):
    if isinstance(text_or_names, str):
        values = text_or_names.replace('，', ',').replace(';', ',').split(',')
    else:
        values = list(text_or_names)
    result = [normalize_symbol(str(value).strip()) for value in values if str(value).strip()]
    if not result or len(result) != len(set(result)):
        raise ValueError('坐标或未知函数不能为空，也不能重复。')
    return result


def parameter_values(parameters):
    result = {}
    for raw_name, raw_value in (parameters or {}).items():
        name = normalize_symbol(str(raw_name).strip())
        if name in result:
            raise ValueError('两个参数在规范化后使用了同一名称：' + name)
        if isinstance(raw_value, bool):
            raise ValueError('参数需要有限实数。')
        value = float(raw_value)
        if not math.isfinite(value):
            raise ValueError('参数需要有限实数。')
        result[name] = value
    return result


def scalar_value(source, parameters=None):
    """Evaluate a finite scalar through the same restricted expression API."""
    if isinstance(source, bool):
        raise ValueError('位置需要有限实数。')
    if isinstance(source, (int, float, np.number)):
        value = float(source)
    else:
        parameters = parameter_values(parameters)
        expression = parse_expression(str(source), [], [], parameters)
        formula = Formula(expression, [], [], parameters, allow_fields=False)
        with np.errstate(over='raise', divide='raise', invalid='raise'):
            output = np.asarray(formula(np.empty((1, 0)), {}), dtype=float)
        if output.size != 1:
            raise ValueError('位置必须是标量。')
        value = float(output.reshape(-1)[0])
    if not math.isfinite(value):
        raise ValueError('位置需要有限实数。')
    return value


def parse_location(source, variables, parameters=None):
    if isinstance(source, Mapping):
        pairs = list(source.items())
    else:
        raw = str(source).strip().replace('，', ',').replace(';', ',')
        if not raw:
            raise ValueError('请在位置栏填写边界或初始位置，例如 x=0 或 t=0。')
        pairs = []
        for part in raw.split(','):
            if part.count('=') != 1:
                raise ValueError('位置格式应为 x=0 或 x=1,t=0。')
            pairs.append(tuple(piece.strip() for piece in part.split('=', 1)))
    result = {}
    for raw_name, raw_value in pairs:
        name = normalize_symbol(str(raw_name).strip())
        if name not in variables or name in result:
            raise ValueError('位置包含未知或重复坐标：' + name)
        result[name] = scalar_value(raw_value, parameters)
    if not result:
        raise ValueError('每条初边值条件都需要明确位置。')
    return result


def compile_problem(*, equations, variables, fields, domain, conditions,
                    parameters=None, branches=None, delays=None, history=None,
                    name='LaTeX 自定义方程'):
    variables, fields = names(variables), names(fields)
    parameters = parameter_values(parameters)
    if not 1 <= len(variables) <= 4 or any(v not in ('x', 'y', 'z', 't') for v in variables):
        raise ValueError('当前内核支持 x、y、z、t 中的 1–4 个坐标。')
    if not 1 <= len(fields) <= 4:
        raise ValueError('当前内核支持 1–4 个未知函数；复数方程可先拆为实部和虚部。')
    spatial = [v for v in variables if v != 't']
    bounds = {}
    for variable in variables:
        if variable not in domain or len(domain[variable]) != 2:
            raise ValueError('请给出每个坐标的上下界。')
        bounds[variable] = [scalar_value(v, parameters) for v in domain[variable]]
    delay_specs = list(delays or [])
    delay_symbols = []
    for delay in delay_specs:
        if not isinstance(delay, Mapping):
            raise ValueError('延迟项需要使用结构化参数。')
        delay_symbols.append(normalize_symbol(str(delay.get('symbol', '')).strip()))
    if len(delay_symbols) != len(set(delay_symbols)):
        raise ValueError('延迟算子符号不能重复。')
    residuals = parse_equations(equations, variables, fields + delay_symbols, parameters, spatial)
    if not 1 <= len(residuals) <= 16:
        raise ValueError('当前内核支持 1–16 条耦合方程。')
    if not isinstance(conditions, (list, tuple)) or not 1 <= len(conditions) <= 64:
        raise ValueError('请提供 1–64 条初始、边界或周期配对条件。')
    compiled_conditions = []
    for index, row in enumerate(conditions):
        if not isinstance(row, Mapping):
            raise ValueError('条件需要包含左侧算子、右侧值及位置。')
        operator = parse_expression(str(row.get('operator', '')).strip(), variables, fields, parameters, spatial)
        target = parse_expression(str(row.get('target', '0')).strip(), variables, [], parameters, spatial)
        condition = {'name': str(row.get('name') or f'condition_{index + 1}'),
                     'operator': operator, 'target': target,
                     'where': parse_location(row.get('where', ''), variables, parameters)}
        if row.get('kind') == 'periodic':
            pair_axis = normalize_symbol(str(row.get('pair_axis', '')).strip())
            if pair_axis not in variables:
                raise ValueError('周期配对需要指定有效坐标轴。')
            condition.update(kind='periodic', pair_axis=pair_axis)
        elif row.get('kind') not in (None, '', 'value', '值/导数'):
            raise ValueError('未知条件类型，请选择值/导数或周期配对。')
        compiled_conditions.append(condition)
    compiled_branches = []
    for branch in branches or []:
        if not isinstance(branch, Mapping) or ('min' in branch) == ('max' in branch):
            raise ValueError('每条分支约束需要一个下界或上界。')
        kind = 'min' if 'min' in branch else 'max'
        compiled_branches.append({'operator': parse_expression(str(branch.get('operator', '')), variables, fields, parameters, spatial),
                                  kind: scalar_value(branch[kind], parameters)})
    specification = {'name': str(name), 'variables': variables, 'fields': fields,
                     'domain': bounds, 'parameters': parameters, 'equations': residuals,
                     'conditions': compiled_conditions, 'branches': compiled_branches}
    if delay_specs:
        from .delay_spec import validate_delay_problem
        compiled_history = {str(field): parse_expression(str(expression), variables, [], parameters, spatial)
                           for field, expression in (history or {}).items()}
        specification['delays'] = delay_specs
        specification['history'] = compiled_history
        return validate_delay_problem(specification)
    if history:
        raise ValueError('历史函数必须与至少一个延迟算子一起提供。')
    # Existing validation rejects unknown symbols, invalid powers, conditions,
    # and branch syntax. The V5 physical boundary additionally checks pairing.
    return physical_input(validate_problem(specification))
