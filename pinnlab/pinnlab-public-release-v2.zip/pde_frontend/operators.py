"""Bounded total derivatives of the already validated scalar AST.

No string evaluator, Python execution, or unrestricted symbolic parser is used.
Jets represent classical commuting partial derivatives. Their order is limited
to six, matching research_v4.spec.Formula. Differentiation is local and assumes
the original expression is defined and differentiable on the requested branch.
"""
from __future__ import annotations

import ast
import math
from dataclasses import dataclass, field as dataclass_field


MAX_NODES = 400
MAX_DERIVATIVE_ORDER = 6
FUNCTIONS = frozenset(("sin", "cos", "exp", "tanh", "sqrt", "log", "abs"))


class OperatorError(ValueError):
    """A bounded scalar differential operator cannot be represented safely."""


@dataclass(frozen=True)
class Context:
    variables: tuple[str, ...]
    fields: tuple[str, ...]
    parameters: tuple[str, ...] = ()
    spatial_variables: tuple[str, ...] = ()
    # All parser/subparser instances in one compile share this registry. The
    # guards survive even when a derivative later simplifies a subtree to zero.
    domain_guards: dict[str, ast.expr] = dataclass_field(default_factory=dict, compare=False, repr=False)


@dataclass(frozen=True)
class Vector:
    """Internal gradient/vector value; never emitted as a scalar Formula."""

    components: tuple[ast.expr, ...]


def number(value):
    if type(value) not in (int, float) or not math.isfinite(value):
        raise OperatorError("数值常量必须有限。")
    return ast.Constant(value=value)


def name(value):
    return ast.Name(id=value, ctx=ast.Load())


def call(function, argument):
    return ast.Call(func=name(function), args=[argument], keywords=[])


def _value(node):
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.USub, ast.UAdd)):
        value = _value(node.operand)
        if value is not None:
            return -value if isinstance(node.op, ast.USub) else value
    return None


def constant_value(node):
    """Evaluate arithmetic of numeric literals only, within fixed small limits."""
    value = _value(node)
    if value is not None:
        return value
    if not isinstance(node, ast.BinOp):
        raise OperatorError("幂指数必须是数值常量，不能包含变量或参数。")
    a, b = constant_value(node.left), constant_value(node.right)
    try:
        if isinstance(node.op, ast.Add):
            value = a + b
        elif isinstance(node.op, ast.Sub):
            value = a - b
        elif isinstance(node.op, ast.Mult):
            value = a * b
        elif isinstance(node.op, ast.Div):
            value = a / b
        elif isinstance(node.op, ast.Pow):
            if abs(b) > 16:
                raise OperatorError("幂指数的绝对值不能超过 16。")
            value = a ** b
        else:
            raise OperatorError("不支持这种常数运算。")
    except (ArithmeticError, OverflowError) as exc:
        raise OperatorError("常数运算越界或除以零。") from exc
    if type(value) not in (int, float) or not math.isfinite(value) or abs(value) > 1e100:
        raise OperatorError("常数运算越界或不是有限实数。")
    return value


def bounded(node, max_nodes=MAX_NODES):
    """Prevent derivative expansion from exceeding the downstream AST budget."""
    count = 0
    for _ in ast.walk(node):
        count += 1
        if count > max_nodes:
            raise OperatorError("表达式展开超过 400 个 AST 节点；请拆分方程或减少嵌套微分。")
    return node


def scalar(value):
    if isinstance(value, Vector):
        raise OperatorError("梯度是向量；请使用散度、显式点积或逐分量输入标量方程。")
    return value


def _binary(op, left, right, simplify=False):
    if simplify:
        a, b = _value(left), _value(right)
        if isinstance(op, ast.Add):
            if a == 0:
                return right
            if b == 0:
                return left
        elif isinstance(op, ast.Sub):
            if b == 0:
                return left
            if a == 0:
                return ast.UnaryOp(op=ast.USub(), operand=right)
        elif isinstance(op, ast.Mult):
            if a == 0 or b == 0:
                return number(0)
            if a == 1:
                return right
            if b == 1:
                return left
        elif isinstance(op, ast.Div):
            if a == 0:
                return number(0)
            if b == 1:
                return left
    return bounded(ast.BinOp(left=left, op=op, right=right))


def binary(op, left, right, dot=False):
    """Typed scalar/vector arithmetic for divergence and explicit dot products."""
    lv, rv = isinstance(left, Vector), isinstance(right, Vector)
    if not (lv or rv):
        return _binary(op, left, right)
    if isinstance(op, (ast.Add, ast.Sub)):
        if not (lv and rv) or len(left.components) != len(right.components):
            raise OperatorError("向量加减两侧必须具有相同分量数，不能与标量相加。")
        return Vector(tuple(_binary(op, a, b) for a, b in zip(left.components, right.components)))
    if isinstance(op, ast.Mult):
        if lv and rv:
            if not dot or len(left.components) != len(right.components):
                raise OperatorError("两个向量不能隐式相乘；请使用 \\cdot 点积。")
            result = number(0)
            for a, b in zip(left.components, right.components):
                result = _binary(ast.Add(), result, _binary(ast.Mult(), a, b), True)
            return result
        vector, factor = (left, right) if lv else (right, left)
        return Vector(tuple(_binary(ast.Mult(), factor, a) for a in vector.components))
    if isinstance(op, ast.Div) and lv and not rv:
        return Vector(tuple(_binary(ast.Div(), a, right) for a in left.components))
    raise OperatorError("不支持向量除数或向量幂；请展开为标量分量。")


def negate(value):
    if isinstance(value, Vector):
        return Vector(tuple(ast.UnaryOp(op=ast.USub(), operand=a) for a in value.components))
    return ast.UnaryOp(op=ast.USub(), operand=value)


def canonical_jet(symbol, context):
    head, separator, suffix = symbol.partition("_")
    if head not in context.fields:
        raise OperatorError("未知场符号：" + head)
    if separator:
        if not suffix or any(v not in context.variables for v in suffix):
            raise OperatorError("导数下标只能使用已声明的坐标。")
        if len(suffix) > MAX_DERIVATIVE_ORDER:
            raise OperatorError("物理导数阶数不能超过 6。")
        suffix = "".join(v * suffix.count(v) for v in context.variables)
    return head + ("_" + suffix if suffix else "")


def capture_domains(node, context):
    """Retain finite real-domain checks before algebra can erase their source.

    No epsilon or branch inequality is invented. log keeps its strict positive
    real domain; sqrt keeps its real domain and numerical derivative checks;
    inverse denominators keep the original nonzero requirement. Guards also
    retain noninteger/negative powers and finite exp evaluation.
    """
    scalar(node)
    for current in ast.walk(node):
        guard = None
        if (isinstance(current, ast.Call) and isinstance(current.func, ast.Name)
                and current.func.id in ("log", "sqrt", "exp")):
            guard = current
        elif isinstance(current, ast.BinOp) and isinstance(current.op, ast.Div):
            guard = ast.BinOp(left=number(1), op=ast.Div(), right=current.right)
        elif isinstance(current, ast.BinOp) and isinstance(current.op, ast.Pow):
            exponent = constant_value(current.right)
            if exponent < 0 or not float(exponent).is_integer():
                guard = current
        if guard is not None:
            key = ast.dump(guard, include_attributes=False)
            if key not in context.domain_guards:
                context.domain_guards[key] = guard
                cost = sum(5 + sum(1 for _ in ast.walk(value))
                           for value in context.domain_guards.values())
                if cost > MAX_NODES:
                    raise OperatorError("保留原始实数定义域所需的 guard 超出 AST 预算；请拆分表达式。")


def append_domain_guards(node, context):
    """Append unsimplified zero terms so Formula evaluates domains and jets."""
    # Capture the final tree as well. This covers explicit powers of zero that
    # can numerically mask NaN (NaN**0 == 1), not only our derivative shortcuts.
    capture_domains(node, context)
    result = node
    for guard in context.domain_guards.values():
        zero_term = ast.BinOp(left=number(0), op=ast.Mult(), right=guard)
        result = bounded(ast.BinOp(left=result, op=ast.Add(), right=zero_term))
    return result


def total_derivative(node, variable, context):
    """Differentiate only the approved AST; fields and jets use the chain rule."""
    if variable not in context.variables:
        raise OperatorError("微分坐标未声明：" + str(variable))
    scalar(node)
    bounded(node)
    capture_domains(node, context)

    def add(a, b):
        return _binary(ast.Add(), a, b, True)

    def mul(a, b):
        return _binary(ast.Mult(), a, b, True)

    def visit(n):
        if isinstance(n, ast.Constant):
            return number(0)
        if isinstance(n, ast.Name):
            if n.id in context.variables:
                return number(int(n.id == variable))
            if n.id in context.parameters or n.id in ("pi", "e"):
                return number(0)
            canonical = canonical_jet(n.id, context)
            head, _, suffix = canonical.partition("_")
            return name(canonical_jet(head + "_" + suffix + variable, context))
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, (ast.UAdd, ast.USub)):
            answer = visit(n.operand)
            return negate(answer) if isinstance(n.op, ast.USub) else answer
        if isinstance(n, ast.BinOp):
            a, b = n.left, n.right
            da, db = visit(a), visit(b)
            if isinstance(n.op, ast.Add):
                return add(da, db)
            if isinstance(n.op, ast.Sub):
                return _binary(ast.Sub(), da, db, True)
            if isinstance(n.op, ast.Mult):
                return add(mul(da, b), mul(a, db))
            if isinstance(n.op, ast.Div):
                numerator = _binary(ast.Sub(), mul(da, b), mul(a, db), True)
                denominator = ast.BinOp(left=b, op=ast.Pow(), right=number(2))
                return _binary(ast.Div(), numerator, denominator, True)
            if isinstance(n.op, ast.Pow):
                exponent = constant_value(b)
                if abs(exponent) > 16:
                    raise OperatorError("幂指数的绝对值不能超过 16。")
                if exponent == 0:
                    return number(0)
                if exponent - 1 < -16:
                    raise OperatorError("微分生成的幂指数超出 Formula 的 ±16 范围。")
                power = ast.BinOp(left=a, op=ast.Pow(), right=number(exponent - 1))
                return mul(mul(number(exponent), power), da)
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in FUNCTIONS and len(n.args) == 1:
            function, argument = n.func.id, n.args[0]
            derivative = visit(argument)
            if function == "abs":
                raise OperatorError("abs 的经典导数在零点不确定；请提供光滑表达式或显式分支。")
            if function == "sin":
                outer = call("cos", argument)
            elif function == "cos":
                outer = negate(call("sin", argument))
            elif function == "exp":
                outer = call("exp", argument)
            elif function == "tanh":
                outer = ast.BinOp(left=number(1), op=ast.Sub(),
                                  right=ast.BinOp(left=call("tanh", argument), op=ast.Pow(), right=number(2)))
            elif function == "sqrt":
                outer = ast.BinOp(left=number(1), op=ast.Div(),
                                  right=ast.BinOp(left=number(2), op=ast.Mult(), right=call("sqrt", argument)))
            else:
                outer = ast.BinOp(left=number(1), op=ast.Div(), right=argument)
            return mul(outer, derivative)
        raise OperatorError("微分只接受安全标量 AST，不接受属性、索引或任意函数调用。")

    return bounded(visit(node))


def differentiate(node, axes, context):
    if not axes or len(axes) > MAX_DERIVATIVE_ORDER:
        raise OperatorError("微分阶数需要在 1–6 之间。")
    result = scalar(node)
    for axis in axes:
        result = total_derivative(result, axis, context)
    return bounded(result)


def gradient(node, context):
    if not context.spatial_variables:
        raise OperatorError("梯度需要至少一个空间坐标；请声明 spatial_variables。")
    return Vector(tuple(total_derivative(scalar(node), v, context) for v in context.spatial_variables))


def divergence(vector, context):
    if not isinstance(vector, Vector) or len(vector.components) != len(context.spatial_variables):
        raise OperatorError("散度需要与空间坐标数一致的向量；例如 \\nabla\\cdot(a\\nabla u)。")
    result = number(0)
    for component, variable in zip(vector.components, context.spatial_variables):
        result = _binary(ast.Add(), result, total_derivative(component, variable, context), True)
    return bounded(result)


def laplacian(node, context):
    return divergence(gradient(node, context), context)
