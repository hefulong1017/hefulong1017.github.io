"""Conservative structural inspection of a compiled physical PDE dictionary.

No numerical solver, reference field or case-name lookup is used to classify
an input. Classical type is reported only when a scalar second-order principal
symbol has a provable signature. Structure is never a well-posedness theorem.
"""
from __future__ import annotations

import ast
import copy
from functools import lru_cache
import hashlib
import json
import math
from pathlib import Path

import sympy as sp

from research_v4.spec import Formula, validate_problem
from .catalog import coverage_matrix, list_templates


LIMITS = {"coordinates": 4, "fields": 4, "physical_derivative_order": 6,
          "equations": 16, "domain": "finite_rectangular_box", "number_system": "real"}
UNSUPPORTED = ["fractional_derivatives", "integral_or_nonlocal_operators", "delay_operators",
               "arbitrary_nonbox_geometry", "native_complex_fields", "more_than_four_fields",
               "full_six_field_3d_maxwell", "automatic_weak_entropy_solution_selection"]


def _num(value):
    if type(value) not in (int, float) or not math.isfinite(value):
        raise ValueError("Expected a finite real number")
    return sp.Rational(str(value))


def _symbolic(formula, symbols):
    functions = {"sin": sp.sin, "cos": sp.cos, "exp": sp.exp, "tanh": sp.tanh,
                 "sqrt": sp.sqrt, "log": sp.log, "abs": sp.Abs}
    def visit(node):
        if isinstance(node, ast.Constant): return _num(node.value)
        if isinstance(node, ast.Name):
            if node.id in formula.parameters: return _num(formula.parameters[node.id])
            if node.id == "pi": return sp.pi
            if node.id == "e": return sp.E
            return symbols[node.id]
        if isinstance(node, ast.UnaryOp): return -visit(node.operand) if isinstance(node.op, ast.USub) else visit(node.operand)
        if isinstance(node, ast.Call): return functions[node.func.id](visit(node.args[0]))
        left, right = visit(node.left), visit(node.right)
        if isinstance(node.op, ast.Add): return left + right
        if isinstance(node.op, ast.Sub): return left - right
        if isinstance(node.op, ast.Mult): return left * right
        if isinstance(node.op, ast.Div): return left / right
        if isinstance(node.op, ast.Pow): return left ** right
        raise ValueError("Unsupported AST syntax")
    return visit(formula.tree)


def _affine(expression, selected):
    if not selected: return True
    selected = set(selected)
    coefficients = [sp.simplify(sp.diff(expression, symbol)) for symbol in selected]
    return all(not coefficient.free_symbols & selected for coefficient in coefficients)


def _order(name):
    return len(name.partition("_")[2])


def _equation_structure(expression, jet_symbols):
    used = [symbol for symbol in jet_symbols if symbol in expression.free_symbols]
    highest = max((_order(str(symbol)) for symbol in used), default=0)
    principal = [symbol for symbol in used if _order(str(symbol)) == highest]
    linear = _affine(expression, used)
    principal_affine = _affine(expression, principal)
    coefficients = {str(symbol): sp.simplify(sp.diff(expression, symbol)) for symbol in principal}
    lower_dependency = any(value.free_symbols & set(used) for value in coefficients.values())
    classification = "linear" if linear else "quasilinear" if principal_affine else "fully_nonlinear"
    return {"classification": classification,
            "linearity": "nonlinear" if classification == "fully_nonlinear" else classification,
            "highest_order": highest, "highest_order_jets": sorted(str(symbol) for symbol in principal),
            "affine_in_all_jets": linear, "affine_in_highest_order_jets": principal_affine,
            "semilinear": bool(not linear and principal_affine and not lower_dependency),
            "principal_coefficients": {name: sp.sstr(value) for name, value in coefficients.items()},
            "interpretation": "Highest-order affinity determines quasilinearity; lower-order nonlinear terms do not make a principal-affine equation fully nonlinear."}


def _interval(expression, bounds):
    """Conservative exact interval arithmetic; unknown fields remain unbounded."""
    expression = sp.simplify(expression)
    if expression.is_number:
        return expression, expression
    if isinstance(expression, sp.Symbol):
        return bounds.get(expression, (-sp.oo, sp.oo))
    if expression.func == sp.Add:
        values = [_interval(term, bounds) for term in expression.args]
        return sum(value[0] for value in values), sum(value[1] for value in values)
    if expression.func == sp.Mul:
        lower, upper = sp.Integer(1), sp.Integer(1)
        for term in expression.args:
            left, right = _interval(term, bounds)
            if left == right == 0 or lower == upper == 0: lower, upper = sp.Integer(0), sp.Integer(0); continue
            products = [sp.Integer(0) if a == 0 or b == 0 else a * b for a in (lower, upper) for b in (left, right)]
            if any(value.has(sp.nan) for value in products): return -sp.oo, sp.oo
            lower, upper = sp.Min(*products), sp.Max(*products)
        return lower, upper
    if expression.func == sp.Pow and expression.exp.is_integer:
        lower, upper = _interval(expression.base, bounds)
        exponent = int(expression.exp)
        if exponent == 0: return sp.Integer(1), sp.Integer(1)
        if exponent < 0:
            if lower <= 0 <= upper: return -sp.oo, sp.oo
            a, b = _interval(expression.base ** (-exponent), bounds)
            return 1 / b, 1 / a
        if exponent % 2: return lower ** exponent, upper ** exponent
        maximum = sp.Max(abs(lower) ** exponent, abs(upper) ** exponent)
        minimum = sp.Integer(0) if lower <= 0 <= upper else sp.Min(abs(lower) ** exponent, abs(upper) ** exponent)
        return minimum, maximum
    if expression.func == sp.exp:
        lower, upper = _interval(expression.args[0], bounds)
        return sp.exp(lower), sp.exp(upper)
    if expression.func in (sp.sin, sp.cos): return sp.Integer(-1), sp.Integer(1)
    return -sp.oo, sp.oo


def _sign(expression, bounds):
    value = sp.simplify(expression)
    if value == 0: return 0
    if value.is_positive is True: return 1
    if value.is_negative is True: return -1
    lower, upper = _interval(value, bounds)
    if lower.is_positive is True: return 1
    if upper.is_negative is True: return -1
    return None


def _definiteness(matrix, bounds):
    if all(_sign(matrix[:size, :size].det(), bounds) == 1 for size in range(1, matrix.rows + 1)):
        return "positive_definite"
    negative = -matrix
    if all(_sign(negative[:size, :size].det(), bounds) == 1 for size in range(1, matrix.rows + 1)):
        return "negative_definite"
    return None


def _classical(problem, symbols, expressions, structures):
    result = {"classification": "unknown", "proved": False,
              "scope": "scalar_second_order_principal_symbol_only",
              "reason": "No applicable provable scalar second-order rule.",
              "existence_or_uniqueness_proved": False}
    if len(problem["fields"]) != 1 or len(expressions) != 1:
        result["reason"] = "Coupled systems are not assigned a scalar elliptic/parabolic/hyperbolic label."
        return result
    variables = problem["variables"]
    if len(variables) == 1:
        result["reason"] = "One coordinate gives an ODE/algebraic input; no PDE type is claimed."
        return result
    if structures[0]["highest_order"] != 2 or not structures[0]["affine_in_highest_order_jets"]:
        result["reason"] = "The input is not second-order principal-affine; first/higher-order or fully nonlinear symbols require other theory."
        return result
    field = problem["fields"][0]
    expression = expressions[0]
    matrix = sp.zeros(len(variables))
    for name, symbol in symbols.items():
        if not name.startswith(field + "_") or _order(name) != 2: continue
        suffix = name.partition("_")[2]
        first, second = variables.index(suffix[0]), variables.index(suffix[1])
        coefficient = sp.simplify(sp.diff(expression, symbol))
        if first == second: matrix[first, second] += coefficient
        else:
            matrix[first, second] += coefficient / 2
            matrix[second, first] += coefficient / 2
    bounds = {symbols[variable]: tuple(_num(v) for v in problem["domain"][variable]) for variable in variables}
    result.update(variables=list(variables), principal_matrix=[[sp.sstr(sp.simplify(value)) for value in matrix.row(row)] for row in range(matrix.rows)],
                  principal_symbol="sum(A_ij*xi_i*xi_j)", mixed_term_convention="The coefficient of u_xy contributes half to A_xy and half to A_yx.")
    definiteness = _definiteness(matrix, bounds)
    if definiteness:
        result.update(classification="elliptic", proved=True, reason="Sylvester leading-minor signs prove principal definiteness throughout the supplied box and all unconstrained real lower jets.", definiteness=definiteness)
        return result
    if "t" in variables:
        time = variables.index("t")
        spatial = [index for index in range(len(variables)) if index != time]
        no_second_time = all(sp.simplify(matrix[time, index]) == 0 for index in range(len(variables)))
        temporal_jet = symbols.get(field + "_t")
        coefficient = sp.simplify(sp.diff(expression, temporal_jet)) if temporal_jet is not None else sp.Integer(0)
        # A nonlinear coefficient multiplying u_t is outside this limited
        # evolutionary rule unless its sign is provably nonzero everywhere.
        temporal_affine = temporal_jet is not None and _affine(expression, [temporal_jet])
        spatial_matrix = matrix.extract(spatial, spatial)
        spatial_type = _definiteness(spatial_matrix, bounds)
        temporal_sign = _sign(coefficient, bounds)
        if no_second_time and temporal_affine and temporal_sign in (-1, 1) and spatial_type:
            spatial_sign = 1 if spatial_type == "positive_definite" else -1
            orientation = "forward" if temporal_sign * spatial_sign < 0 else "backward"
            result.update(classification="parabolic", proved=True,
                          reason="No second-time/mixed-time principal term, a nonvanishing first-time coefficient, and a definite spatial second-order block are proved.",
                          time_coefficient=sp.sstr(coefficient), time_orientation=orientation,
                          wellposedness_warning="Forward-time initial data may be ill posed for backward diffusion." if orientation == "backward" else "Parabolic symbol does not prove compatibility, regularity or numerical solvability.")
            return result
    # Exact constant-symbol eigenvalue signs cover wave and mixed derivative
    # examples without evaluating a random point and calling that a proof.
    if not any(value.free_symbols for value in matrix):
        try:
            signatures = []
            for eigenvalue, multiplicity in matrix.eigenvals().items(): signatures.extend([_sign(eigenvalue, bounds)] * multiplicity)
            positive, negative = signatures.count(1), signatures.count(-1)
            if len(signatures) == len(variables) and None not in signatures and 0 not in signatures and min(positive, negative) == 1:
                result.update(classification="hyperbolic", proved=True,
                              reason="Exact constant real symmetric principal matrix has one eigenvalue of one sign and all remaining eigenvalues of the other sign.",
                              signature={"positive": positive, "negative": negative, "zero": 0})
                return result
        except (NotImplementedError, ValueError, TypeError):
            pass
    result["reason"] = "Principal sign/signature is not proved by the limited exact rules; degeneracy, changing type or stronger analysis may apply."
    return result


@lru_cache(maxsize=1)
def _frozen_validation():
    path = Path(__file__).resolve().parents[1] / "research_v5" / "validation" / "results_final.json"
    if not path.exists():
        return {"version": "V5", "status": "evidence_unavailable", "validated_families": 0, "family_names": []}
    data = json.loads(path.read_text(encoding="utf-8"))
    groups = {}
    cases = [row for row in data["rows"] if row["suite"] == "catalog" and row["variant"] == "full"]
    for row in cases: groups.setdefault(row["canonical_family"], []).append(bool(row["audit"].get("accepted_solution")))
    families = sorted(family for family, accepted in groups.items() if all(accepted))
    return {"version": "V5", "status": "named_frozen_case_evidence_only", "validated_families": len(families),
            "family_names": families, "validated_cases": sum(bool(row["audit"].get("accepted_solution")) for row in cases),
            "requested_cases": len(cases), "source": "research_v5/validation/results_final.json",
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "interpretation": "Only the exact named frozen cases/configurations passed; a new template or edited input gains no accuracy validation."}


def inspect_problem(problem):
    """Return JSON structural/admission evidence for a compiled physical spec.

    Unsafe or unsupported input is returned as ineligible, never evaluated as
    Python, passed to a solver, or converted into an existence assertion.
    """
    if not isinstance(problem, dict): problem = {}
    variables = problem.get("variables", [])
    fields = problem.get("fields", [])
    variables = list(variables) if isinstance(variables, (list, tuple)) else []
    fields = list(fields) if isinstance(fields, (list, tuple)) else []
    response = {"dimensions": len(variables), "field_count": len(fields), "variables": variables, "fields": fields,
                "derivative_orders": {}, "highest_orders": {"total": 0, "time": 0, "space": 0, "mixed": False},
                "operator_structure": {"classification": "unknown", "linearity": "unknown"},
                "classical_type": {"classification": "unknown", "proved": False},
                "admission": {"eligible": False, "reasons": [], "limits": dict(LIMITS),
                              "interpretation": "Eligible means the finite interface can represent the input, not that it has a unique solution or that numerical convergence is guaranteed."},
                "coverage": {"expression_support": "unassessed", "current_input_validation": "unvalidated",
                             "frozen_validation": copy.deepcopy(_frozen_validation()), "editable_templates": len(list_templates()),
                             "template_count_is_solved_count": False, "matrix": coverage_matrix()},
                "unsupported_boundaries": list(UNSUPPORTED), "warnings": []}
    reasons = response["admission"]["reasons"]
    if problem.get("domain_type", "box") not in ("box", "rectangle", "rectangular_box"):
        reasons.append("The current solver accepts finite rectangular boxes, not arbitrary geometry.")
    declared_unsupported = problem.get("unsupported_features", [])
    if declared_unsupported:
        reasons.append("Explicit unsupported mathematical features: " + ", ".join(str(value) for value in declared_unsupported))
    if problem.get("number_system", "real") != "real":
        reasons.append("Native complex arithmetic is unsupported; split into at most four real fields explicitly.")
    try:
        physical = {key: problem[key] for key in ("variables", "fields", "domain", "equations", "conditions")}
        physical["name"] = "structural_inspection"
        for key in ("parameters", "branches"):
            if key in problem: physical[key] = problem[key]
        physical = validate_problem(physical)
        formulas = [Formula(text, variables, fields, physical.get("parameters")) for text in physical["equations"]]
        all_formulas = list(formulas)
        for condition in physical["conditions"]:
            all_formulas.append(Formula(condition["operator"], variables, fields, physical.get("parameters")))
            Formula(str(condition["target"]), variables, fields, physical.get("parameters"), False)
            if condition.get("kind") == "periodic" and (condition.get("pair_axis") not in variables or condition["where"].get(condition["pair_axis"]) != physical["domain"][condition["pair_axis"]][0]):
                raise ValueError("Periodic conditions must pair their lower coordinate face explicitly.")
        for branch in physical.get("branches", []): all_formulas.append(Formula(branch["operator"], variables, fields, physical.get("parameters")))
        pde_names = set().union(*(formula.jets for formula in formulas))
        all_names = set().union(*(formula.jets for formula in all_formulas))
        symbols = {name: sp.Symbol(name, real=True) for name in all_names | set(variables)}
        for field in fields:
            names = sorted(name for name in all_names if name == field or name.startswith(field + "_"))
            jets = [name.partition("_")[2] for name in names]
            result = {"total": max(map(len, jets), default=0),
                      "time": max((suffix.count("t") for suffix in jets), default=0),
                      "space": max((len(suffix) - suffix.count("t") for suffix in jets), default=0),
                      "mixed": any(len(set(suffix)) > 1 for suffix in jets),
                      "jets": names, "highest_pde_order": max((_order(name) for name in pde_names if name == field or name.startswith(field + "_")), default=0),
                      "scope": "PDE, supplied condition operators and branch operators; time is the explicitly named t coordinate."}
            response["derivative_orders"][field] = result
        response["highest_orders"] = {key: max((result[key] for result in response["derivative_orders"].values()), default=0) for key in ("total", "time", "space")}
        response["highest_orders"]["mixed"] = any(result["mixed"] for result in response["derivative_orders"].values())
        expressions = [_symbolic(formula, symbols) for formula in formulas]
        jet_symbols = [symbols[name] for name in pde_names]
        structures = [_equation_structure(expression, jet_symbols) for expression in expressions]
        priorities = {"linear": 0, "quasilinear": 1, "fully_nonlinear": 2}
        overall = max((item["classification"] for item in structures), key=priorities.get)
        response["operator_structure"] = {"classification": overall, "linearity": "nonlinear" if overall == "fully_nonlinear" else overall,
                                          "equations": structures, "scope": "Highest-order affinity per equation. No scalar classification of coupled-system well-posedness is inferred."}
        response["classical_type"] = _classical(physical, symbols, expressions, structures)
        response["warnings"].append("Finite local expression support and principal-symbol type do not prove existence, uniqueness, smoothness, entropy selection or convergence.")
        if response["classical_type"].get("time_orientation") == "backward": response["warnings"].append("The parabolic symbol is backward relative to the named t coordinate; forward initial-value data may be ill posed.")
        if any(structure["classification"] == "fully_nonlinear" for structure in structures): response["warnings"].append("Fully nonlinear branches and admissibility need problem-specific information; no scalar linear principal-type label is assigned.")
    except (ValueError, TypeError, KeyError, SyntaxError, AttributeError, ZeroDivisionError) as exc:
        reasons.append(type(exc).__name__ + ": " + str(exc))
    response["admission"]["eligible"] = not reasons
    response["coverage"]["expression_support"] = "within_restricted_interface" if not reasons else "unsupported_or_invalid"
    return response
