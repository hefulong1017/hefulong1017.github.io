# 安全 LaTeX 数学输入前端

本目录提供输入编译层，不修改 V4/V5 冻结数值源、模型或实验。LaTeX 被明确分词并构造成白名单 AST，再生成 research_v4.spec.Formula 接受的残差字符串。代码不调用 eval、exec、SymPy parse_expr 或任意字符串 sympify。

~~~python
from pde_frontend import (
    normalize_symbol, parse_expression, parse_equation, parse_equations,
)

parameters = {"nu": 0.01}
residual = parse_equation(
    r"\frac{\partial u}{\partial t}-\nu\frac{\partial^2u}{\partial x^2}=0",
    variables=["x", "t"], fields=["u"], parameters=parameters,
)
# u_t - nu * u_xx - 0

operator = parse_expression(r"\partial_x((1+u^2)u_x)", ["x", "t"], ["u"])
system = parse_equations(
    [r"u_t=v_x", r"v_t=u_x"], ["x", "t"], ["u", "v"],
)
~~~

三个 parse 函数均接收 text、variables、fields、parameters=None、spatial_variables=None；parse_expression/parse_equation 返回字符串，parse_equations 返回字符串列表。parameters 是有限数值映射。仅计算位置或常数时可传入空 variables/fields；这不扩大物理求解器的维数支持范围。

normalize_symbol 和公开的 SYMBOL_ALIASES 供界面统一声明：例如 \nu/ν→nu、\phi/φ→phi、\lambda/λ/lambda→lam。字段与参数使用相同规则；编译器输出的名字应与传给数值内核的规范化声明保持一致。字段、参数、坐标及保留函数名不能冲突。

## 已支持的明确语法

| 输入 | 含义 |
|---|---|
| u_t、u_{xxt} | 已声明场的 1–6 阶经典偏导，按声明坐标顺序规范化混合下标 |
| \frac{\partial^2 u}{\partial x^2} | 标准偏导分式，分子阶数必须与分母总阶数一致 |
| \partial_x(...)、\frac{\partial}{\partial x}(...) | 对括号内完整表达式应用链式、乘积和商法则 |
| u(x,t) | 参数列表必须按顺序恰好等于声明坐标；不推断边界迹或变量替换 |
| \frac{a}{b}、2u、3xt | 分数与由声明符号组成的隐式乘法；同名完整声明优先 |
| \sin、\cos、\exp、\tanh、\log、\ln、\sqrt、\abs | 对应安全单参数函数，也接受 ASCII 函数名；多因子参数需要括号 |
| e^{...}、\mathrm{e}^{...} | 安全转换为 exp(...) |
| \sin^2(x)、\sin(x)^2 | 均为 sin(x) 的平方；不会把外部幂误放进函数参数 |
| \Delta u、\nabla^2u | 对空间坐标的拉普拉斯，默认变量列表中除 t 外的坐标 |
| \nabla\cdot(a\nabla u) | 有类型的梯度和散度组合，包含非常数系数的导数 |
| \nabla u\cdot\nabla v | 明确的梯度点积；两个向量的隐式乘法被拒绝 |
| \nabla\cdot([u_x,u_y]) | 与 spatial_variables 数量一致的显式向量散度 |

空间坐标可用 spatial_variables 显式指定。纯时间上下文没有默认空间坐标，梯度/拉普拉斯会拒绝。参数 a 作为常数微分为零；如果 a 是已声明场，则产生 a_x 等系数导数。未知坐标函数 a(x) 不会被假装成常数参数：应提供具体系数表达式，或声明辅助场并给出闭合方程。

## 多维与变系数输入

坐标声明支持 1–3 个空间坐标 `x,y,z`，并可加时间坐标 `t`。例如三维非稳态问题声明 `variables=["x", "y", "z", "t"]`；解仍可逐点查询，绘图界面以固定其余坐标的曲线或二维切片呈现。静态三维椭圆问题则声明 `variables=["x", "y", "z"]`。

坐标依赖的系数必须写成明确表达式，而不是当作常数参数。例如：

~~~latex
u_t-\nabla\cdot((1+x+y+z)\nabla u)=0
~~~

或写成逐方向通量：

~~~latex
-\partial_x((1+x)u_x)-\partial_y((1+y)u_y)-\partial_z((1+z)u_z)=1
~~~

梯度与散度会按已声明的空间坐标展开，并对系数和解应用乘积法则。因此 `\nabla\cdot(a(x)\nabla u)` 包含 `\nabla a\cdot\nabla u` 项；若系数是未知场，则还需要给它增加场方程或明确的系数模型。

界面提供基于 V6 通过家族的维度扩展模板，覆盖 1D、2D 与 3D，并可选生成变系数版本。Goursat 模板保留为二维问题。扩维和变系数组合均标为待独立误差验证；原冻结案例的通过状态不转移到新模板。

parse_equation 将唯一等号两边编成“左−右”；没有等号时视为残差。parse_equations 接受字符串列表、顶层换行、LaTeX 双反斜杠行分隔，以及 aligned/align/equation 环境和成对数学包装。默认最多 16 式；不从域文字或边界迹中自动猜测条件。

## 展开时保留原实数定义域

单纯写出 D_x log(u)=u_x/u 会错误扩大定义域：负常数 u 的右侧是零，原来的实对数却没有定义。本编译器在微分和零项约简前登记原表达式中的 log、sqrt、除数、负/非整数幂以及 exp 的有限数值检查，在最终 AST 末尾追加**不进行化简**的零项。例如：

~~~text
输入：\partial_x(log(u))
输出：1 / u * u_x + 0 * log(u) + 0 * (1 / u)

输入：\partial_x(log(-1))
输出：0 + 0 * log(-1)

输入：\partial_x(0/u)
输出：0 + 0 * (1 / u)
~~~

零项在原有效实域内不改变残差值或导数；在无效点仍强制评价原函数或倒数，使残差/数值 Jacobian 的非有限值检查能够拒绝候选。此规则也检查最终原始 AST，防止显式零幂掩盖 NaN，例如 (log(u))^0 不会令负 u 成为可接受输入。域项按结构去重，并在每个独立方程编译时重置。

这里没有添加 epsilon、把 u>0 改成 u≥epsilon，或自行发明物理分支约束。log 保留严格正实参数域，除数保留非零要求；sqrt 和分数幂保留原实域。数值 Jacobian 在某些边界或奇点可能仍无法有限评价，此时保守拒绝，而不是假装证明了光滑性。有限采样的域检查也不等于在整个连续区域证明候选有定义。

## 明确拒绝与数学边界

- u(0,t) 等边界迹必须写成 operator=u，并在条件位置栏填写 x=0；不能静默抹掉参数。
- 未声明符号、未知 LaTeX 命令、Python 属性/索引/字符串/任意调用、直接写入方程的积分、求和和分数阶算子均明确失败。V8 通过独立的结构化延迟配置支持点延迟及分布延迟；PDE 行引用配置的延迟通道符号，不把通用积分语法误当成已支持。
- 普通幂指数必须是绝对值不超过 16 的数值常量。变量指数仅对 Euler 底数 e 转成 exp；其余不猜测。生成的导数也必须符合 Formula 的幂和六阶导数限制。
- 反三角函数尚未实现。\sin^{-1}(x) 等上标 −1 写法存在反函数/倒数歧义，会拒绝；倒数可明确写 1/sin(x)。
- 顶层梯度是向量，不能冒充标量残差。应使用散度/点积或展开各分量；不支持任意张量微积分。
- abs 作为代数函数可用，但对其做经典微分会拒绝，因为零点导数需要额外定义。其他链式展开以原表达式在所选实分支上有定义且足够光滑为前提，不保证弱导数、熵解或奇点处等价。
- 非分组的多因子函数参数会提示补括号，例如将 \sin\pi x 写成 \sin(\pi x)。显式括号决定算子作用域，例如 \partial_x(u)^2 是 u_x 的平方，\partial_x(u^2) 才是对平方求导。

单式最大 12000 输入字符、1800 token、40 层括号/递归；展开后最多 400 AST 节点和 4000 字符，物理 jet 最高六阶。错误包含零基 position、一基 line/column、原文片段与指针。编译成功仅表示语法与支持范围通过，不证明该 PDE 可解、条件相容或数值算法会收敛。

tests/test_latex.py 的 114 项测试已通过，验证实际 Formula 数值等价、微分链式法则、坐标和参数语义、括号作用域、非法输入无执行、资源限制及定义域保留。回归包括负常数 u 对 D_x log(u) 必须失败、D_x log(-1) 不能变成无 guard 的零、正域值和 Torch Jacobian 不变，以及真实 V5 常数基/负边界值求解必须拒绝无效初场。

44 个模板共 471 个方程、条件与分支表达式已重新编译并通过物理格式校验。新增域检查后最大 AST 为 265/400 节点，最大输出为 450/4000 字符；未通过扩大预算容纳模板。
