"""Validation for explicit, history-driven delay PDE operators."""
from __future__ import annotations

import re

from research_v4.spec import Formula, validate_problem


def validate_delay_problem(problem):
    p = dict(problem)
    delays = p.get("delays", [])
    history = p.get("history", {})
    if not isinstance(delays, (list, tuple)) or not delays:
        raise ValueError("At least one delay operator is required.")
    if not isinstance(history, dict):
        raise ValueError("History data must map each delayed field to an expression.")
    variables, fields = p.get("variables", []), p.get("fields", [])
    if "t" not in variables:
        raise ValueError("Delay equations require the time coordinate t.")
    parameters = p.get("parameters", {})
    reserved = set(variables) | set(fields) | set(parameters) | {"pi", "e", "sin", "cos", "exp", "tanh", "sqrt", "log", "abs"}
    aliases, normalized = set(), []
    for raw in delays:
        if not isinstance(raw, dict):
            raise ValueError("Each delay operator must be an object.")
        symbol = raw.get("symbol")
        if not isinstance(symbol, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9]*", symbol):
            raise ValueError("Delay symbols must be simple names such as d1 or m1.")
        if symbol in reserved or symbol in aliases:
            raise ValueError("Delay symbols must be unique and cannot shadow fields, coordinates, or parameters.")
        aliases.add(symbol)
        field = raw.get("field")
        if field not in fields:
            raise ValueError(f"Delay operator {symbol} must reference a declared field.")
        kind = raw.get("kind")
        if kind == "point":
            delay = str(raw.get("delay", "")).strip()
            if not delay:
                raise ValueError(f"Point delay {symbol} needs a positive delay expression.")
            Formula(delay, variables, [], parameters, allow_fields=False)
            normalized.append({"symbol": symbol, "kind": kind, "field": field, "delay": delay})
        elif kind == "distributed":
            lower, upper, kernel = (str(raw.get(key, "")).strip() for key in ("lower", "upper", "kernel"))
            if not lower or not upper or not kernel:
                raise ValueError(f"Distributed delay {symbol} needs lower/upper lag bounds and a kernel.")
            Formula(lower, variables, [], parameters, allow_fields=False)
            Formula(upper, variables, [], parameters, allow_fields=False)
            Formula(kernel, list(variables) + ["s"], [], parameters, allow_fields=False)
            order = raw.get("quadrature", 16)
            if type(order) is not int or not 4 <= order <= 64:
                raise ValueError("Distributed-delay quadrature order must be an integer from 4 to 64.")
            normalized.append({"symbol": symbol, "kind": kind, "field": field,
                               "lower": lower, "upper": upper, "kernel": kernel,
                               "quadrature": order})
        else:
            raise ValueError("Delay kind must be point or distributed.")

    needed_history = {item["field"] for item in normalized}
    if set(history) != needed_history:
        missing = sorted(needed_history - set(history))
        extra = sorted(set(history) - needed_history)
        raise ValueError(f"Provide exactly one history expression per delayed field; missing={missing}, extra={extra}.")
    for field, expression in history.items():
        if not isinstance(expression, str) or not expression.strip():
            raise ValueError(f"History for {field} must be a nonempty expression.")
        Formula(expression, variables, [], parameters, allow_fields=False)

    equations = p.get("equations", [])
    surrogate = dict(p)
    surrogate.pop("delays", None)
    surrogate.pop("history", None)
    surrogate["equations"] = []
    for equation in equations:
        for alias in aliases:
            equation = re.sub(r"(?<![A-Za-z0-9_])" + re.escape(alias) + r"(?![A-Za-z0-9_])", "0", equation)
        surrogate["equations"].append(equation)
    checked = validate_problem(surrogate)
    for expression in equations:
        formula = Formula(expression, variables, list(fields) + sorted(aliases), parameters)
        if any(name.startswith(alias + "_") for name in formula.jets for alias in aliases):
            raise ValueError("Derivatives of delayed aliases are not supported; use delayed values in the residual.")
    checked["equations"] = list(equations)
    checked["delays"] = normalized
    checked["history"] = dict(history)
    return checked
