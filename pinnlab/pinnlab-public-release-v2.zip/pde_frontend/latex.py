"""A small, explicit LaTeX-to-Formula compiler, without eval or string CAS.

Supported input is mathematical syntax, never Python source. The compiler
tokenizes and builds a whitelisted AST itself. Differential operators use the
bounded chain/product rules in operators.py. Unsupported or ambiguous syntax
fails with a source position rather than being guessed or silently discarded.
"""
from __future__ import annotations

import ast
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
import keyword
import math
import re

from . import operators as op


MAX_INPUT_LENGTH = 12000
MAX_TOKENS = 1800
MAX_NESTING = 40
MAX_OUTPUT_LENGTH = 4000
MAX_EQUATIONS = 16

_GREEK = {
    "alpha": "α", "beta": "β", "gamma": "γ", "delta": "δ",
    "epsilon": "ε", "zeta": "ζ", "eta": "η", "theta": "θ",
    "iota": "ι", "kappa": "κ", "lambda": "λ", "mu": "μ",
    "nu": "ν", "xi": "ξ", "pi": "π", "rho": "ρ",
    "sigma": "σ", "tau": "τ", "upsilon": "υ", "phi": "φ",
    "chi": "χ", "psi": "ψ", "omega": "ω",
}
SYMBOL_ALIASES = {}
for _ascii, _unicode in _GREEK.items():
    _target = "lam" if _ascii == "lambda" else _ascii
    SYMBOL_ALIASES[_ascii] = _target
    SYMBOL_ALIASES["\\" + _ascii] = _target
    SYMBOL_ALIASES[_unicode] = _target
for _variant, _target in {
    "varepsilon": "epsilon", "vartheta": "theta", "varrho": "rho",
    "varsigma": "sigma", "varphi": "phi",
}.items():
    SYMBOL_ALIASES["\\" + _variant] = _target
for _unicode, _target in {"ϵ": "epsilon", "ϑ": "theta", "ϱ": "rho", "ς": "sigma", "ϕ": "phi"}.items():
    SYMBOL_ALIASES[_unicode] = _target
for _upper in ("Gamma", "Theta", "Lambda", "Xi", "Pi", "Sigma", "Upsilon", "Phi", "Psi", "Omega"):
    SYMBOL_ALIASES["\\" + _upper] = _upper


def normalize_symbol(name):
    """Normalize a declared Greek/ASCII name; lambda is consistently named lam."""
    if not isinstance(name, str):
        raise ValueError("符号名称必须是文本。")
    normalized = SYMBOL_ALIASES.get(name.strip(), name.strip())
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9]*", normalized) or keyword.iskeyword(normalized):
        raise ValueError("符号名称需为 ASCII 字母开头的字母数字串；希腊字母可用 \\nu 等形式，lambda 对应 lam。")
    return normalized


class LatexParseError(ValueError):
    """User-facing failure with zero-based position and one-based line/column."""

    def __init__(self, message, source="", position=0):
        self.message = str(message)
        self.source = source if isinstance(source, str) else ""
        self.position = max(0, min(int(position), len(self.source)))
        self.line = self.source.count("\n", 0, self.position) + 1
        previous = self.source.rfind("\n", 0, self.position)
        self.column = self.position - previous
        start = max(previous + 1, self.position - 45)
        end = self.source.find("\n", self.position)
        end = len(self.source) if end < 0 else end
        end = min(end, self.position + 45)
        snippet = self.source[start:end]
        pointer = " " * (self.position - start) + "^"
        super().__init__(f"{self.message}（第 {self.line} 行，第 {self.column} 列）\n{snippet}\n{pointer}")


@dataclass(frozen=True)
class Token:
    kind: str
    value: str
    start: int
    end: int


def _context(variables, fields, parameters, spatial_variables):
    try:
        if isinstance(variables, str) or not isinstance(variables, Sequence):
            raise ValueError("variables 必须是坐标名称列表。")
        if isinstance(fields, str) or not isinstance(fields, Sequence):
            raise ValueError("fields 必须是未知函数名称列表。")
        coordinates = tuple(normalize_symbol(v) for v in variables)
        unknowns = tuple(normalize_symbol(f) for f in fields)
        if not 0 <= len(coordinates) <= 4 or len(set(coordinates)) != len(coordinates) or any(v not in ("x", "y", "z", "t") for v in coordinates):
            raise ValueError("请使用至多 4 个互异 x/y/z/t 坐标；纯常数表达式可使用空列表。")
        if len(unknowns) > 4 or len(set(unknowns)) != len(unknowns):
            raise ValueError("未知函数最多 4 个，规范化后的名称不能重复。")
        parameters = {} if parameters is None else parameters
        if not isinstance(parameters, Mapping) or len(parameters) > 64:
            raise ValueError("parameters 应为最多 64 个有限数值参数的映射。")
        names = tuple(normalize_symbol(k) for k in parameters)
        if len(set(names)) != len(names):
            raise ValueError("参数在希腊名称规范化后出现重名。")
        if any(type(v) not in (int, float) or not math.isfinite(v) for v in parameters.values()):
            raise ValueError("参数值必须为有限实数。")
        reserved = set(coordinates) | set(op.FUNCTIONS) | {"pi", "e"}
        if set(unknowns) & reserved or set(names) & (reserved | set(unknowns)):
            raise ValueError("字段、参数、坐标和保留函数名不能重名。")
        if spatial_variables is not None and (isinstance(spatial_variables, str) or not isinstance(spatial_variables, Sequence)):
            raise ValueError("spatial_variables 必须是坐标名称列表。")
        spatial = tuple(v for v in coordinates if v != "t") if spatial_variables is None else tuple(normalize_symbol(v) for v in spatial_variables)
        if len(set(spatial)) != len(spatial) or any(v not in coordinates for v in spatial):
            raise ValueError("spatial_variables 必须是已声明坐标的互异子列表。")
        return op.Context(coordinates, unknowns, names, spatial)
    except (ValueError, TypeError) as exc:
        raise LatexParseError(str(exc)) from exc


def _unwrap_math(text):
    # Keep string length/offsets unchanged while removing matching math wrappers.
    stripped = text.strip()
    left = len(text) - len(text.lstrip())
    pairs = (("$$", "$$"), ("\\(", "\\)"), ("\\[", "\\]"), ("$", "$"))
    for opening, closing in pairs:
        if stripped.startswith(opening):
            if not stripped.endswith(closing) or len(stripped) <= len(opening) + len(closing):
                raise LatexParseError("数学环境定界符未成对闭合。", text, left)
            a, b = left, left + len(stripped) - len(closing)
            text = text[:a] + " " * len(opening) + text[a + len(opening):b] + " " * len(closing) + text[b + len(closing):]
            break
    return text


def _prepare(text):
    if not isinstance(text, str) or not 0 < len(text) <= MAX_INPUT_LENGTH:
        raise LatexParseError(f"单个表达式需包含 1–{MAX_INPUT_LENGTH} 个字符。", text)
    return _unwrap_math(text)


def _tokens(text):
    result, index, stack = [], 0, []
    mapping = {
        "+": "PLUS", "-": "MINUS", "−": "MINUS", "*": "MUL",
        "/": "DIV", "^": "POW", "_": "SUB", "=": "EQUAL",
        "(": "LP", ")": "RP", "{": "LB", "}": "RB",
        "[": "LS", "]": "RS", ",": "COMMA", "|": "BAR",
        "·": "MUL", "⋅": "MUL", "×": "MUL",
    }
    while index < len(text):
        start, char = index, text[index]
        if char.isspace():
            index += 1
            continue
        if char == "\\":
            index += 1
            if index < len(text) and text[index] in ",;!: ":
                index += 1
                continue
            match = re.match(r"[A-Za-z]+", text[index:])
            if not match:
                raise LatexParseError("不支持此 LaTeX 转义；多行方程请调用 parse_equations。", text, start)
            command = match.group()
            index += len(command)
            if command in ("left", "right", "quad", "qquad", "enspace", "displaystyle", "textstyle"):
                continue
            if command in ("cdot", "times"):
                token = Token("MUL", "dot" if command == "cdot" else "*", start, index)
            elif "\\" + command in SYMBOL_ALIASES:
                token = Token("ID", SYMBOL_ALIASES["\\" + command], start, index)
            elif command in op.FUNCTIONS or command == "ln":
                token = Token("FUNC", "log" if command == "ln" else command, start, index)
            elif command in ("frac", "dfrac", "tfrac"):
                token = Token("CMD", "frac", start, index)
            elif command in ("partial", "nabla", "Delta"):
                token = Token("CMD", command, start, index)
            elif command in ("mathrm", "operatorname"):
                token = Token("CMD", command, start, index)
            else:
                hint = ("当前只支持整数阶局部经典微分，不支持积分、分数阶或非局部算子。"
                        if command in ("int", "iint", "iiint", "oint", "sum", "prod", "prescript") else
                        "请使用支持的函数、局部微分算子或声明的符号。")
                raise LatexParseError("不支持的命令 \\" + command + "。" + hint, text, start)
        elif char in ("∂", "∇", "Δ"):
            index += 1
            token = Token("CMD", {"∂": "partial", "∇": "nabla", "Δ": "Delta"}[char], start, index)
        elif char in SYMBOL_ALIASES:
            index += 1
            token = Token("ID", SYMBOL_ALIASES[char], start, index)
        elif char.isascii() and (char.isdigit() or char == "." and index + 1 < len(text) and text[index + 1].isdigit()):
            match = re.match(r"(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?", text[index:])
            value = match.group()
            if len(value) > 64:
                raise LatexParseError("数字字面量过长。", text, start)
            index += len(value)
            token = Token("NUM", value, start, index)
        elif char.isascii() and char.isalpha():
            match = re.match(r"[A-Za-z][A-Za-z0-9]*", text[index:])
            value = match.group()
            index += len(value)
            token = Token("ID", SYMBOL_ALIASES.get(value, value), start, index)
        elif char in mapping:
            index += 1
            if char == "*" and index < len(text) and text[index] == "*":
                index += 1
                token = Token("POW", "**", start, index)
            else:
                token = Token(mapping[char], "dot" if char in ("·", "⋅") else char, start, index)
        else:
            raise LatexParseError("不支持的字符 " + repr(char) + "；不接受 Python 属性、字符串或代码。", text, start)
        if token.kind in ("LP", "LB", "LS"):
            stack.append(token)
            if len(stack) > MAX_NESTING:
                raise LatexParseError("括号嵌套超过 40 层。", text, start)
        elif token.kind in ("RP", "RB", "RS"):
            expected = {"RP": "LP", "RB": "LB", "RS": "LS"}[token.kind]
            if not stack or stack[-1].kind != expected:
                raise LatexParseError("括号不匹配。", text, start)
            stack.pop()
        result.append(token)
        if len(result) > MAX_TOKENS:
            raise LatexParseError("表达式 token 数量超出限制；请拆分输入。", text, start)
    if stack:
        raise LatexParseError("括号未闭合。", text, stack[-1].start)
    return result


class _Parser:
    def __init__(self, tokens, context, source):
        self.tokens = list(tokens) + [Token("EOF", "", len(source), len(source))]
        self.context, self.source, self.index, self.depth = context, source, 0, 0

    @property
    def current(self):
        return self.tokens[self.index]

    def fail(self, message, token=None):
        raise LatexParseError(message, self.source, (token or self.current).start)

    def take(self, kind=None):
        token = self.current
        if kind is not None and token.kind != kind:
            self.fail("此处需要 " + kind + "，请检查运算符或括号。")
        self.index += 1
        return token

    def parse(self):
        if self.current.kind == "EOF":
            self.fail("表达式不能为空。")
        try:
            result = self.addition()
            if self.current.kind != "EOF":
                self.fail("此处有无法解释的符号；等式请使用 parse_equation，多行请使用 parse_equations。")
            return result
        except op.OperatorError as exc:
            self.fail(str(exc), self.tokens[max(0, self.index - 1)])

    def addition(self):
        result = self.product()
        while self.current.kind in ("PLUS", "MINUS"):
            operation = self.take()
            right = self.product()
            result = op.binary(ast.Add() if operation.kind == "PLUS" else ast.Sub(), result, right)
        return result

    def starts_atom(self, token):
        return token.kind in ("NUM", "ID", "FUNC", "CMD", "LP", "LB", "LS", "BAR")

    def product(self):
        result = self.unary()
        while True:
            if self.current.kind in ("MUL", "DIV"):
                token = self.take()
                result = op.binary(ast.Mult() if token.kind == "MUL" else ast.Div(),
                                   result, self.unary(), dot=token.value == "dot")
            elif self.starts_atom(self.current) and self.current.kind != "BAR":
                result = op.binary(ast.Mult(), result, self.unary())
            else:
                break
        return result

    def unary(self):
        self.depth += 1
        if self.depth > MAX_NESTING:
            self.fail("表达式递归嵌套超过 40 层。")
        try:
            if self.current.kind in ("PLUS", "MINUS"):
                negative = self.take().kind == "MINUS"
                value = self.unary()
                return op.negate(value) if negative else value
            return self.power()
        finally:
            self.depth -= 1

    def power(self):
        result = self.atom()
        if self.current.kind == "POW":
            token = self.take()
            exponent = self.unary()
            if isinstance(result, ast.Name) and result.id == "e":
                return op.call("exp", op.scalar(exponent))
            try:
                value = op.constant_value(op.scalar(exponent))
            except op.OperatorError as exc:
                self.fail(str(exc), token)
            if abs(value) > 16:
                self.fail("幂指数的绝对值不能超过 16。", token)
            result = op.binary(ast.Pow(), op.scalar(result), op.number(value))
        return result

    def group_tokens(self):
        opening = self.take("LB")
        depth, result = 1, []
        while depth:
            token = self.take()
            if token.kind == "EOF":
                self.fail("花括号未闭合。", opening)
            if token.kind == "LB":
                depth += 1
            elif token.kind == "RB":
                depth -= 1
            if depth:
                result.append(token)
        return result

    def group(self):
        token = self.take()
        closing = {"LP": "RP", "LB": "RB"}[token.kind]
        result = self.addition()
        self.take(closing)
        return result

    def subscript(self):
        self.take("SUB")
        values = self.group_tokens() if self.current.kind == "LB" else [self.take("ID")]
        if not values or any(t.kind != "ID" for t in values):
            self.fail("导数下标只支持已声明坐标组成的字符串，例如 u_{xxt}。")
        suffix = "".join(t.value for t in values)
        if not suffix or any(v not in self.context.variables for v in suffix) or len(suffix) > 6:
            self.fail("导数下标只能包含已声明坐标，阶数不超过 6。", values[0])
        return suffix

    def integer_power(self):
        token = self.take("POW")
        values = self.group_tokens() if self.current.kind == "LB" else [self.take("NUM")]
        if len(values) != 1 or values[0].kind != "NUM" or not re.fullmatch(r"[1-6]", values[0].value):
            self.fail("微分阶数必须是 1–6 的整数；不支持分数阶微分。", token)
        return int(values[0].value)

    def operand(self):
        if not self.starts_atom(self.current) and self.current.kind not in ("PLUS", "MINUS"):
            self.fail("微分算子后需要函数或括号表达式。")
        # A compound operator operand must be grouped. Otherwise the operator
        # applies to exactly the next powered atom, as in Delta u or partial_x u.
        if self.current.kind in ("LP", "LB"):
            return self.group()
        return self.unary()

    def fraction(self):
        numerator, denominator = self.group_tokens(), self.group_tokens()
        if numerator and numerator[0].kind == "CMD" and numerator[0].value == "partial":
            nparser = _Parser(numerator, self.context, self.source)
            nparser.take()
            order = nparser.integer_power() if nparser.current.kind == "POW" else 1
            body = nparser.tokens[nparser.index:-1]
            dparser = _Parser(denominator, self.context, self.source)
            axes = []
            while dparser.current.kind != "EOF":
                partial = dparser.take()
                if partial.kind != "CMD" or partial.value != "partial":
                    self.fail("微分分母需为 \\partial x 或 \\partial x^2\\partial t 这样的坐标序列。", partial)
                coordinate = dparser.take("ID")
                if coordinate.value not in self.context.variables:
                    self.fail("微分分母含未声明或非单字母坐标。", coordinate)
                repeats = dparser.integer_power() if dparser.current.kind == "POW" else 1
                axes.extend([coordinate.value] * repeats)
                if len(axes) > 6:
                    self.fail("物理微分阶数不能超过 6。", coordinate)
            if len(axes) != order:
                self.fail("微分分子阶数与分母坐标总阶数不一致。", numerator[0])
            value = _Parser(body, self.context, self.source).parse() if body else self.operand()
            return op.differentiate(value, axes, self.context)
        a = _Parser(numerator, self.context, self.source).parse()
        b = _Parser(denominator, self.context, self.source).parse()
        return op.binary(ast.Div(), a, b)

    def identifier(self, token):
        raw = token.value
        known = set(self.context.variables) | set(self.context.fields) | set(self.context.parameters) | {"pi", "e"} | set(op.FUNCTIONS)
        if raw not in known:
            # Exact declared symbols take precedence over juxtaposition. Only a
            # complete segmentation into declared symbols is ever accepted.
            names = sorted(known, key=lambda value: (-len(value), value))
            cache = {}
            def segment(index):
                if index == len(raw):
                    return []
                if index in cache:
                    return cache[index]
                for candidate in names:
                    if raw.startswith(candidate, index):
                        tail = segment(index + len(candidate))
                        if tail is not None:
                            cache[index] = [candidate] + tail
                            return cache[index]
                cache[index] = None
                return None
            pieces = segment(0) if len(raw) <= 80 else None
            if not pieces or len(pieces) <= 1:
                self.fail("未声明的符号 " + raw + "；请在字段或参数栏声明，或使用显式乘号。", token)
            offset, inserted = token.start, []
            for piece in pieces:
                inserted.append(Token("ID", piece, offset, offset + len(piece)))
                offset += len(piece)
            self.tokens[self.index:self.index] = inserted[1:]
            raw = inserted[0].value
        if raw in op.FUNCTIONS:
            return self.function(Token("FUNC", raw, token.start, token.end))
        if self.current.kind == "SUB":
            if raw not in self.context.fields:
                self.fail("仅未知函数支持导数下标；参数下标名称请先规范化为独立参数。", token)
            return op.name(op.canonical_jet(raw + "_" + self.subscript(), self.context))
        if raw in self.context.fields and self.current.kind == "LP":
            self.take()
            arguments = [self.addition()]
            while self.current.kind == "COMMA":
                self.take()
                arguments.append(self.addition())
            self.take("RP")
            if len(arguments) != len(self.context.variables) or any(
                not isinstance(a, ast.Name) or a.id != v for a, v in zip(arguments, self.context.variables)
            ):
                self.fail("场函数参数必须按顺序恰好列出声明坐标；u(0,t) 等边界迹请写作 u，并在条件位置栏填写 x=0。", token)
        elif raw in self.context.parameters and self.current.kind == "LP":
            self.fail("参数是常数，不能写成未定义的坐标函数；请用明确系数表达式或声明辅助字段。", token)
        return op.name(raw)

    def function(self, token):
        exponent = None
        if self.current.kind == "POW":
            self.take()
            exponent = self.unary()
            value = op.constant_value(op.scalar(exponent))
            if abs(value) > 16:
                self.fail("函数幂指数的绝对值不能超过 16。", token)
            if value == -1 and token.value in ("sin", "cos", "tanh", "log"):
                self.fail("函数上标 −1 可能表示反函数，当前不作猜测；倒数请写 1/函数(...)，反函数尚不支持。", token)
            exponent = op.number(value)
        if token.value == "sqrt" and self.current.kind == "LS":
            self.fail("当前 sqrt 只支持平方根；其他根请使用明确的常数有理幂。", token)
        grouped = self.current.kind in ("LP", "LB")
        value = self.operand()
        if not grouped and self.starts_atom(self.current) and self.current.kind not in ("FUNC",):
            self.fail("函数的多因子参数有歧义，请用括号，例如 \\sin(\\pi x)。", self.current)
        result = op.call(token.value, op.scalar(value))
        return op.binary(ast.Pow(), result, exponent) if exponent is not None else result

    def atom(self):
        token = self.take()
        if token.kind == "NUM":
            try:
                value = float(token.value) if any(c in token.value for c in ".eE") else int(token.value)
                return op.number(value)
            except (ValueError, OverflowError, op.OperatorError) as exc:
                self.fail("数字必须是有限实数。", token)
        if token.kind in ("LP", "LB"):
            self.index -= 1
            return self.group()
        if token.kind == "LS":
            values = [op.scalar(self.addition())]
            while self.current.kind == "COMMA":
                self.take()
                values.append(op.scalar(self.addition()))
            self.take("RS")
            if len(values) != len(self.context.spatial_variables):
                self.fail("向量分量数必须与 spatial_variables 相同。", token)
            return op.Vector(tuple(values))
        if token.kind == "ID":
            return self.identifier(token)
        if token.kind == "FUNC":
            return self.function(token)
        if token.kind == "CMD":
            if token.value == "frac":
                return self.fraction()
            if token.value in ("operatorname", "mathrm"):
                content = self.group_tokens()
                if len(content) != 1 or content[0].kind != "ID":
                    self.fail("仅支持单个已声明符号或安全函数的排版包装。", token)
                return self.identifier(content[0])
            if token.value == "partial":
                before = self.integer_power() if self.current.kind == "POW" else None
                if self.current.kind != "SUB":
                    self.fail("请写 \\partial_x(...) 或标准偏导分式。", token)
                axes = self.subscript()
                after = self.integer_power() if self.current.kind == "POW" else None
                if before is not None and after is not None:
                    self.fail("微分阶数重复声明。", token)
                order = before or after
                if order is not None:
                    if len(axes) != 1:
                        self.fail("重复微分幂只适用于单坐标；混合微分请明确列出下标。", token)
                    axes *= order
                return op.differentiate(self.operand(), axes, self.context)
            if token.value == "Delta":
                return op.laplacian(op.scalar(self.operand()), self.context)
            if token.value == "nabla":
                if self.current.kind == "POW":
                    order = self.integer_power()
                    if order != 2:
                        self.fail("只支持 \\nabla^2 的拉普拉斯写法；其他阶请显式输入偏导。", token)
                    return op.laplacian(op.scalar(self.operand()), self.context)
                if self.current.kind == "MUL" and self.current.value == "dot":
                    self.take()
                    return op.divergence(self.operand(), self.context)
                return op.gradient(op.scalar(self.operand()), self.context)
        if token.kind == "BAR":
            # A bar is not multiplication and its matching delimiter must be
            # explicit. Grouped abs is clearer and avoids norm/vector ambiguity.
            self.fail("绝对值请写 \\abs(...) 或 abs(...)；向量范数请显式写各分量。", token)
        self.fail("此处需要数字、已声明符号、函数或括号表达式。", token)


def _emit(tree, context, source):
    try:
        tree = op.bounded(op.append_domain_guards(op.scalar(tree), context))
    except op.OperatorError as exc:
        raise LatexParseError(str(exc), source, 0) from exc
    # Validate our own generated AST as well, independently of parsing paths.
    for node in ast.walk(tree):
        if isinstance(node, ast.Name):
            if node.id in set(context.variables) | set(context.parameters) | {"pi", "e"} | set(op.FUNCTIONS):
                continue
            try:
                op.canonical_jet(node.id, context)
            except op.OperatorError as exc:
                raise LatexParseError(str(exc), source, 0) from exc
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Pow):
            value = op.constant_value(node.right)
            if abs(value) > 16:
                raise LatexParseError("展开后的幂指数超出 ±16。", source, 0)
    output = ast.unparse(tree)
    if len(output) > MAX_OUTPUT_LENGTH:
        raise LatexParseError("展开后的残差超过 4000 个字符；请拆分方程。", source, 0)
    return output


def parse_expression(text, variables, fields, parameters=None, spatial_variables=None):
    """Compile one scalar expression to the restricted Formula input language."""
    context = _context(variables, fields, parameters, spatial_variables)
    source = _prepare(text)
    return _emit(_Parser(_tokens(source), context, text).parse(), context, text)


def parse_equation(text, variables, fields, parameters=None, spatial_variables=None):
    """Compile lhs=rhs into lhs-rhs; no equality means an already given residual."""
    context = _context(variables, fields, parameters, spatial_variables)
    source = _prepare(text)
    tokens = _tokens(source)
    equals = [index for index, token in enumerate(tokens) if token.kind == "EQUAL"]
    if len(equals) > 1:
        raise LatexParseError("每行只允许一个等号；请将方程组分行输入。", text, tokens[equals[1]].start)
    if not equals:
        return _emit(_Parser(tokens, context, text).parse(), context, text)
    index = equals[0]
    left = _Parser(tokens[:index], context, text).parse()
    right = _Parser(tokens[index + 1:], context, text).parse()
    try:
        tree = op.binary(ast.Sub(), left, right)
    except op.OperatorError as exc:
        raise LatexParseError(str(exc), text, tokens[index].start) from exc
    return _emit(tree, context, text)


def parse_equations(text, variables, fields, parameters=None, spatial_variables=None):
    """Compile <=16 equations supplied as lines, LaTeX rows, or a text list."""
    if isinstance(text, str):
        if not 0 < len(text) <= MAX_INPUT_LENGTH * MAX_EQUATIONS:
            raise LatexParseError("方程组输入大小超限。", text)
        source = _unwrap_math(text)
        for match in list(re.finditer(r"\\(begin|end)\{([^{}]+)\}", source)):
            if match.group(2) not in ("aligned", "align", "align*", "equation", "equation*"):
                raise LatexParseError("仅支持 aligned/align/equation 方程环境；分段函数和矩阵请逐式展开。", text, match.start())
        source = re.sub(r"\\(?:begin|end)\{(?:aligned|align\*?|equation\*?)\}",
                        lambda m: " " * len(m.group()), source)
        source = source.replace("&", " ")
        # Line breaks inside a TeX fraction/group are formatting, not equations.
        rows, start, depth = [], 0, 0
        index = 0
        while index < len(source):
            char = source[index]
            if char in "({[":
                depth += 1
            elif char in ")}]":
                depth -= 1
            separator = depth == 0 and (char in "\n;" or source.startswith("\\\\", index))
            if separator:
                if source[start:index].strip():
                    rows.append((source[start:index], start))
                width = 2 if source.startswith("\\\\", index) else 1
                index += width
                start = index
                continue
            index += 1
        if source[start:].strip():
            rows.append((source[start:], start))
    elif isinstance(text, Sequence) and not isinstance(text, (bytes, bytearray)):
        if any(not isinstance(row, str) for row in text):
            raise LatexParseError("方程列表中的每项必须是文本。")
        rows = [(row, 0) for row in text]
        source = None
    else:
        raise LatexParseError("请提供方程文本或字符串列表。")
    if not 1 <= len(rows) <= MAX_EQUATIONS:
        raise LatexParseError("方程数量需为 1–16。", text if isinstance(text, str) else "")
    result = []
    for row, offset in rows:
        try:
            result.append(parse_equation(row, variables, fields, parameters, spatial_variables))
        except LatexParseError as exc:
            if source is not None:
                raise LatexParseError(exc.message, text, offset + exc.position) from exc
            raise
    return result
