"""Local image-to-LaTeX OCR using Pix2Tex, loaded only on request."""
from __future__ import annotations

from functools import lru_cache
from io import BytesIO


MAX_IMAGE_BYTES = 12 * 1024 * 1024
MAX_IMAGE_PIXELS = 32_000_000


@lru_cache(maxsize=1)
def _model():
    try:
        from pix2tex.cli import LatexOCR
    except ImportError as exc:
        raise RuntimeError("本地公式识别组件未安装；请运行项目的 install.cmd 安装 equation-ocr 扩展。") from exc
    try:
        return LatexOCR()
    except Exception as exc:
        raise RuntimeError(
            "本地 Pix2Tex 模型未能初始化。首次使用需要联网下载模型权重；"
            "请检查网络后重试，或确认本机模型缓存可用。"
        ) from exc


def recognize_equation_image(data: bytes) -> str:
    if not isinstance(data, (bytes, bytearray)) or not data:
        raise ValueError("请选择一张非空方程图片。")
    if len(data) > MAX_IMAGE_BYTES:
        raise ValueError("图片最大支持 12 MB。")
    try:
        from PIL import Image, ImageOps
    except ImportError as exc:
        raise RuntimeError("缺少图片处理组件；请运行项目的 install.cmd 安装 equation-ocr 扩展。") from exc
    try:
        with Image.open(BytesIO(data)) as source:
            if source.width * source.height > MAX_IMAGE_PIXELS:
                raise ValueError("图片尺寸过大，请裁剪到 3200 万像素以内。")
            image = ImageOps.exif_transpose(source).convert("RGB")
            image.load()
    except (OSError, Image.DecompressionBombError) as exc:
        raise ValueError("无法读取该图片；请使用清晰的 PNG、JPG 或 WEBP 方程截图。") from exc
    try:
        latex = str(_model()(image)).strip()
    except Exception as exc:
        raise RuntimeError(
            "本地公式识别失败。请使用清晰、裁剪后的公式图片重试；"
            "首次运行还需要成功加载 Pix2Tex 模型权重。"
        ) from exc
    if not latex or len(latex) > 12000:
        raise ValueError("未得到可用的公式识别结果，请裁剪公式区域后重试。")
    return latex
