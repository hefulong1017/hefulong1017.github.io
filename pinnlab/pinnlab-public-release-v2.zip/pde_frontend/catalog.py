"""Editable local-PDE LaTeX templates, never a numerical-success catalogue.

Every entry is an input example. Adding a template creates no validation vote.
Six-component full 3-D Maxwell and unrestricted geometries are intentionally
outside the present four-field/box interface rather than disguised as support.
"""
from __future__ import annotations

import copy
import math
import re


_TEMPLATES = {}


def _tex(expression):
    expression = str(expression)
    expression = re.sub(r"\b([A-Za-z][A-Za-z0-9]*)_([xyzt]{1,6})\b", r"\1_{\2}", expression)
    expression = expression.replace("**", "^").replace("*", r" \cdot ")
    for name in ("sin", "cos", "exp", "tanh", "log"):
        expression = re.sub(r"\b" + name + r"(?=\s*\()", lambda match: "\\" + match.group(0), expression)
    for name in ("pi", "nu", "kappa", "alpha", "beta", "gamma", "epsilon", "rho", "sigma"):
        expression = re.sub(r"\b" + name + r"\b", lambda match: "\\" + match.group(0), expression)
    return expression


def _condition(name, where, operator="u", target="0", **extra):
    return {"name": name, "where": where, "operator": _tex(operator), "target": _tex(target), **extra}


def _walls(variables, domain, fields=("u",), target="0"):
    return [_condition(f"{field}_{axis}_{side}", {axis: domain[axis][index]}, field, target)
            for field in fields for axis in variables if axis != "t" for index, side in ((0, "left"), (1, "right"))]


def _periodic(axis, domain, fields=("u",), order=1):
    return [_condition(f"periodic_{field}_{axis}_{derivative}", {axis: domain[axis][0]},
                       field + ("_" + axis * derivative if derivative else ""),
                       kind="periodic", pair_axis=axis)
            for field in fields for derivative in range(order)]


def _initial(target="sin(pi*x)", field="u", time=0.):
    return _condition(field + "_initial", {"t": time}, field, target)


def _add(identifier, label, family, variables, equations, conditions, *, domain=None,
         parameters=None, fields=("u",), branches=None, latex_equations=None, notes=""):
    variables = list(variables)
    domain = domain or {variable: [0., 1.] for variable in variables}
    _TEMPLATES[identifier] = {
        "id": identifier, "label": label, "family": family,
        "variables": variables, "fields": list(fields), "domain": domain,
        "parameters": parameters or {},
        "latex_equations": latex_equations or [_tex(equation) + "=0" for equation in equations],
        "conditions": conditions, "branches": branches or [],
        "support_status": "editable_expression_template_not_numerically_validated",
        "numerically_validated": False,
        "wellposedness_notes": notes or "A local input example. Structural admissibility does not prove existence, uniqueness, regularity or numerical convergence.",
    }


_xt = {"x": [0., 1.], "t": [0., 1.]}
_xy = {"x": [0., 1.], "y": [0., 1.]}
_xyt = {"x": [0., 1.], "y": [0., 1.], "t": [0., 1.]}

_add("heat_1d", "一维热扩散", "heat", ("x", "t"), ["u_t-kappa*u_xx"],
     _walls(("x", "t"), _xt) + [_initial()], domain=_xt, parameters={"kappa": .1},
     latex_equations=[r"\frac{\partial u}{\partial t}-\kappa\frac{\partial^2u}{\partial x^2}=0"])
_add("heat_2d", "二维热扩散", "heat", ("x", "y", "t"), ["u_t-kappa*(u_xx+u_yy)"],
     _walls(("x", "y", "t"), _xyt) + [_initial("sin(pi*x)*sin(pi*y)")], domain=_xyt,
     parameters={"kappa": .1}, latex_equations=[r"u_t-\kappa\Delta u=0"])
_add("poisson", "Poisson 零边值", "poisson", ("x", "y"), ["-u_xx-u_yy-sin(pi*x)*sin(pi*y)"],
     _walls(("x", "y"), _xy), domain=_xy)
_add("laplace", "Laplace 非零边值", "poisson", ("x", "y"), ["u_xx+u_yy"],
     _walls(("x", "y"), _xy, target="x+y"), domain=_xy,
     latex_equations=[r"\nabla^2 u=0"])
_add("variable_diffusion", "散度形式变系数扩散", "variable_elliptic", ("x", "y"), [],
     _walls(("x", "y"), _xy), domain=_xy,
     latex_equations=[r"-\nabla\cdot((1+x)\nabla u)-1=0"])
_add("anisotropic", "各向异性椭圆方程", "anisotropic_diffusion", ("x", "y"), ["-3*u_xx-0.4*u_xy-u_yy-1"],
     _walls(("x", "y"), _xy), domain=_xy)
_add("helmholtz", "Helmholtz 波数输入", "helmholtz", ("x", "y"), ["-u_xx-u_yy-k**2*u-sin(pi*x)*sin(pi*y)"],
     _walls(("x", "y"), _xy), domain=_xy, parameters={"k": 1.},
     notes="Some wave numbers meet an eigenvalue and can cause nonuniqueness or incompatibility; no automatic well-posedness promise.")
_add("wave", "一维波动方程", "wave", ("x", "t"), ["u_tt-c**2*u_xx"],
     _walls(("x", "t"), _xt) + [_initial(), _condition("initial_velocity", {"t": 0.}, "u_t")],
     domain=_xt, parameters={"c": 1.})
_add("telegraph", "阻尼电报方程", "telegraph", ("x", "t"), ["u_tt+alpha*u_t-c**2*u_xx"],
     _walls(("x", "t"), _xt) + [_initial(), _condition("initial_velocity", {"t": 0.}, "u_t")],
     domain=_xt, parameters={"c": 1., "alpha": .5})
_add("klein_gordon", "Klein–Gordon 方程", "klein_gordon", ("x", "t"), ["u_tt-c**2*u_xx+m**2*u"],
     _walls(("x", "t"), _xt) + [_initial(), _condition("initial_velocity", {"t": 0.}, "u_t")],
     domain=_xt, parameters={"c": 1., "m": 1.})
_add("sine_gordon", "Sine–Gordon 非线性波动", "sine_gordon", ("x", "t"), ["u_tt-u_xx+sin(u)"],
     _walls(("x", "t"), _xt) + [_initial("0.2*sin(pi*x)"), _condition("initial_velocity", {"t": 0.}, "u_t")], domain=_xt)
_add("advection", "周期线性输运", "periodic_advection", ("x", "t"), ["u_t+c*u_x"],
     _periodic("x", _xt) + [_initial("sin(2*pi*x)")], domain=_xt, parameters={"c": 1.})
_add("advection_diffusion", "周期对流扩散", "advection_diffusion", ("x", "t"), ["u_t+c*u_x-nu*u_xx"],
     _periodic("x", _xt, order=2) + [_initial("sin(2*pi*x)")], domain=_xt, parameters={"c": 1., "nu": .05})
_add("burgers", "黏性 Burgers", "burgers", ("x", "t"), ["u_t+u*u_x-nu*u_xx"],
     _walls(("x", "t"), _xt) + [_initial("-sin(pi*x)")], domain=_xt, parameters={"nu": .02},
     notes="Viscosity is positive; high gradients can remain difficult. This new initial-data template has no V6 accuracy result.")
_add("reaction_diffusion", "线性反应扩散", "reaction_diffusion", ("x", "t"), ["u_t-D*u_xx+r*u"],
     _walls(("x", "t"), _xt) + [_initial()], domain=_xt, parameters={"D": .1, "r": 1.})
_add("fisher_kpp", "Fisher–KPP 反应扩散", "fisher_kpp", ("x", "t"), ["u_t-D*u_xx-r*u*(1-u)"],
     _walls(("x", "t"), _xt) + [_initial("sin(pi*x)**2")], domain=_xt, parameters={"D": .02, "r": 1.})
_add("allen_cahn", "Allen–Cahn 双稳态扩散", "allen_cahn", ("x", "t"), ["u_t-epsilon**2*u_xx+u**3-u"],
     _periodic("x", _xt, order=2) + [_initial("0.2*cos(2*pi*x)")], domain=_xt, parameters={"epsilon": .05})
_add("nonlinear_poisson", "半线性 Poisson", "nonlinear_poisson", ("x", "y"), ["-u_xx-u_yy+u**3-sin(pi*x)*sin(pi*y)"],
     _walls(("x", "y"), _xy), domain=_xy)
_add("nonlinear_diffusion", "拟线性非线性扩散", "nonlinear_diffusion", ("x", "t"),
     ["u_t-(1+u**2)*u_xx-2*u*u_x**2"],
     _walls(("x", "t"), _xt) + [_initial("0.2*sin(pi*x)")], domain=_xt,
     latex_equations=[r"u_t-\partial_x((1+u^2)u_x)=0"])
_add("minimal_surface", "最小曲面图方程", "minimal_surface", ("x", "y"),
     ["(1+u_y**2)*u_xx-2*u_x*u_y*u_xy+(1+u_x**2)*u_yy"],
     _walls(("x", "y"), _xy, target="0.1*x*y"), domain=_xy)
_add("monge_ampere", "Monge–Ampère 凸分支", "monge_ampere", ("x", "y"), ["u_xx*u_yy-u_xy**2-1"],
     _walls(("x", "y"), _xy, target="0.5*(x**2+y**2)"), domain=_xy,
     branches=[{"name": "convex_x", "operator": "u_xx", "min": 0.}, {"name": "convex_y", "operator": "u_yy", "min": 0.},
               {"name": "convex_det", "operator": "u_xx*u_yy-u_xy**2", "min": 0.}],
     notes="The convex branch is explicitly supplied. A fully nonlinear principal-symbol classification is left unknown.")
_add("eikonal", "Eikonal 正向分支", "eikonal", ("x", "y"), ["u_x**2+u_y**2-1"],
     [_condition("inflow", {"x": 0.})], domain=_xy, branches=[{"name": "forward", "operator": "u_x", "min": 0.}],
     notes="Classical local template only. Caustics and viscosity/weak solution selection are not automatically supported.")
_add("hamilton_jacobi", "黏性 Hamilton–Jacobi", "viscous_hamilton_jacobi", ("x", "t"), ["u_t+0.5*u_x**2-nu*u_xx"],
     _periodic("x", _xt, order=2) + [_initial("0.1*cos(2*pi*x)")], domain=_xt, parameters={"nu": .05})

_kdv_domain = {"x": [-math.pi, math.pi], "t": [0., .5]}
_add("kdv", "KdV 三阶色散", "kdv", ("x", "t"), ["u_t+6*u*u_x+u_xxx"],
     _periodic("x", _kdv_domain, order=3) + [_initial("0.2*cos(x)")], domain=_kdv_domain,
     notes="Periodic derivatives through order two are paired. This dispersive high-order template is unvalidated.")
_add("kuramoto_sivashinsky", "Kuramoto–Sivashinsky 四阶演化", "kuramoto_sivashinsky", ("x", "t"),
     ["u_t+u*u_x+u_xx+nu*u_xxxx"], _periodic("x", _kdv_domain, order=4) + [_initial("0.2*cos(x)")],
     domain=_kdv_domain, parameters={"nu": .1})
_add("cahn_hilliard", "Cahn–Hilliard 四阶守恒演化", "cahn_hilliard", ("x", "t"),
     ["u_t+epsilon**2*u_xxxx-(3*u**2-1)*u_xx-6*u*u_x**2"],
     [_condition(f"noflux_{side}_{jet}", {"x": value}, jet)
      for side, value in (("left", 0.), ("right", 1.)) for jet in ("u_x", "u_xxx")] + [_initial("0.1*cos(pi*x)")],
     domain=_xt, parameters={"epsilon": .05})
_add("cahn_hilliard_mixed", "Cahn–Hilliard 浓度／化学势系统", "cahn_hilliard", ("x", "t"),
     ["u_t-v_xx", "v-u**3+u+epsilon**2*u_xx"],
     [_condition(f"noflux_{field}_{side}", {"x": value}, field + "_x")
      for field in ("u", "v") for side, value in (("left", 0.), ("right", 1.))] + [_initial("0.1*cos(pi*x)")],
     domain=_xt, parameters={"epsilon": .05}, fields=("u", "v"))
_add("thin_film", "薄膜四阶退化演化", "thin_film", ("x", "t"),
     ["u_t+3*u**2*u_x*u_xxx+u**3*u_xxxx"],
     _periodic("x", _xt, order=4) + [_initial("1+0.1*cos(2*pi*x)")], domain=_xt,
     branches=[{"name": "positive_height", "operator": "u", "min": .01}],
     notes="An explicitly positive branch is requested; contact lines and zero-height weak solutions are outside this classical template.")
_add("sixth_order_diffusion", "六阶耗散方程", "sixth_order_diffusion", ("x", "t"), ["u_t-eta*u_xxxxxx"],
     _periodic("x", _xt, order=6) + [_initial("cos(2*pi*x)")], domain=_xt, parameters={"eta": .00001})
_add("beam", "静态两端固支梁", "biharmonic_beam", ("x",), ["u_xxxx-q"],
     [_condition(f"{side}_{jet}", {"x": value}, jet) for side, value in (("left", 0.), ("right", 1.)) for jet in ("u", "u_x")],
     parameters={"q": 1.}, notes="A fourth-order ODE boundary problem, not an additional PDE family success.")
_add("dynamic_beam", "动态 Euler–Bernoulli 梁", "dynamic_beam", ("x", "t"), ["u_tt+c**2*u_xxxx"],
     [_condition(f"{side}_{jet}", {"x": value}, jet) for side, value in (("left", 0.), ("right", 1.)) for jet in ("u", "u_x")]
     + [_initial("x**2*(1-x)**2"), _condition("initial_velocity", {"t": 0.}, "u_t")], domain=_xt, parameters={"c": 1.})
_add("biharmonic_plate", "二维固支双调和板", "biharmonic_plate", ("x", "y"), ["u_xxxx+2*u_xxyy+u_yyyy-1"],
     [_condition(f"{axis}_{side}_{jet}", {axis: value}, jet)
      for axis in ("x", "y") for side, value in (("left", 0.), ("right", 1.)) for jet in ("u", "u_" + axis)], domain=_xy)

_add("stokes_2d", "二维 Stokes 速度／压力系统", "stokes", ("x", "y"),
     ["-nu*(u_xx+u_yy)+p_x-sin(pi*x)*sin(pi*y)", "-nu*(v_xx+v_yy)+p_y", "u_x+v_y"],
     _walls(("x", "y"), _xy, fields=("u", "v")) + [_condition("pressure_gauge", {"x": 0., "y": 0.}, "p")],
     domain=_xy, fields=("u", "v", "p"), parameters={"nu": .1},
     notes="Three fields fit the interface; incompressibility and a pressure gauge are explicit. A template is not an inf-sup or convergence guarantee.")
_ns_domain = {"x": [0., 2 * math.pi], "y": [0., 2 * math.pi], "t": [0., 1.]}
_add("navier_stokes_2d", "二维不可压 Navier–Stokes", "navier_stokes", ("x", "y", "t"),
     ["u_t+u*u_x+v*u_y-nu*(u_xx+u_yy)+p_x", "v_t+u*v_x+v*v_y-nu*(v_xx+v_yy)+p_y", "u_x+v_y"],
     _periodic("x", _ns_domain, fields=("u", "v", "p")) + _periodic("y", _ns_domain, fields=("u", "v", "p"))
     + [_initial("sin(x)*cos(y)", "u"), _initial("-cos(x)*sin(y)", "v"),
        _condition("pressure_gauge", {"x": 0., "y": 0.}, "p")],
     domain=_ns_domain, fields=("u", "v", "p"), parameters={"nu": .05},
     notes="Smooth periodic divergence-free initial velocity; pressure has a point gauge for each time. No turbulence or arbitrary-flow accuracy claim.")
_add("elasticity_2d", "二维线弹性位移系统", "elasticity", ("x", "y"),
     ["-mu*(u_xx+u_yy)-(lam+mu)*(u_xx+v_xy)-sin(pi*x)*sin(pi*y)",
      "-mu*(v_xx+v_yy)-(lam+mu)*(u_xy+v_yy)"],
     _walls(("x", "y"), _xy, fields=("u", "v")), domain=_xy,
     fields=("u", "v"), parameters={"mu": 1., "lam": 1.})
_add("elastodynamics_2d", "二维弹性动力学", "elastodynamics", ("x", "y", "t"),
     ["rho*u_tt-mu*(u_xx+u_yy)-(lam+mu)*(u_xx+v_xy)",
      "rho*v_tt-mu*(v_xx+v_yy)-(lam+mu)*(u_xy+v_yy)"],
     _walls(("x", "y", "t"), _xyt, fields=("u", "v")) + [_initial("sin(pi*x)*sin(pi*y)", "u"), _initial("0", "v"),
       _condition("u_velocity", {"t": 0.}, "u_t"), _condition("v_velocity", {"t": 0.}, "v_t")],
     domain=_xyt, fields=("u", "v"), parameters={"rho": 1., "mu": 1., "lam": 1.})
_add("maxwell_te_2d", "二维 Maxwell TE 三场约化", "maxwell_te", ("x", "y", "t"),
     ["epsilon*u_t-(w_x-v_y)", "mu*v_t+u_y", "mu*w_t-u_x", "v_x+w_y"],
     _walls(("x", "y", "t"), _xyt, fields=("u",)) + [_initial("sin(pi*x)*sin(pi*y)", "u"), _initial("0", "v"), _initial("0", "w")],
     domain=_xyt, fields=("u", "v", "w"), parameters={"epsilon": 1., "mu": 1.},
     notes="u=Ez,v=Hx,w=Hy with PEC electric boundary and magnetic divergence constraint. Full 3-D six-field Maxwell is outside this interface.")
_add("euler_1d_smooth", "一维可压 Euler 光滑三场形式", "euler_smooth", ("x", "t"),
     ["r_t+u*r_x+r*u_x", "u_t+u*u_x+p_x/r", "p_t+u*p_x+gamma*p*u_x"],
     _periodic("x", _xt, fields=("r", "u", "p")) + [_initial("1+0.1*sin(2*pi*x)", "r"), _initial("0", "u"), _initial("1", "p")],
     domain=_xt, fields=("r", "u", "p"), parameters={"gamma": 1.4},
     branches=[{"name": "positive_density", "operator": "r", "min": .0001}, {"name": "positive_pressure", "operator": "p", "min": .0001}],
     notes="Primitive-variable classical equations before shock formation. Weak entropy solutions, vacuum and shock capturing are not provided by this template.")

_add("schrodinger_real", "Schrödinger 实部／虚部系统", "schrodinger", ("x", "t"), ["u_t+alpha*v_xx", "v_t-alpha*u_xx"],
     _periodic("x", _kdv_domain, fields=("u", "v"), order=2) + [_initial("sin(x)", "u"), _initial("0", "v")],
     domain=_kdv_domain, fields=("u", "v"), parameters={"alpha": .5},
     notes="Complex fields are split into two real unknowns; native complex arithmetic is not claimed.")
_add("gross_pitaevskii_real", "Gross–Pitaevskii 实双场", "gross_pitaevskii", ("x", "t"),
     ["u_t+0.5*v_xx-g*(u**2+v**2)*v", "v_t-0.5*u_xx+g*(u**2+v**2)*u"],
     _periodic("x", _kdv_domain, fields=("u", "v"), order=2) + [_initial("cos(x)", "u"), _initial("sin(x)", "v")],
     domain=_kdv_domain, fields=("u", "v"), parameters={"g": 1.})
_fp_domain = {"x": [-3., 3.], "t": [0., 1.]}
_add("fokker_planck", "Ornstein–Uhlenbeck Fokker–Planck", "fokker_planck", ("x", "t"), ["u_t-D*u_xx-x*u_x-u"],
     [_condition("left_reflecting", {"x": -3.}, "D*u_x+x*u"), _condition("right_reflecting", {"x": 3.}, "D*u_x+x*u"),
      _initial("exp(-x**2/(2*D))")], domain=_fp_domain, parameters={"D": .5},
     notes="Reflecting flux and full initial density are supplied. No unsupported integral normalization constraint is silently imposed.")
_add("goursat", "Goursat 混合导数问题", "goursat", ("x", "y"), ["u_xy-u"],
     [_condition("x_axis", {"y": 0.}, target="1"), _condition("y_axis", {"x": 0.}, target="1")], domain=_xy)
_add("convection_layer", "一维稳态对流扩散边界层", "convection_diffusion", ("x",), ["epsilon*u_xx-beta*u_x"],
     [_condition("left", {"x": 0.}), _condition("right", {"x": 1.}, target="1")], parameters={"epsilon": .001, "beta": 1.},
     notes="An ODE boundary layer example. A small scale can be represented but numerical accuracy is not guaranteed.")
_add("regularized_p_laplace", "正则化 p=3 Laplace 散度形式", "regularized_p_laplace", ("x", "y"), [],
     _walls(("x", "y"), _xy), domain=_xy, parameters={"epsilon": .1},
     latex_equations=[r"-\nabla\cdot(sqrt(\epsilon^2+u_x^2+u_y^2)\nabla u)-\sin(\pi x)\sin(\pi y)=0"])


_DIMENSION_FAMILIES = {
    "heat": "热方程",
    "poisson": "Poisson 方程",
    "laplace": "Laplace 方程",
    "variable_elliptic": "变系数椭圆方程",
    "helmholtz": "Helmholtz 方程",
    "anisotropic_diffusion": "各向异性扩散",
    "mixed_elliptic": "混合椭圆方程",
    "black_scholes": "Black–Scholes 方程",
    "advection_diffusion": "对流扩散方程",
    "periodic_advection": "周期输运方程",
    "reaction_diffusion": "线性反应扩散",
    "allen_cahn": "Allen–Cahn 方程",
    "nonlinear_diffusion": "非线性扩散方程",
    "nonlinear_poisson": "非线性 Poisson 方程",
    "regularized_p_laplace": "正则化 p-Laplace 方程",
    "wave": "波动方程",
    "telegraph": "电报方程",
    "klein_gordon": "Klein–Gordon 方程",
    "sine_gordon": "Sine–Gordon 方程",
    "goursat": "Goursat 方程（二维）",
}


def dimension_template_families():
    """V6-passing family labels available as editable dimensional templates."""
    return [{"id": identifier, "label": label} for identifier, label in _DIMENSION_FAMILIES.items()]


def _sum_terms(terms):
    return "+".join(terms) if terms else "0"


def _product_sines(axes, frequency="pi"):
    return "*".join(f"sin({frequency}*{axis})" for axis in axes)


def _product_cosines(axes, frequency="2*pi"):
    return "*".join(f"cos({frequency}*{axis})" for axis in axes)


def get_dimension_template(family, dimension, *, variable_coefficients=False):
    """Build a transparent 1-D to 3-D input template for a V6-passing family.

    The dimensional extensions are structural examples, not numerical audit
    results. Goursat is intrinsically a two-coordinate problem in this catalog.
    """
    if family not in _DIMENSION_FAMILIES:
        raise KeyError("Unknown dimension template family: " + str(family))
    if type(dimension) is not int or dimension not in (1, 2, 3):
        raise ValueError("空间维数只能选择 1、2 或 3。")
    if family == "goursat" and dimension != 2:
        raise ValueError("Goursat 模板需要两个特征坐标；请选择二维。")
    variable_coefficients = bool(variable_coefficients or family in ("variable_elliptic", "black_scholes"))

    axes = ("x", "y", "z")[:dimension]
    time_dependent = family in {
        "heat", "anisotropic_diffusion", "black_scholes", "advection_diffusion",
        "periodic_advection", "reaction_diffusion", "allen_cahn", "nonlinear_diffusion",
        "wave", "telegraph", "klein_gordon", "sine_gordon",
    }
    variables = axes + (("t",) if time_dependent else ())
    domain = {axis: ([0.5, 2.0] if family == "black_scholes" else [0.0, 1.0]) for axis in axes}
    if time_dependent:
        domain["t"] = [0.0, 0.5] if family == "black_scholes" else [0.0, 1.0]
    zero_walls = lambda fields=("u",): _walls(variables, domain, fields=fields)
    product = _product_sines(axes)
    product_periodic = _product_sines(axes, "2*pi")
    coefficient = "(1+" + "+".join(axes) + ")"
    parameters = {}
    conditions = []
    equations = []
    notes = "维度拓展输入模板；该空间维数与该参数组合尚无独立数值误差验证。"

    if family == "heat":
        parameters = {"kappa": 0.1}
        diffusion = (rf"\nabla\cdot(kappa*{coefficient}\nabla u)"
                     if variable_coefficients else rf"kappa\Delta u")
        equations = [rf"u_t-{diffusion}=0"]
        conditions = zero_walls() + [_initial(product)]
    elif family == "poisson":
        source = f"{dimension}*pi**2*({product})"
        operator = rf"\nabla\cdot({coefficient}\nabla u)" if variable_coefficients else rf"\Delta u"
        equations = [rf"-{operator}-({source})=0"]
        conditions = zero_walls()
    elif family == "laplace":
        if variable_coefficients:
            equations = [rf"-\nabla\cdot({coefficient}\nabla u)-1=0"]
            conditions = zero_walls()
        else:
            equations = [r"\Delta u=0"]
            conditions = [_condition(f"{axis}_{side}", {axis: domain[axis][index]}, "u", _sum_terms(list(axes)))
                          for axis in axes for index, side in ((0, "lower"), (1, "upper"))]
    elif family in ("variable_elliptic", "helmholtz", "nonlinear_poisson", "regularized_p_laplace"):
        operator = rf"\nabla\cdot({coefficient}\nabla u)" if variable_coefficients or family == "variable_elliptic" else r"\Delta u"
        if family in ("variable_elliptic", "poisson"):
            equations = [rf"-{operator}-1=0"]
        elif family == "helmholtz":
            parameters = {"k": 1.0}
            equations = [rf"-{operator}-k^2*u-1=0"]
        elif family == "nonlinear_poisson":
            equations = [rf"-{operator}+u^3-1=0"]
        else:
            parameters = {"epsilon": 0.1}
            gradients = [f"u_{axis}" for axis in axes]
            gradient_squared = _sum_terms([f"{gradient}^2" for gradient in gradients])
            metric = f"sqrt(epsilon^2+{gradient_squared})"
            laplace_term = _sum_terms([f"u_{{{axis}{axis}}}" for axis in axes])
            hessian_terms = [f"u_{axis}^2*u_{{{axis}{axis}}}" for axis in axes]
            hessian_terms.extend(
                f"2*u_{axes[i]}*u_{axes[j]}*u_{{{axes[i]}{axes[j]}}}"
                for i in range(dimension) for j in range(i + 1, dimension)
            )
            divergence = f"{metric}*({laplace_term})+({_sum_terms(hessian_terms)})/{metric}"
            if variable_coefficients:
                divergence = f"{coefficient}*({divergence})+{metric}*({_sum_terms(gradients)})"
            equations = [f"-{divergence}-1=0"]
        conditions = zero_walls()
    elif family == "mixed_elliptic":
        parameters = {"rho": 0.1}
        if variable_coefficients:
            diagonal = [rf"\partial_{axis}((1+{axis})u_{axis})" for axis in axes]
        else:
            diagonal = [f"u_{{{axis}{axis}}}" for axis in axes]
        cross = [f"u_{{{axes[i]}{axes[j]}}}" for i in range(dimension) for j in range(i + 1, dimension)]
        equations = ["-" + _sum_terms(diagonal) + ("-2*rho*(" + _sum_terms(cross) + ")" if cross else "") + "-1=0"]
        conditions = zero_walls()
    elif family == "anisotropic_diffusion":
        parameters = {f"a{i + 1}": 1.0 + 0.2 * i for i in range(dimension)}
        if variable_coefficients:
            diffusion_terms = [rf"\partial_{axis}((a{i + 1}+{axis})u_{axis})"
                               for i, axis in enumerate(axes)]
            diffusion = _sum_terms(diffusion_terms)
        else:
            diffusion = _sum_terms([f"a{i + 1}*u_{{{axis}{axis}}}" for i, axis in enumerate(axes)])
        equations = [f"u_t-{diffusion}=0"]
        conditions = zero_walls() + [_initial(product)]
    elif family == "black_scholes":
        parameters = {"r": 0.05, **{f"sigma{i + 1}": 0.2 for i in range(dimension)}}
        for i in range(dimension):
            for j in range(i + 1, dimension):
                parameters[f"rho{i + 1}{j + 1}"] = 0.15
        terms = ["u_t"]
        rate = (2 * dimension - 1) * parameters["r"]
        for i, axis in enumerate(axes):
            sigma = parameters[f"sigma{i + 1}"]
            terms.append(f"-0.5*sigma{i + 1}^2*{axis}^2*u_{{{axis}{axis}}}")
            terms.append(f"-r*{axis}*u_{axis}")
            rate += sigma ** 2
        for i in range(dimension):
            for j in range(i + 1, dimension):
                rho = parameters[f"rho{i + 1}{j + 1}"]
                terms.append(f"-rho{i + 1}{j + 1}*sigma{i + 1}*sigma{j + 1}*{axes[i]}*{axes[j]}*u_{{{axes[i]}{axes[j]}}}")
                rate += 4 * rho * parameters[f"sigma{i + 1}"] * parameters[f"sigma{j + 1}"]
        terms.append("+r*u")
        equations = ["".join(terms) + "=0"]
        conditions = [_initial("*".join(f"{axis}**2" for axis in axes))]
        for axis in axes:
            for index, side in ((0, "lower"), (1, "upper")):
                conditions.append(_condition(f"{axis}_{side}", {axis: domain[axis][index]}, "u",
                                             f"exp({rate:.10g}*t)*" + "*".join(f"{name}**2" for name in axes)))
        notes = "多资产 Black–Scholes 光滑幂函数输入模板；该维数的 PINN 误差尚无独立审计。"
    elif family in ("advection_diffusion", "periodic_advection"):
        parameters = {}
        velocity = []
        for i, axis in enumerate(axes):
            parameters[f"c{i + 1}"] = 0.5
            speed = f"c{i + 1}"
            if variable_coefficients:
                speed = f"({speed}+0.1*sin(2*pi*{axis}))"
            velocity.append(f"{speed}*u_{axis}")
        if family == "periodic_advection":
            equations = ["u_t+" + _sum_terms(velocity) + "=0"]
            conditions = [_periodic(axis, domain, order=1)[0] for axis in axes] + [_initial(product_periodic)]
        else:
            parameters.update({f"nu{i + 1}": 0.05 for i in range(dimension)})
            if variable_coefficients:
                diffusivity = rf"nu1*{coefficient}"
                diffusion = rf"\nabla\cdot({diffusivity}\nabla u)"
            else:
                diffusion = _sum_terms([f"nu{i + 1}*u_{{{axis}{axis}}}" for i, axis in enumerate(axes)])
            equations = ["u_t+" + _sum_terms(velocity) + "-" + diffusion + "=0"]
            conditions = [condition for axis in axes for condition in _periodic(axis, domain, order=2)] + [_initial(product_periodic)]
    elif family in ("reaction_diffusion", "allen_cahn", "nonlinear_diffusion"):
        if family == "reaction_diffusion":
            parameters = {"D": 0.1, "r": 1.0}
            diffusion = rf"\nabla\cdot(D*{coefficient}\nabla u)" if variable_coefficients else r"D\Delta u"
            equations = [rf"u_t-{diffusion}+r*u=0"]
            conditions = zero_walls() + [_initial(product)]
        elif family == "allen_cahn":
            parameters = {"epsilon": 0.05}
            diffusion = rf"\nabla\cdot(epsilon^2*{coefficient}\nabla u)" if variable_coefficients else rf"epsilon^2\Delta u"
            equations = [rf"u_t-{diffusion}+u^3-u=0"]
            conditions = [condition for axis in axes for condition in _periodic(axis, domain, order=2)] + [_initial("0.2*" + _product_cosines(axes))]
        else:
            flux = f"{coefficient}*(1+u^2)" if variable_coefficients else "(1+u^2)"
            equations = [rf"u_t-\nabla\cdot({flux}\nabla u)=0"]
            conditions = [condition for axis in axes for condition in _periodic(axis, domain, order=2)] + [_initial("0.2*" + _product_cosines(axes))]
    elif family in ("wave", "telegraph", "klein_gordon", "sine_gordon"):
        if family == "telegraph":
            parameters = {"c": 1.0, "alpha": 0.5}
            spatial_operator = (rf"\nabla\cdot(c^2*{coefficient}\nabla u)" if variable_coefficients
                               else rf"c^2\Delta u")
            equations = [rf"u_{{tt}}+alpha*u_t-{spatial_operator}=0"]
        elif family == "klein_gordon":
            parameters = {"c": 1.0, "m": 1.0}
            spatial_operator = (rf"\nabla\cdot(c^2*{coefficient}\nabla u)" if variable_coefficients
                               else rf"c^2\Delta u")
            equations = [rf"u_{{tt}}-{spatial_operator}+m^2*u=0"]
        elif family == "sine_gordon":
            parameters = {"c": 1.0}
            spatial_operator = (rf"\nabla\cdot(c^2*{coefficient}\nabla u)" if variable_coefficients
                               else r"c^2\Delta u")
            equations = [rf"u_{{tt}}-{spatial_operator}+sin(u)=0"]
        else:
            parameters = {"c": 1.0}
            spatial_operator = (rf"\nabla\cdot(c^2*{coefficient}\nabla u)" if variable_coefficients
                               else rf"c^2\Delta u")
            equations = [rf"u_{{tt}}-{spatial_operator}=0"]
        conditions = zero_walls() + [_initial(product), _condition("initial_velocity", {"t": 0.0}, "u_t")]
    elif family == "goursat":
        coefficient_xy = "(1+x+y)" if variable_coefficients else "1"
        equations = [f"{coefficient_xy}*u_{{xy}}-u=0"]
        conditions = [_condition("x_axis", {"y": 0.0}, target="1"),
                      _condition("y_axis", {"x": 0.0}, target="1")]
    else:
        raise ValueError("该方程族尚未实现维度模板。")

    variable_label = "空间变系数" if variable_coefficients else "常空间系数"
    label = f"{_DIMENSION_FAMILIES[family]}（{dimension}D，{variable_label}）"
    return {
        "id": f"dimension_{family}_{dimension}d_{'variable' if variable_coefficients else 'constant'}",
        "label": label,
        "family": family,
        "variables": list(variables),
        "fields": ["u"],
        "domain": domain,
        "parameters": parameters,
        "latex_equations": [equation if "=" in equation else equation + "=0" for equation in equations],
        "conditions": conditions,
        "branches": [],
        "support_status": "unvalidated_dimension_extension_input_template",
        "numerically_validated": False,
        "spatial_dimension": dimension,
        "variable_coefficients": bool(variable_coefficients),
        "wellposedness_notes": notes,
    }


def list_templates():
    """Metadata for editable examples; no template implies solve success."""
    return [{key: copy.deepcopy(value) for key, value in template.items()
             if key in ("id", "label", "family", "variables", "fields", "support_status", "numerically_validated", "wellposedness_notes")}
            for template in _TEMPLATES.values()]


def get_template(identifier):
    try:
        return copy.deepcopy(_TEMPLATES[identifier])
    except KeyError:
        raise KeyError("Unknown editable PDE template: " + str(identifier)) from None


def coverage_matrix():
    """Structural interface coverage, deliberately separate from accuracy."""
    return [
        {"structure": "finite_local_integer_derivatives", "expression_support": "up_to_order_6", "validation": "only_named_frozen_cases"},
        {"structure": "scalar_linear_semilinear_quasilinear_fully_nonlinear", "expression_support": "restricted_safe_ast", "validation": "not_every_equation"},
        {"structure": "real_coupled_systems", "expression_support": "1_to_4_fields_1_to_4_coordinates", "validation": "new_system_templates_unvalidated"},
        {"structure": "divergence_and_local_differential_operators", "expression_support": "expanded_by_latex_frontend", "validation": "parsing_is_not_numerical_validation"},
        {"structure": "scalar_spatial_dimensions", "expression_support": "1_to_3_space_coordinates_optional_time", "validation": "generated_dimension_templates_are_unvalidated_extensions"},
        {"structure": "coordinate_dependent_coefficients", "expression_support": "explicit_safe_expressions_and_divergence_product_rule", "validation": "only_named_frozen_cases_have_accuracy_audits"},
        {"structure": "periodic_and_mixed_operator_conditions", "expression_support": "explicit_paired_periodic_or_local_conditions", "validation": "wellposedness_not_automatic"},
        {"structure": "prescribed_point_and_distributed_time_delay", "expression_support": "experimental_v8_structured_operators", "validation": "no_independent_accuracy_audit"},
        {"structure": "fractional_integral_and_other_nonlocal_operators", "expression_support": "unsupported", "validation": "none"},
        {"structure": "general_nonbox_geometry_native_complex_full_3d_maxwell", "expression_support": "unsupported", "validation": "none"},
    ]
