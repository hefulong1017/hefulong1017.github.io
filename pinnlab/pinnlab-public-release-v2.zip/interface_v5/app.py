"""Presentation fixes over the frozen numerical V5 experiment.

This module changes result wording only. The frozen solver, configuration,
models, and original interface remain byte-for-byte reproducible.
"""
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from research_v5 import app as numerical_app

st = numerical_app.st


def _result_header(bundle):
    result = bundle['result']
    st.subheader('2 · 求解前检查')
    numerical_app._show_analysis(bundle['analysis'])
    if result is None:
        return
    st.subheader('3 · 数值结果')
    st.caption(f"当前展示的是已计算输入：{result.problem['name']}。修改输入后需再次点击“开始数值求解”。")
    status_text = numerical_app.STATUS_TEXT.get(result.status, result.status)
    if result.status == 'physics_and_correction_tolerance' and not result.config.stability_control:
        status_text = '采样物理检查达标（未启用函数修正停止检查）'
    columns = st.columns(4)
    columns[0].metric('计算状态', status_text)
    columns[1].metric('独立点分数', f"{result.diagnostics['guard_score']:.3e}")
    columns[2].metric('函数数量', str(result.bank.size))
    columns[3].metric('求解耗时', f'{result.seconds:.2f} 秒')
    extra = st.columns(3)
    extra[0].metric('估计函数修正量', f"{result.diagnostics['function_correction_proxy']:.3e}")
    gain = result.diagnostics['guard_stability']['inverse_gain']
    extra[1].metric('离散逆敏感性', f'{gain:.3e}' if gain is not None else '不可可靠估计')
    extra[2].metric('当前线性化可辨识', '是' if result.diagnostics['discrete_stability_reliable'] else '否')
    if result.status == 'physics_and_correction_tolerance':
        st.success(status_text + '。可以查看、查询和导出当前数值候选。')
    else:
        st.warning('本次尚未满足全部停止条件，下面展示当前候选；请勿将其视为已验证的方程解。搜索停滞或时间用尽都不等于证明无解。')
    st.warning('采样检查仅针对有限点、当前函数空间及其线性化。启用函数修正停止检查时，还要求修正量与可辨识性达标；关闭时不使用这道停止门。这些检查不是逐点解误差、存在性或唯一性证明。边界消元也只针对所用函数与采样条件。')
    st.caption('本方法通过物理残差拟合神经/结构化特征的读出系数，特征由候选规则选择；当前实现不进行全参数深层网络训练。参考解不参与训练；本界面没有用私有精确解评价来挑选模型。')


numerical_app._result_header = _result_header

if __name__ == '__main__':
    numerical_app.main()
