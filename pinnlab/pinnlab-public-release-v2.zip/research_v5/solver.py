"""Function-metric neural corrections, physical-scale proposals and jet fallback.

Discrete sensitivity controls stopping; it is not a global PDE error bound.
Every fitted readout coefficient is determined from physical equations/data.
"""
from __future__ import annotations
from dataclasses import dataclass,asdict
import json
from pathlib import Path
import time
import numpy as np
import torch
from scipy import linalg
from threadpoolctl import threadpool_limits

from research_v4.solver import (SolverConfig as BaseConfig,Block as BaseBlock,
    System as BaseSystem,Result as BaseResult,points,_direction_candidates,
    _response_step,_birth_pool)
from research_v4.spec import Formula,validate_problem
from research_v4.admission import analyze as classical_analyze
from .features import V5Bank,propose,_descriptor_key
from .structured_modes import structured_proposals
from .stability import linearized_stability


@dataclass
class SolverConfig(BaseConfig):
    max_features: int=96
    candidate_limit: int=32
    max_frequency: int=48
    budget_seconds: float=20.
    value_tolerance: float=1e-6
    informed_features: bool=True
    stability_control: bool=True
    max_initial_informed: int=64
    jacobian_rtol: float=1e-13
    mass_rtol: float=1e-12

    def validate(self):
        super().validate()
        if not np.isfinite(self.value_tolerance) or self.value_tolerance<=0: raise ValueError('Positive value_tolerance required.')
        if type(self.max_initial_informed) is not int or not 0<=self.max_initial_informed<=64: raise ValueError('Invalid initial feature budget.')
        for value in (self.jacobian_rtol,self.mass_rtol):
            if not np.isfinite(value) or not 0<value<1: raise ValueError('Invalid SVD threshold.')


def physical_input(problem):
    keys=('name','variables','domain','fields','equations','conditions','branches','parameters')
    p=validate_problem({k:problem[k] for k in keys if k in problem})
    for condition in p['conditions']:
        if condition.get('kind')=='periodic':
            axis=condition.get('pair_axis')
            if axis not in p['variables'] or condition.get('where',{}).get(axis)!=p['domain'][axis][0]:
                raise ValueError('Periodic conditions must specify the lower face of pair_axis.')
    return p


def analyze(problem):
    # The V4 analyzer interprets local endpoint operators. Applying it to a
    # paired difference as though it were a local Dirichlet value is unsound.
    if any(c.get('kind')=='periodic' for c in problem['conditions']):
        return {'incompatible':False,'certificates':[],'symmetries':[],'stability_warnings':[],
                'limitations':['Paired periodic conditions are handled numerically; local endpoint symbolic checks are not applied.']}
    return classical_analyze(problem)


class IncompatibleProblem(ValueError):
    def __init__(self,analysis):
        self.analysis=analysis
        super().__init__('An exact compatibility check proved the supplied classical problem inconsistent; see analysis certificates.')


def _accepted(a,g,c,candidate,cfg):
    try:
        la,lg=a.loss(candidate),g.loss(candidate); olda,oldg=a.loss(c),g.loss(c)
        branch0=max(a.branch_violation(c),g.branch_violation(c))
        branch=max(a.branch_violation(candidate),g.branch_violation(candidate))
        feasible=branch<=cfg.branch_tolerance if branch0<=cfg.branch_tolerance else branch<branch0 or branch<=cfg.branch_tolerance
        margin=64*np.finfo(float).eps
        return feasible and la<olda*(1-margin) and lg<oldg*(1-margin),la,lg,branch
    except (ValueError,FloatingPointError,OverflowError): return False,float('inf'),float('inf'),float('inf')


class Block(BaseBlock):
    def __init__(self,problem,bank,p,operator,target='0',weight=1.,branch=None,scale=None):
        # A zero trial may lie outside log/sqrt/reciprocal domains. A unit
        # normalizer is valid; a separate finite feasible initialization is
        # required before any actual solve. Invalid values are never fitted.
        self.problem,self.bank,self.points=problem,bank,p
        self.formula=Formula(operator,problem['variables'],problem['fields'],problem.get('parameters'))
        rawtarget=Formula(str(target),problem['variables'],problem['fields'],problem.get('parameters'),False)(p,{})
        self.target=np.broadcast_to(rawtarget,(len(p),)).copy()
        self.branch=branch; self.names=sorted(self.formula.jets)
        suffixes={'u'+('_'+n.split('_',1)[1] if '_' in n else '') for n in self.names}
        values=bank.values(p,suffixes)
        self.phi={n:values['u'+('_'+n.split('_',1)[1] if '_' in n else '')] for n in self.names}
        self.indices={n:problem['fields'].index(n.split('_',1)[0]) for n in self.names}
        self.size=bank.size*len(problem['fields'])
        self.domain_deferred=False
        if scale is None:
            try:
                r=self.raw(np.zeros(self.size)); self.normalizer=max(1.,float(np.sqrt(np.mean(r*r))))
            except (FloatingPointError,ValueError,ZeroDivisionError):
                self.normalizer=1.; self.domain_deferred=True
        else: self.normalizer=scale
        self.scale=np.sqrt(weight/len(p))/self.normalizer


class PairBlock:
    """Genuine periodic left/right operator difference, not endpoint values."""
    def __init__(self,problem,bank,p,operator,target,weight,axis,scale=None):
        left=p.copy(); right=p.copy(); index=problem['variables'].index(axis)
        left[:,index],right[:,index]=problem['domain'][axis]
        self.left=Block(problem,bank,left,operator,target,weight,scale=scale)
        self.right=Block(problem,bank,right,operator,'0',weight,scale=self.left.normalizer)
        self.formula=self.left.formula; self.branch=None
        self.normalizer=self.left.normalizer; self.scale=self.left.scale
        self.points=left; self.size=self.left.size
    def raw(self,c,jacobian=False):
        a,b=self.left.raw(c,jacobian),self.right.raw(c,jacobian)
        return (a[0]-b[0],a[1]-b[1]) if jacobian else a-b
    def series(self,c,d,order): return self.left.series(c,d,order)-self.right.series(c,d,order)


class System(BaseSystem):
    def __init__(self,problem,bank,config,seed,guard=False,normalizers=None):
        self.bank,self.problem=bank,problem
        self.blocks=[]; self.condition_blocks=[]; self.branch_blocks=[]
        p=points(problem,config.guard if guard else config.interior,seed)
        self.interior_points=p
        scales=iter(normalizers) if normalizers is not None else None
        def add(operator,target,weight,p,branch=None,pair_axis=None):
            scale=next(scales) if scales is not None else None
            if pair_axis is not None: b=PairBlock(problem,bank,p,operator,target,weight,pair_axis,scale)
            else: b=Block(problem,bank,p,operator,target,weight,branch,scale)
            self.blocks.append(b); return b
        for equation in problem['equations']: add(equation,'0',1.,p)
        self.equation_count=len(self.blocks)
        for i,c in enumerate(problem['conditions']):
            q=points(problem,config.condition_points,seed+100+i,c.get('where',{}))
            pair_axis=c.get('pair_axis') if c.get('kind')=='periodic' else None
            if c.get('kind')=='periodic' and pair_axis not in problem['variables']: raise ValueError('Periodic condition requires a valid pair_axis.')
            self.condition_blocks.append(add(c['operator'],c['target'],config.boundary_weight*c.get('weight',1.),q,pair_axis=pair_axis))
        for b in problem.get('branches',[]):
            kind='min' if 'min' in b else 'max'
            self.branch_blocks.append(add(b['operator'],str(b[kind]),config.branch_weight,p,kind))
        self.normalizers=[b.normalizer for b in self.blocks]

    def value_matrix(self):
        phi=self.bank.values(self.interior_points,['u'])['u']
        return linalg.block_diag(*([phi]*len(self.problem['fields'])))


@dataclass
class Result(BaseResult):
    analysis: dict=None

    def save(self,path):
        path=Path(path); path.mkdir(parents=True,exist_ok=True)
        state={'version':'5.0.0-research','problem':self.problem,'config':asdict(self.config),
               'features':self.bank.features,'coefficients':self.coefficients.tolist(),
               'history':self.history,'status':self.status,'seconds':self.seconds,
               'diagnostics':self.diagnostics,'analysis':self.analysis,'training_uses_reference':False,
               'claim':'discrete_stability_aware_neural_corrections_with_physical_features; novelty_unproven'}
        (path/'model.json').write_text(json.dumps(state,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
        return path


def load(path):
    state=json.loads((Path(path)/'model.json').read_text(encoding='utf-8'))
    p=physical_input(state['problem'])
    bank=V5Bank(p['variables'],[p['domain'][v] for v in p['variables']],features=state['features'])
    return Result(p,SolverConfig(**state['config']),bank,np.asarray(state['coefficients']),
                  state['history'],state['status'],state['seconds'],state['diagnostics'],state.get('analysis'))


def _finite_initial(a,g,c,z,hard):
    trials=[c]
    bank=a.bank; fields=a.problem['fields']
    constant=next((i for i,f in enumerate(bank.features) if f['kind']=='poly' and not any(f['powers'])),None)
    if constant is not None:
        for level in (1.,-1.,.1,10.):
            candidate=np.zeros_like(c)
            for f in range(len(fields)): candidate[f*bank.size+constant]=level
            if hard: candidate=c+z@(z.T@(candidate-c))
            trials.append(candidate)
    for candidate in trials:
        try:
            a.evaluate(candidate,True); g.evaluate(candidate,True)
            return candidate
        except (FloatingPointError,ValueError,ZeroDivisionError): pass
    raise ValueError('Could not construct a finite initial neural field inside all expression domains; no infeasibility conclusion follows.')


def _quotient_tangent(a,z,values,analysis):
    if not analysis or not z.shape[1]: return z,0
    bank=a.bank; constants=[]
    index=next((i for i,f in enumerate(bank.features) if f['kind']=='poly' and not any(f['powers'])),None)
    if index is None: return z,0
    for symmetry in analysis.get('symmetries',[]):
        if symmetry['type']!='constant_shift': continue
        h=np.zeros(z.shape[0]); h[a.problem['fields'].index(symmetry['field'])*bank.size+index]=1.
        # Only remove a symbolically proven gauge which is also a tangent to
        # the supplied sampled conditions. The correction is measured modulo
        # this gauge; unrelated fields must still pass their correction test.
        if np.linalg.norm(h-z@(z.T@h))<=1e-8:
            constants.append(values.T@(values@h)/len(values))
    if not constants: return z,0
    rows=np.array(constants)@z
    q=linalg.null_space(rows,rcond=1e-12)
    return z@q,z.shape[1]-q.shape[1]


def _snapshot(a,g,c,z,cfg,values,analysis=None):
    ra,ja=a.evaluate(c,True); rg,jg=g.evaluate(c,True)
    tangent,removed=_quotient_tangent(a,z,np.vstack(values),analysis)
    kwargs=dict(mass_rtol=cfg.mass_rtol,jacobian_rtol=cfg.jacobian_rtol)
    sa=linearized_stability(ra,ja,values[0],tangent,**kwargs)
    sg=linearized_stability(rg,jg,values[1],tangent,**kwargs)
    return {'train':float(np.linalg.norm(ra)),'guard':float(np.linalg.norm(rg)),
            'branch':max(a.branch_violation(c),g.branch_violation(c)),
            'proxy':max(sa.linearized_error_proxy,sg.linearized_error_proxy),
            'reliable':bool(tangent.shape[1]==0 or sa.reliable and sg.reliable),
            'no_free_discrete_tangent':tangent.shape[1]==0,'gauge_directions_removed':removed,
            'train_stability':sa,'guard_stability':sg}


def _merit(s,cfg):
    score=max(s['train'],s['guard'])/cfg.tolerance
    if cfg.stability_control: score=max(score,s['proxy']/cfg.value_tolerance)
    return score


def solve(problem,config=None,callback=None):
    cfg=config or SolverConfig(); cfg.validate(); p=physical_input(problem)
    started=time.perf_counter(); deadline=started+cfg.budget_seconds if cfg.budget_seconds else None
    def expired(): return deadline is not None and time.perf_counter()>=deadline
    torch.set_num_threads(cfg.threads)
    analysis=analyze(p)
    if analysis['incompatible']: raise IncompatibleProblem(analysis)
    bank=V5Bank(p['variables'],[p['domain'][v] for v in p['variables']],poly_degree=cfg.poly_degree,neural_frequencies=cfg.neural_frequencies)
    informed=(structured_proposals(p,bank)+propose(p,bank)) if cfg.informed_features else []
    added=[]
    for descriptor in informed:
        if len(added)>=cfg.max_initial_informed or bank.size>=cfg.max_features: break
        if _descriptor_key(descriptor) in bank._keys: continue
        bank=bank.append(descriptor); added.append(descriptor)
    if bank.size>cfg.max_features: raise ValueError('Initial feature count exceeds max_features.')
    a=System(p,bank,cfg,cfg.seed); normalizers=a.normalizers
    g=System(p,bank,cfg,cfg.seed+1,True,normalizers)
    c,z,hard=a.boundary_space()
    c=_finite_initial(a,g,c,z,hard)
    values=(a.value_matrix(),g.value_matrix())
    history=[]; births=0; status='iteration_limit'; snapshot=None
    def install(newbank):
        aa=System(p,newbank,cfg,cfg.seed,normalizers=normalizers)
        gg=System(p,newbank,cfg,cfg.seed+1,True,normalizers)
        lift,zz,hh=aa.boundary_space()
        vv=(aa.value_matrix(),gg.value_matrix())
        return aa,gg,lift,zz,hh,vv
    def passed(s):
        return max(s['train'],s['guard'])<=cfg.tolerance and s['branch']<=cfg.branch_tolerance and (
            not cfg.stability_control or s['reliable'] and s['proxy']<=cfg.value_tolerance)
    with threadpool_limits(limits=cfg.threads):
        for step in range(cfg.iterations):
            if expired(): status='budget'; break
            snapshot=_snapshot(a,g,c,z,cfg,values,analysis)
            if passed(snapshot): status='physics_and_correction_tolerance'; break
            record={'step':step,'features':bank.size,'seconds':time.perf_counter()-started,
                    'training_before':snapshot['train'],'guard_before':snapshot['guard'],
                    'function_correction_before':snapshot['proxy'],'stability_reliable':snapshot['reliable'],
                    'births':births,'action':'no_accepted_direction'}
            history.append(record); accepted=False
            direction=snapshot['train_stability'].correction
            for k in range(14):
                if expired() or not np.any(direction): break
                candidate=c+2.**(-k)*direction
                okay,la,lg,bv=_accepted(a,g,c,candidate,cfg)
                if okay:
                    c=candidate; record.update(action='function_metric_correction',training_after=la,guard_after=lg,damping=2.**(-k))
                    accepted=True; break
            if not accepted and cfg.response_search and not expired():
                best=None
                for d in _direction_candidates(z,bank,p['fields'],cfg.seed+step):
                    if expired(): break
                    trial=_response_step(a,g,c,d,cfg,deadline)
                    if trial is not None and (best is None or trial['guard']<best['guard']): best=trial
                    if best is not None and best['guard']<=cfg.tolerance: break
                if best is not None:
                    c=best.pop('coefficients'); record.update(action='high_order_response',**best); accepted=True
            if not accepted and cfg.allow_birth and births<cfg.max_births and bank.size<cfg.max_features and not expired():
                pool=_birth_pool(bank,cfg.candidate_limit,cfg.max_frequency)
                best=None
                for index,descriptor in enumerate(pool):
                    if expired(): break
                    newbank=bank.append(descriptor); born=[descriptor]
                    aa,gg,lift,zz,hh,vv=install(newbank)
                    if hh and not zz.shape[1]:
                        for extra in pool[index+1:index+5]:
                            if newbank.size>=cfg.max_features or expired(): break
                            newbank=newbank.append(extra); born.append(extra)
                            aa,gg,lift,zz,hh,vv=install(newbank)
                            if zz.shape[1]: break
                    padded=np.c_[c.reshape(len(p['fields']),bank.size),np.zeros((len(p['fields']),newbank.size-bank.size))].ravel()
                    base=lift+zz@(zz.T@(padded-lift)) if hh else padded
                    try: state=_snapshot(aa,gg,base,zz,cfg,vv,analysis)
                    except (FloatingPointError,ValueError,ZeroDivisionError): continue
                    proposals=[(base,'condition_projection')]
                    delta=state['train_stability'].correction
                    proposals.extend((base+2.**(-k)*delta,'function_metric_refit') for k in range(6))
                    for candidate,kind in proposals:
                        if expired(): break
                        okay,la,lg,bv=_accepted(aa,gg,padded,candidate,cfg)
                        if okay:
                            state2=_snapshot(aa,gg,candidate,zz,cfg,vv,analysis)
                            merit=_merit(state2,cfg)
                            if best is None or merit<best[0]:
                                best=(merit,candidate,newbank,aa,gg,zz,hh,vv,born,kind,state2)
                            if passed(state2): break
                    if best is not None and passed(best[-1]): break
                if best is not None:
                    _,c,bank,a,g,z,hard,values,born,kind,state=best; births+=1
                    record.update(action='feature_extension',features_added=born,proposal=kind,
                                  guard_after=state['guard'],function_correction_after=state['proxy'])
                    accepted=True
            if callback: callback(record)
            if not accepted:
                status='budget' if expired() else 'inconclusive'; break
        snapshot=_snapshot(a,g,c,z,cfg,values,analysis)
        if passed(snapshot): status='physics_and_correction_tolerance'
        elif expired(): status='budget'
    seconds=time.perf_counter()-started
    diagnostics={'training_score':snapshot['train'],'guard_score':snapshot['guard'],
                 'max_branch_violation':snapshot['branch'],'function_correction_proxy':snapshot['proxy'],
                 'discrete_stability_reliable':snapshot['reliable'],
                 'proven_constant_gauges_removed_in_sensitivity':snapshot['gauge_directions_removed'],
                 'no_free_discrete_tangent':snapshot['no_free_discrete_tangent'],
                 'training_stability':snapshot['train_stability'].to_dict(),
                 'guard_stability':snapshot['guard_stability'].to_dict(),
                 'initial_informed_features':added,'features':bank.size,'births':births,
                 'condition_eliminated_at_sample_points':hard,'budget_seconds':cfg.budget_seconds,
                 'budget_exceeded':bool(cfg.budget_seconds and seconds>cfg.budget_seconds),
                 'budget_overrun_seconds':max(0.,seconds-cfg.budget_seconds) if cfg.budget_seconds else 0.,
                 'training_uses_reference':False,
                 'interpretation':'Function correction and inverse gain are discrete local diagnostics, not global solution error certificates.'}
    return Result(p,cfg,bank,c,history,status,seconds,diagnostics,analysis)
