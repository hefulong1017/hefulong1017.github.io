"""Legacy-catalog physical adapters and predictor-only independent audits.

catalog_problem() never constructs a reference or imports a training routine.
References are accessed only by audit_catalog(), after a predictor exists.
Periodic conditions retain explicit paired-point semantics.
"""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
from typing import Callable

import numpy as np
from scipy.stats import qmc
import yaml

from pinnlab.catalog import get_case, list_cases
from research_v4.spec import Formula, validate_problem


AUDIT_THRESHOLDS = {
    "equation_rmse": 1e-4, "equation_max_abs": 1e-3,
    "condition_rmse": 1e-5, "condition_max_abs": 1e-4,
    "branch_max_violation": 1e-6,
    "relative_l2": 1e-3, "normalized_max_abs_error": 1e-2,
}


def _canonical_family(family: str) -> str:
    # Same accounting as the old audited suite, without importing its trainers.
    return "poisson" if family == "laplace" else family


def _read_source(case_id: str) -> dict:
    case = get_case(case_id)  # Exact lookup; no path interpolation from user input.
    source = yaml.safe_load(case.problem_path.read_text(encoding="utf-8"))
    if not isinstance(source, dict):
        raise ValueError("Catalog YAML must contain a mapping.")
    return source


def catalog_cases() -> list[dict]:
    """Fresh metadata only; cases and canonical families must be counted apart."""
    return [{
        "id": case.id, "label": case.label, "family": case.family,
        "canonical_family": _canonical_family(case.family),
        "variables": list(case.variables), "manufactured": case.manufactured,
        "source_free": case.source_free, "notes": case.notes,
        "expected_outcome": "unique",
        "expectation_interpretation": "Catalog reference branch; not a proof of PDE uniqueness.",
    } for case in list_cases()]


def _condition(raw: dict, variables: list[str], domain: dict, fields: list[str], index: int) -> dict:
    if not isinstance(raw, dict):
        raise ValueError("Each condition must be a mapping.")
    where = copy.deepcopy(raw.get("where"))
    if not isinstance(where, dict) or not where:
        raise ValueError("A condition needs nonempty fixed coordinates.")
    for axis, value in where.items():
        if axis not in variables or type(value) not in (int, float) or not np.isfinite(value):
            raise ValueError("Invalid condition coordinate.")
        if not domain[axis][0] <= value <= domain[axis][1]:
            raise ValueError("Condition coordinate outside domain.")
    field = raw.get("field", fields[0])
    if field not in fields:
        raise ValueError("Unknown condition field.")
    legacy_type = raw.get("type")
    kind = raw.get("kind", legacy_type or "operator")
    kind = {"dirichlet": "operator", "value": "operator", "initial": "operator"}.get(kind, kind)
    operator = raw.get("operator")
    if kind == "derivative":
        derivative = raw.get("derivative")
        if operator is None:
            if not isinstance(derivative, str) or not derivative:
                raise ValueError("Derivative condition needs an operator or derivative suffix.")
            operator = derivative if derivative.startswith(field + "_") else field + "_" + derivative
        kind = "operator"
    elif isinstance(kind, str) and kind.startswith(field + "_") and operator is None:
        operator, kind = kind, "operator"
    elif kind == "neumann":
        if len(where) != 1:
            raise ValueError("Neumann data must be specified on one boundary face.")
        axis, position = next(iter(where.items()))
        if axis == "t" or position not in domain[axis]:
            raise ValueError("Neumann data requires a spatial endpoint.")
        # Old Problem.condition_operator uses outward normal, including left -.
        sign = -1 if position == domain[axis][0] else 1
        operator = str(sign) + "*" + field + "_" + axis
        kind = "operator"
    elif kind not in ("operator", "periodic"):
        raise ValueError("Unsupported condition kind/type: " + str(kind))
    if operator is None:
        operator = field
    target = raw.get("target", raw.get("value", "0"))
    if type(target) in (int, float):
        if not np.isfinite(target):
            raise ValueError("Condition target must be finite.")
        target = str(target)
    if not isinstance(operator, str) or not isinstance(target, str):
        raise ValueError("Condition operator/target must be expressions.")
    result = {"name": str(raw.get("name") or "condition_" + str(index)),
              "where": where, "operator": operator, "target": target}
    weight = raw.get("weight", 1.0)
    if type(weight) not in (int, float) or not np.isfinite(weight) or weight <= 0:
        raise ValueError("Condition weight must be positive and finite.")
    result["weight"] = weight
    if kind == "periodic":
        axis = raw.get("pair_axis")
        if axis not in variables or where.get(axis) != domain[axis][0]:
            raise ValueError("Periodic data needs pair_axis at its lower endpoint.")
        result.update(kind="periodic", pair_axis=axis)
    return result


def _physical_problem(source: dict, case_id: str | None = None) -> dict:
    """Whitelist physical fields; discard reference and all evaluation metadata."""
    if not isinstance(source, dict):
        raise ValueError("Problem source must be a mapping.")
    variables = copy.deepcopy(source.get("variables"))
    domain = copy.deepcopy(source.get("domain"))
    fields = copy.deepcopy(source.get("fields", ["u"]))
    if not isinstance(variables, list) or not isinstance(domain, dict) or not isinstance(fields, list) or not fields:
        raise ValueError("Invalid coordinates/domain/fields.")
    if set(domain) != set(variables):
        raise ValueError("Domain keys must match variables.")
    equations = copy.deepcopy(source.get("equations"))
    if equations is None:
        residual = source.get("residual")
        if not isinstance(residual, str):
            raise ValueError("Provide residual or equations.")
        equations = [residual]
    if not isinstance(equations, list) or not all(isinstance(e, str) for e in equations):
        raise ValueError("Equations must be a list of expressions.")
    raw_conditions = source.get("conditions")
    if not isinstance(raw_conditions, list):
        raise ValueError("Provide a condition list.")
    result = {
        "name": str(source.get("name") or case_id or "catalog_problem"),
        "variables": variables, "domain": domain, "fields": fields,
        "equations": equations,
        "parameters": copy.deepcopy(source.get("parameters", {})),
        "conditions": [_condition(c, variables, domain, fields, i) for i, c in enumerate(raw_conditions)],
    }
    names = [c["name"] for c in result["conditions"]]
    if len(set(names)) != len(names):
        raise ValueError("Condition names must be unique.")
    branches = []
    for raw in source.get("branches", []):
        if not isinstance(raw, dict):
            raise ValueError("Branch must be a mapping.")
        branch = {k: copy.deepcopy(raw[k]) for k in ("name", "operator", "min", "max") if k in raw}
        for bound in ("min", "max"):
            if bound in branch and (type(branch[bound]) not in (int, float) or not np.isfinite(branch[bound])):
                raise ValueError("Branch bounds must be finite real numbers.")
        branches.append(branch)
    if case_id == "monge_ampere":
        # The catalog explicitly specifies the convex branch in its metadata.
        # These inequalities depend on the PDE and requested branch, not truth.
        branches.extend([
            {"name": "convex_x", "operator": "u_xx", "min": 0.0},
            {"name": "convex_y", "operator": "u_yy", "min": 0.0},
            {"name": "convex_determinant", "operator": "u_xx*u_yy-u_xy**2", "min": 0.0},
        ])
    if branches:
        result["branches"] = branches
    return validate_problem(result)


def catalog_problem(case_id: str) -> dict:
    """V4-shaped physical input only; periodic kind/pair_axis must be honored.

    A backend that lacks paired-point conditions must reject them explicitly;
    interpreting them as local value constraints changes the physical problem.
    """
    return _physical_problem(_read_source(case_id), case_id)


def _points(problem: dict, count: int, seed: int, where: dict | None = None) -> np.ndarray:
    bounds = np.array([problem["domain"][v] for v in problem["variables"]], dtype=float)
    unit = qmc.Sobol(len(bounds), scramble=True, seed=seed).random_base2(
        int(np.ceil(np.log2(count))))[:count]
    points = bounds[:, 0] + unit * (bounds[:, 1] - bounds[:, 0])
    for axis, value in (where or {}).items():
        points[:, problem["variables"].index(axis)] = value
    return points


def _request(predictor: Callable, points: np.ndarray, names: set[str], fields: list[str]) -> dict:
    values = predictor(points, derivatives=tuple(sorted(names - set(fields))))
    if not isinstance(values, dict):
        raise TypeError("Predictor must return a dictionary of field and requested derivative arrays.")
    answer = {}
    for name in set(fields) | names:
        if name not in values:
            raise KeyError("Predictor omitted " + name)
        array = np.asarray(values[name], dtype=float)
        if array.shape == (len(points), 1):
            array = array[:, 0]
        if array.shape != (len(points),):
            raise ValueError("Invalid predictor shape for " + name)
        if not np.isfinite(array).all():
            raise FloatingPointError("Non-finite predictor values for " + name)
        answer[name] = array
    return answer


def _formula(text: str, problem: dict, fields: bool = True) -> Formula:
    return Formula(text, problem["variables"], problem["fields"], problem.get("parameters"), fields)


def _evaluate(formula: Formula, points: np.ndarray, jets: dict) -> np.ndarray:
    with np.errstate(over="raise", invalid="raise", divide="raise"):
        value = np.asarray(formula(points, jets), dtype=float)
        value = np.broadcast_to(value, (len(points),))
        if not np.isfinite(value).all():
            raise FloatingPointError("Non-finite audit expression.")
    return value


def _metrics(error: np.ndarray) -> dict:
    with np.errstate(over="raise", invalid="raise", divide="raise"):
        return {"rmse": float(np.sqrt(np.mean(error * error))),
                "max_abs": float(np.max(np.abs(error)))}


def _reference_metrics(value: np.ndarray, truth: np.ndarray) -> dict:
    with np.errstate(over="raise", invalid="raise", divide="raise"):
        delta = value - truth
        norm = float(np.linalg.norm(truth))
        metrics = {"relative_l2": float(np.linalg.norm(delta) / max(norm, 1e-14)),
                   "rmse": float(np.sqrt(np.mean(delta * delta))),
                   "max_abs_error": float(np.max(np.abs(delta))),
                   "normalized_max_abs_error": float(np.max(np.abs(delta)) / max(1.0, float(np.max(np.abs(truth))))),
                   "reference_max_abs": float(np.max(np.abs(truth)))}
        if not all(np.isfinite(v) for v in metrics.values()):
            raise FloatingPointError("Non-finite reference error metrics.")
    return metrics


def _reference(case_id: str):
    """Use the legacy verified analytic/numeric path only within the audit."""
    from pinnlab.catalog import load_problem
    from pinnlab.references import Reference

    source = _read_source(case_id)
    specification = source.get("reference") or {}
    kind = specification.get("kind") if isinstance(specification, dict) else None
    if kind not in ("analytic", "burgers_cole_hopf", "burgers_fd"):
        raise ValueError("No supported independent reference; reference.kind=" + repr(kind))
    # Reference checks analytic consistency or numeric quadrature refinement.
    # No cache directory is passed, so this audit never changes legacy files.
    return Reference(load_problem(case_id))


def audit_catalog(case_id: str, predictor: Callable, count: int = 8192, seed: int = 20261112) -> dict:
    """Audit a frozen predictor on fresh points, without fitting or feature access.

    Physical gates, reference error and the catalog branch must all pass.
    An unsupported/unavailable numeric reference remains an explicit failure
    to certify accuracy; it is never substituted with an analytic expression.
    """
    if type(count) is not int or not 32 <= count <= 262144:
        raise ValueError("Audit count must be an integer in [32,262144].")
    if type(seed) is not int or not 0 <= seed < 2**31 - 2048:
        raise ValueError("Audit seed must be an integer in [0,2**31-2048).")
    if not callable(predictor):
        raise TypeError("Provide a predictor callable.")
    problem = catalog_problem(case_id)
    metadata = next(c for c in catalog_cases() if c["id"] == case_id)
    source_bytes = get_case(case_id).problem_path.read_bytes()
    result = {
        "id": case_id, "family": metadata["family"], "canonical_family": metadata["canonical_family"],
        "expected_outcome": "unique", "expectation_interpretation": metadata["expectation_interpretation"],
        "count": count, "seed": seed, "accepted_solution": False, "accepted_accuracy": False,
        "successful_handling": False, "physics_consistent": False,
        "reference_errors": None, "reference": None, "reference_error": None,
        "equations": [], "conditions": {}, "branches": {}, "audit_error": None,
        "thresholds": dict(AUDIT_THRESHOLDS), "training_uses_reference": False,
        "source_yaml_sha256": hashlib.sha256(source_bytes).hexdigest(),
        "physical_input_sha256": hashlib.sha256(json.dumps(problem, sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
        "interpretation": "Independent finite-point diagnostics, not a global error, existence or uniqueness certificate.",
    }
    points = _points(problem, count, seed)
    result["points_sha256"] = hashlib.sha256(points.tobytes()).hexdigest()
    values = None
    try:
        equations = [_formula(e, problem) for e in problem["equations"]]
        branches = [(_formula(b["operator"], problem), b) for b in problem.get("branches", [])]
        names = set().union(*(e.jets for e in equations), *(e.jets for e, _ in branches))
        values = _request(predictor, points, names, problem["fields"])
        result["equations"] = [_metrics(_evaluate(e, points, values)) for e in equations]
        for index, condition in enumerate(problem["conditions"]):
            p = _points(problem, min(count, 512), seed + 100 + index, condition["where"])
            operator, target = _formula(condition["operator"], problem), _formula(condition["target"], problem, False)
            jets = _request(predictor, p, operator.jets, problem["fields"])
            error = _evaluate(operator, p, jets)
            if condition.get("kind") == "periodic":
                paired = p.copy()
                axis = problem["variables"].index(condition["pair_axis"])
                paired[:, axis] = problem["domain"][condition["pair_axis"]][1]
                right = _request(predictor, paired, operator.jets, problem["fields"])
                error = error - _evaluate(operator, paired, right)
            error = error - _evaluate(target, p, {})
            result["conditions"][condition["name"]] = {
                **_metrics(error), "kind": condition.get("kind", "operator"), "count": len(p)}
        for index, (formula, branch) in enumerate(branches):
            value = _evaluate(formula, points, values)
            violation = (np.maximum(float(branch["min"]) - value, 0.0) if "min" in branch
                         else np.maximum(value - float(branch["max"]), 0.0))
            result["branches"][branch.get("name", "branch_" + str(index))] = {
                "minimum": float(np.min(value)), "maximum": float(np.max(value)),
                "max_violation": float(np.max(violation))}
        if case_id == "monge_ampere":
            a, d, b = values["u_xx"], values["u_yy"], values["u_xy"]
            minimum = float(np.min(0.5 * (a + d - np.sqrt((a - d)**2 + 4*b*b))))
            result["minimum_hessian_eigenvalue"] = minimum
            result["convex_branch_pass"] = minimum > 1e-8
        gates = AUDIT_THRESHOLDS
        physics = (
            all(m["rmse"] <= gates["equation_rmse"] and m["max_abs"] <= gates["equation_max_abs"]
                for m in result["equations"])
            and all(m["rmse"] <= gates["condition_rmse"] and m["max_abs"] <= gates["condition_max_abs"]
                    for m in result["conditions"].values())
            and all(m["max_violation"] <= gates["branch_max_violation"] for m in result["branches"].values())
            and result.get("convex_branch_pass", True))
        result["physics_consistent"] = bool(physics)
    except Exception as exc:
        result["audit_error"] = type(exc).__name__ + ": " + str(exc)
    if values is not None:
        try:
            reference = _reference(case_id)
            result["reference"] = copy.deepcopy(reference.metadata)
            truth = np.asarray(reference(points), dtype=float).reshape(-1)
            if truth.shape != (len(points),) or not np.isfinite(truth).all():
                raise FloatingPointError("Invalid independent reference values.")
            if problem["fields"] != ["u"]:
                raise ValueError("The legacy reference API is scalar; multi-field reference audit is unsupported.")
            result["reference_errors"] = _reference_metrics(values["u"], truth)
        except Exception as exc:
            result["reference_error"] = type(exc).__name__ + ": " + str(exc)
    reference_pass = (
        result["reference_errors"] is not None
        and result["reference_errors"]["relative_l2"] <= AUDIT_THRESHOLDS["relative_l2"]
        and result["reference_errors"]["normalized_max_abs_error"] <= AUDIT_THRESHOLDS["normalized_max_abs_error"])
    accepted = bool(result["audit_error"] is None and result["physics_consistent"] and reference_pass)
    result.update(accepted_solution=accepted, accepted_accuracy=accepted, successful_handling=accepted)
    return result
