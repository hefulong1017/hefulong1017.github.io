"""Discrete linearized sensitivity in a sampled function L2 metric.

This module uses no PDE labels or reference solutions. It reports properties
of supplied matrices at supplied points. None of its numbers is a continuous
PDE error certificate, an existence result, or a guarantee for a nonlinear step.
In particular, a small condition number can coexist with a huge inverse gain.
"""
from __future__ import annotations

from dataclasses import dataclass, fields
import math

import numpy as np
from scipy import linalg


@dataclass
class StabilityReport:
    """Matrices' local correction and conditional sensitivity diagnostics.

    ``correction`` uses the original coefficient coordinates. It minimizes the
    weighted linearized residual in the *value-resolved* tangent space, choosing
    minimum sampled-function norm among its least-squares solutions. When a
    value-null direction changes the residual, that space is incomplete and
    ``reliable`` is false. No ridge term is added.

    ``sigma_min`` is zero and ``inverse_gain`` is infinite if not every observed
    function direction is identifiable, or if the sampled value metric fails
    to determine the linearized residual. ``to_dict`` converts infinity to
    JSON null and supplies explicit unbounded/invalid flags.
    """

    correction: np.ndarray
    value_correction: np.ndarray
    linearized_residual: np.ndarray
    weighted_linearized_residual: np.ndarray
    function_correction_norm: float
    residual_norm_before: float
    remaining_residual_norm: float
    relative_remaining_residual: float
    sigma_min: float
    sigma_max: float
    smallest_retained_singular_value: float
    inverse_gain: float
    condition_number: float
    identifiable_rank: int
    function_rank: int
    coefficient_dimension: int
    tangent_dimension: int
    mass_nullity: int
    jacobian_nullity: int
    mass_null_residual_coupling: float
    mass_null_coupling_relative: float
    redundancy_consistent: bool
    identifiable: bool
    reliable: bool
    status: str
    warnings: list[str]
    singular_values: np.ndarray
    mass_singular_values: np.ndarray
    mass_rank_threshold: float
    jacobian_rank_threshold: float
    normal_equation_defect: float

    @property
    def linearized_error_proxy(self):
        """Sampled L2 size of the proposed correction, not a true error."""
        return self.function_correction_norm

    @property
    def inverse_gain_residual_proxy(self):
        """Conditional discrete gain times residual; undefined when unreliable."""
        if not self.reliable:
            return math.inf
        return self.inverse_gain * self.residual_norm_before

    def to_dict(self, include_arrays=False):
        """Produce strict-JSON-compatible diagnostics; arrays are opt-in."""
        answer = {}
        for field in fields(self):
            value = getattr(self, field.name)
            if isinstance(value, np.ndarray):
                if not include_arrays:
                    continue
                value = value.tolist()
            elif isinstance(value, float) and not math.isfinite(value):
                value = None
            answer[field.name] = value
        answer.update(
            linearized_error_proxy=self.linearized_error_proxy,
            inverse_gain_residual_proxy=(self.inverse_gain_residual_proxy
                                         if math.isfinite(self.inverse_gain_residual_proxy) else None),
            inverse_gain_is_unbounded_or_invalid=not math.isfinite(self.inverse_gain),
            interpretation="Discrete sampled-function linearization only; not a global PDE error certificate.")
        return answer


def _matrix(value, name):
    result = np.asarray(value, dtype=np.float64)
    if result.ndim != 2 or not np.isfinite(result).all():
        raise ValueError(f"{name} must be a finite two-dimensional matrix")
    return result


def _weights(value, count, name, normalize):
    result = np.ones(count, dtype=np.float64) if value is None else np.asarray(value, dtype=np.float64)
    if result.shape != (count,) or not np.isfinite(result).all() or np.any(result < 0) or not np.any(result > 0):
        raise ValueError(f"{name} must have one finite nonnegative entry per row and positive total weight")
    if normalize:
        # Normalize before summation so that large finite weights cannot make
        # the sum overflow. Common rescaling cannot change the function metric.
        result = result / np.max(result)
        result = result / np.sum(result)
    return result


def _spectral_norm(matrix):
    return float(linalg.svdvals(matrix, check_finite=False)[0]) if matrix.shape[0] and matrix.shape[1] else 0.


def linearized_stability(residual, jacobian, value_matrix, nullspace=None, *,
                         value_weights=None, residual_weights=None,
                         mass_rtol=1e-12, jacobian_rtol=1e-12,
                         jacobian_atol=0., redundancy_rtol=1e-10):
    """Whiten sampled function values, then solve the physical residual by SVD.

    Parameters
    ----------
    residual : (n,) array
        Current residual, with any existing physical scaling retained.
    jacobian : (n, p) array
        Derivative of that same residual with respect to coefficients.
    value_matrix : (q, p) array
        Linearized function values at independently chosen value points. For
        multiple fields, stack their value rows and coefficient blocks, e.g.
        ``scipy.linalg.block_diag(Phi_u, Phi_v)``. Field unit/importance scaling
        must be supplied explicitly; the default averages all scalar entries.
    nullspace : (p, k) array, optional
        Admissible *homogeneous* coefficient directions, for example a boundary
        condition nullspace. Its columns may be redundant or nonorthonormal.
        The current coefficient/lifting itself is not an argument.
    value_weights : (q,) nonnegative array, optional
        Normalized to sum one. Default uniform weights give RMS scalar values.
    residual_weights : (n,) nonnegative array, optional
        Row weights, not normalized. Default ones preserve preweighted r/J.
    mass_rtol, jacobian_rtol : nonnegative float
        Relative SVD rank thresholds. In particular a sole singular value of
        1e-6 remains identifiable at default tolerances. No absolute floor of
        one and no ridge penalty are applied to the physical Jacobian.
    jacobian_atol : nonnegative float
        Optional absolute rank floor in the user's residual/function units.
        Increasing it deliberately marks small but resolved modes unidentified.
    redundancy_rtol : nonnegative float
        Relative tolerance for J acting on a sampled-value-null direction.

    Whitening ``Phi Z = U S V.T`` yields ``T = Z V / S`` with orthonormal
    weighted value columns. Direct SVD of ``J T`` therefore measures residual
    per unit sampled function norm, rather than per arbitrary coefficient norm.
    Algebraic reparameterizations preserve the result when resolved by the
    stated numerical rank tolerances. Extreme ill scaling can change rank in
    finite precision; inspect all reported ranks and thresholds.
    """
    for name, value in (("mass_rtol", mass_rtol), ("jacobian_rtol", jacobian_rtol),
                        ("jacobian_atol", jacobian_atol), ("redundancy_rtol", redundancy_rtol)):
        if isinstance(value, (bool, np.bool_)) or not np.isscalar(value) or not np.isfinite(value) or value < 0:
            raise ValueError(f"{name} must be a finite nonnegative scalar")
    r = np.asarray(residual, dtype=np.float64)
    j = _matrix(jacobian, "jacobian")
    phi = _matrix(value_matrix, "value_matrix")
    if r.ndim != 1 or len(r) < 1 or not np.isfinite(r).all():
        raise ValueError("residual must be a nonempty finite one-dimensional array")
    if j.shape[0] != len(r) or phi.shape[1] != j.shape[1] or phi.shape[0] < 1:
        raise ValueError("residual, jacobian and value_matrix dimensions do not agree")
    coefficient_dimension = j.shape[1]
    z = np.eye(coefficient_dimension) if nullspace is None else _matrix(nullspace, "nullspace")
    if z.shape[0] != coefficient_dimension:
        raise ValueError("nullspace must have one row per coefficient")
    vw = _weights(value_weights, len(phi), "value_weights", normalize=True)
    rw = _weights(residual_weights, len(r), "residual_weights", normalize=False)
    sqrt_rw = np.sqrt(rw)
    b = sqrt_rw * r
    j_weighted = sqrt_rw[:, None] * j
    phi_weighted = np.sqrt(vw)[:, None] * phi
    value_tangent = phi_weighted @ z
    residual_tangent = j_weighted @ z
    if not np.isfinite(value_tangent).all() or not np.isfinite(residual_tangent).all():
        raise FloatingPointError("Non-finite tangent matrices after supplied scaling")

    # Full RIGHT vectors are needed to audit ALL value-null directions when
    # k > q. For tall value matrices, economy mode already gives every right
    # vector and avoids allocating a potentially enormous q-by-q left matrix.
    full_mass_svd = value_tangent.shape[0] < value_tangent.shape[1]
    _, mass_s, mass_vh = linalg.svd(value_tangent, full_matrices=full_mass_svd, check_finite=False,
                                   lapack_driver="gesvd")
    mass_threshold = float(mass_rtol * mass_s[0]) if len(mass_s) else 0.
    function_rank = int(np.count_nonzero(mass_s > mass_threshold))
    tangent_dimension = z.shape[1]
    mass_nullity = tangent_dimension - function_rank
    right_null = mass_vh[function_rank:].T
    coupling = _spectral_norm(residual_tangent @ right_null)
    j_tangent_norm = _spectral_norm(residual_tangent)
    coupling_relative = coupling / j_tangent_norm if j_tangent_norm > 0 else 0.
    redundancy_consistent = bool(coupling <= redundancy_rtol * j_tangent_norm)
    transform = (z @ mass_vh[:function_rank].T) / mass_s[:function_rank][None, :]
    a = j_weighted @ transform
    if not np.isfinite(transform).all() or not np.isfinite(a).all():
        raise FloatingPointError("Function metric whitening overflowed")
    u, singular, vh = linalg.svd(a, full_matrices=False, check_finite=False, lapack_driver="gesvd")
    sigma_max = float(singular[0]) if len(singular) else 0.
    jacobian_threshold = float(max(jacobian_atol, jacobian_rtol * sigma_max))
    rank = int(np.count_nonzero(singular > jacobian_threshold))
    y = -vh[:rank].T @ ((u[:, :rank].T @ b) / singular[:rank])
    correction = transform @ y
    value_correction = phi @ correction
    linearized_residual = r + j @ correction
    weighted_remaining = sqrt_rw * linearized_residual
    correction_norm = float(linalg.norm(np.sqrt(vw) * value_correction))
    before_norm = float(linalg.norm(b))
    remaining_norm = float(linalg.norm(weighted_remaining))
    identifiable = bool(function_rank > 0 and rank == function_rank)
    reliable = bool(identifiable and redundancy_consistent)
    retained_min = float(singular[rank - 1]) if rank else 0.
    sigma_min = retained_min if reliable else 0.
    inverse_gain = 1. / sigma_min if sigma_min > 0 else math.inf
    condition_number = sigma_max / sigma_min if sigma_min > 0 else math.inf
    warnings = []
    if not function_rank:
        status = "no_resolved_function_directions"
        warnings.append("The supplied constraints/value matrix leave no resolved function direction.")
    elif not redundancy_consistent:
        status = "value_metric_incomplete"
        warnings.append("Some direction has negligible sampled values but changes the residual; finite value points do not determine the residual action.")
    elif not identifiable:
        status = "unidentifiable_function_modes"
        warnings.append("The linearized equations leave observed function modes unidentified; a finite inverse gain would be misleading.")
    else:
        status = "identified_discrete_linearization"
    if mass_nullity and redundancy_consistent:
        warnings.append("Coefficient/tangent redundancy was removed only at the reported numerical tolerance.")
    if remaining_norm > 1e-10 * max(before_norm, np.finfo(float).tiny):
        warnings.append("A residual component remains outside the retained linearized range; the correction does not solve the supplied residual exactly.")
    if not all(np.isfinite(v).all() for v in (correction, value_correction, linearized_residual, weighted_remaining)):
        raise FloatingPointError("Non-finite SVD correction")
    return StabilityReport(
        correction=correction, value_correction=value_correction,
        linearized_residual=linearized_residual, weighted_linearized_residual=weighted_remaining,
        function_correction_norm=correction_norm, residual_norm_before=before_norm,
        remaining_residual_norm=remaining_norm,
        relative_remaining_residual=remaining_norm / before_norm if before_norm else 0.,
        sigma_min=sigma_min, sigma_max=sigma_max,
        smallest_retained_singular_value=retained_min, inverse_gain=inverse_gain,
        condition_number=condition_number, identifiable_rank=rank, function_rank=function_rank,
        coefficient_dimension=coefficient_dimension, tangent_dimension=tangent_dimension,
        mass_nullity=mass_nullity, jacobian_nullity=function_rank - rank,
        mass_null_residual_coupling=coupling, mass_null_coupling_relative=coupling_relative,
        redundancy_consistent=redundancy_consistent, identifiable=identifiable, reliable=reliable,
        status=status, warnings=warnings, singular_values=singular,
        mass_singular_values=mass_s, mass_rank_threshold=mass_threshold,
        jacobian_rank_threshold=jacobian_threshold,
        normal_equation_defect=float(linalg.norm(a.T @ weighted_remaining)))
