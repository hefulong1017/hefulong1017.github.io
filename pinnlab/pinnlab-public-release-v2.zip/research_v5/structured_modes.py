"""Bounded Fourier/exponential composition from physical data and symbols.

These are conventional structured/Trefftz trial functions. No readout weights,
solution references, case names or target amplitudes are used as coefficients.
"""
import itertools
import math
import numpy as np
import sympy as sp
from research_v4.spec import Formula
from research_v4.basis import _descriptor_key
from .features import _physical,_symbolic,_linear,_float,_canonical_v5


def structured_proposals(problem,bank,limit=64):
    p=_physical(problem); variables=p['variables']; fields=p['fields']; dim=len(variables)
    formulas=[Formula(eq,variables,fields,p.get('parameters')) for eq in p['equations']]
    data=[Formula(str(c['target']),variables,fields,p.get('parameters'),False) for c in p['conditions']]
    names=set(variables)
    for f in formulas: names.update(f.jets)
    symbols={n:sp.Symbol(n,real=True) for n in names}; coords=[symbols[v] for v in variables]
    jets=[symbols[n] for n in names if n not in variables]
    equations=[_symbolic(f,symbols) for f in formulas]
    zero=dict.fromkeys(jets,0)
    expressions=[(e.subs(zero),{}) for e in equations]+[(_symbolic(f,symbols),c.get('where',{})) for f,c in zip(data,p['conditions'])]
    modes=[]; degrees=[0]*dim
    for expression,where in expressions:
        if sp.count_ops(expression)>700: continue
        try:
            expanded=sp.expand_mul(expression.rewrite(sp.exp))
            terms=sp.Add.make_args(expanded)
            if len(terms)>128: continue
            for term in terms:
                phase=sp.Integer(0); rest=sp.Integer(1)
                for factor in sp.Mul.make_args(term):
                    if factor.func==sp.exp: phase+=factor.args[0]
                    else: rest*=factor
                rate=[sp.simplify(sp.diff(phase,x)) for x in coords]
                if any(value.free_symbols for value in rate): continue
                if (phase-sum(v*x for v,x in zip(rate,coords))).free_symbols: continue
                try: powers=sp.Poly(rest,*coords).monoms()
                except sp.PolynomialError: continue
                for power in powers:
                    if sum(power)<=6:
                        degrees=[max(a,b) for a,b in zip(degrees,power)]
                        if any(rate): modes.append((tuple(rate),tuple(power),where))
        except (TypeError,ValueError,NotImplementedError): continue
        if len(modes)>80: modes=modes[:80]; break
    # Prefer data modes completed by the *homogeneous operator symbol*. A
    # missing fixed coordinate is a mode parameter, not a supplied solution.
    complete=[]
    if len(fields)==1:
        coefficients=[_linear(e,jets,coords) for e in equations]
        unknown=sp.Symbol('lambda_mode')
        for rate,power,where in modes:
            for axis in sorted((variables.index(v) for v in where),key=lambda i:variables[i]!='t'):
                if rate[axis]!=0 or power[axis]!=0: continue
                lam=list(rate); lam[axis]=unknown
                for coeff in coefficients:
                    if coeff is None: continue
                    symbol=sp.Integer(0)
                    for name,value in coeff.items():
                        suffix=name.split('_',1)[1] if '_' in name else ''
                        symbol+=value*sp.prod(lam[variables.index(v)] for v in suffix)
                    try:
                        poly=sp.Poly(sp.expand(symbol),unknown)
                        if not 1<=poly.degree()<=2: continue
                        roots=sp.solve(poly.as_expr(),unknown)
                    except (ValueError,sp.PolynomialError,NotImplementedError): continue
                    for root in roots:
                        if root.free_symbols: continue
                        fitted=list(rate); fitted[axis]=root
                        complete.append((tuple(fitted),power))
    out=[]; seen=set(bank._keys)
    def add(rate,power):
        if len(out)>=limit: return
        real=[_float(sp.re(value)) for value in rate]; imag=[_float(sp.im(value)) for value in rate]
        if any(v is None for v in real+imag): return
        first=next((v for v in imag if abs(v)>1e-12),0.)
        if first<0: imag=[-v for v in imag]
        factors=[]
        if any(abs(v)>1e-13 for v in real): factors.append({'kind':'exp_ridge','rate':real})
        trigs=[None]
        if any(abs(v)>1e-13 for v in imag):
            frequency=[v*(b-a)/math.pi for v,(a,b) in zip(imag,bank.bounds)]
            trigs=[{'kind':k,'frequency':frequency} for k in ('sin','cos')]
        for trig in trigs:
            fs=factors+([trig] if trig else [])
            if any(power): fs=fs+[{'kind':'poly','powers':list(power)}]
            if not fs: continue
            descriptor=fs[0] if len(fs)==1 else {'kind':'product','factors':fs}
            try: descriptor=_canonical_v5(descriptor,dim)
            except ValueError: continue
            key=_descriptor_key(descriptor)
            if key not in seen:
                seen.add(key); out.append(descriptor)
                if len(out)>=limit: return
    for rate,power in complete: add(rate,power)
    # Every monomial is expanded into a nested Chebyshev span, so translating
    # the physical box never assumes x^k equals a single Chebyshev function.
    for rate,power,_ in modes:
        for lower in itertools.product(*(range(d+1) for d in power)):
            add(rate,lower)
    # Boundary exponent rates and initial polynomial spatial degrees can be
    # combined without fitting any reference amplitude (e.g. power payoffs).
    spatial=[min(d,4) if v!='t' else 0 for d,v in zip(degrees,variables)]
    for rate,_,_ in modes:
        if any(rate[i]!=0 and spatial[i] for i in range(dim)): continue
        if not any(spatial) or np.prod([d+1 for d in spatial])>20: continue
        for lower in itertools.product(*(range(d+1) for d in spatial)): add(rate,lower)
    return out
