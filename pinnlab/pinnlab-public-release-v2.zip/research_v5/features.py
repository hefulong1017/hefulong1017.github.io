"""Physical-input feature proposals and stable exponential neural ridges.

These are conventional operator/data-informed trial functions, not a claim of
algorithmic originality or a universal solver. Coefficients are not supplied:
the PDE residual still determines all readout weights. No reference solution,
case identifier, outcome label or fitted error is inspected here.

``exp_ridge/rate`` uses physical-coordinate rates. Its anchor is the box
corner maximizing rate dot x, so its exponent is nonpositive inside the box.
Products can mix these ridges with all V4 primitives, with exact jets to six.
"""
from __future__ import annotations

import ast
import itertools
import math

import numpy as np
import sympy as sp

from research_v4.basis import (MAX_ORDER, NeuralBank, _canonical, _descriptor_key, _vector)
from research_v4.spec import Formula, validate_problem


def _canonical_v5(descriptor, dimension, depth=0):
    if not isinstance(descriptor, dict) or depth > 4:
        raise ValueError("A feature must be a descriptor mapping with limited nesting")
    kind = descriptor.get("kind")
    if kind == "exp_ridge":
        if set(descriptor) != {"kind", "rate"}:
            raise ValueError("An exp_ridge requires only a physical rate vector")
        rate = _vector(descriptor["rate"], dimension, "rate")
        if any(abs(value) > 1e12 for value in rate):
            raise ValueError("Exponential physical rates must be within 1e12")
        return {"kind": kind, "rate": rate} if any(rate) else {"kind": "poly", "powers": [0] * dimension}
    if kind != "product":
        return _canonical(descriptor, dimension, depth)
    factors = descriptor.get("factors")
    if set(descriptor) != {"kind", "factors"} or not isinstance(factors, (list, tuple)) or not 1 <= len(factors) <= 4:
        raise ValueError("A product requires one to four factors")
    flattened = []
    for raw in factors:
        factor = _canonical_v5(raw, dimension, depth + 1)
        if factor["kind"] == "product": flattened.extend(factor["factors"])
        elif factor["kind"] != "poly" or any(factor["powers"]): flattened.append(factor)
    if len(flattened) > 4:
        raise ValueError("A product may contain at most four primitive factors")
    if not flattened:
        return {"kind": "poly", "powers": [0] * dimension}
    if len(flattened) == 1:
        return flattened[0]
    return {"kind": "product", "factors": sorted(flattened, key=_descriptor_key)}


class V5Bank(NeuralBank):
    """V4-compatible bank with stable physical exponential ridge products."""

    def __init__(self, variables, bounds, features=None, poly_degree=2, neural_frequencies=1):
        # Let the frozen implementation validate coordinates and initial V4
        # functions, then install the extended canonical descriptor sequence.
        super().__init__(variables, bounds, features=[] if features is not None else None,
                         poly_degree=poly_degree, neural_frequencies=neural_frequencies)
        if features is None:
            return
        if not isinstance(features, (list, tuple)):
            raise ValueError("features must be a JSON sequence of descriptors")
        unique = {}
        for descriptor in features:
            canonical = _canonical_v5(descriptor, len(self.variables))
            unique.setdefault(_descriptor_key(canonical), canonical)
        self.features = list(unique.values())
        self.size = len(self.features)
        self._keys = frozenset(unique)

    def append(self, descriptor):
        feature = _canonical_v5(descriptor, len(self.variables))
        features = list(self.features)
        if _descriptor_key(feature) not in self._keys:
            features.append(feature)
        return V5Bank(self.variables, self.bounds, features=features,
                      poly_degree=self.poly_degree, neural_frequencies=self.neural_frequencies)

    def values(self, points, names):
        points = np.asarray(points, dtype=np.float64)
        if points.ndim != 2 or points.shape[1] != len(self.variables) or not np.isfinite(points).all():
            raise ValueError("points must be a finite (n, dimensions) array")
        orders = self._orders(names)
        primitives = {}
        has_exponential = False
        def collect(descriptor):
            nonlocal has_exponential
            if descriptor["kind"] == "product":
                for factor in descriptor["factors"]: collect(factor)
            elif descriptor["kind"] == "exp_ridge": has_exponential = True
            else: primitives.setdefault(_descriptor_key(descriptor), descriptor)
        for descriptor in self.features: collect(descriptor)
        if has_exponential and (np.any(points < self.bounds[:, 0]) or np.any(points > self.bounds[:, 1])):
            raise ValueError("Stable exponential features require points inside their physical box")
        # A product derivative needs only coordinatewise suborders of requested
        # jets. This avoids allocating every derivative in four dimensions.
        needed = {beta for alpha in orders.values() for beta in itertools.product(*(range(a + 1) for a in alpha))}
        def name(alpha):
            suffix = "".join(variable * order for variable, order in zip(self.variables, alpha))
            return "u_" + suffix if suffix else "u"
        legacy_descriptors = list(primitives.values())
        legacy = NeuralBank(self.variables, self.bounds, features=legacy_descriptors)
        legacy_values = legacy.values(points, [name(alpha) for alpha in needed])
        columns = {key: index for index, key in enumerate(primitives)}
        cache = {}

        def product_value(factors, alpha):
            if len(factors) == 1:
                return evaluate(factors[0], alpha)
            key = ("product_tail", tuple(_descriptor_key(factor) for factor in factors), alpha)
            if key not in cache:
                value = np.zeros(len(points))
                for beta in itertools.product(*(range(a + 1) for a in alpha)):
                    remainder = tuple(a - b for a, b in zip(alpha, beta))
                    coefficient = math.prod(math.comb(a, b) for a, b in zip(alpha, beta))
                    value += coefficient * evaluate(factors[0], beta) * product_value(factors[1:], remainder)
                cache[key] = value
            return cache[key]

        def evaluate(descriptor, alpha):
            key = (_descriptor_key(descriptor), alpha)
            if key not in cache:
                if descriptor["kind"] == "product":
                    value = product_value(descriptor["factors"], alpha)
                elif descriptor["kind"] == "exp_ridge":
                    rate = np.asarray(descriptor["rate"], dtype=float)
                    anchor = np.where(rate >= 0, self.bounds[:, 1], self.bounds[:, 0])
                    exponent = (points - anchor) @ rate
                    # Every summand is nonpositive in-domain; no clipping or
                    # saturated exponential is used, so jets stay integrable.
                    multiplier = math.prod(float(rate[j]) ** order for j, order in enumerate(alpha))
                    value = np.exp(exponent) * multiplier
                else:
                    value = legacy_values[name(alpha)][:, columns[_descriptor_key(descriptor)]]
                cache[key] = value
            return cache[key]

        answer = {}
        with np.errstate(over="raise", invalid="raise", divide="raise"):
            for requested, alpha in orders.items():
                value = np.column_stack([evaluate(descriptor, alpha) for descriptor in self.features]) if self.features else np.empty((len(points), 0))
                if not np.isfinite(value).all():
                    raise FloatingPointError("Non-finite V5 physical derivative: " + requested)
                answer[requested] = value
        return answer


def _number(value):
    if type(value) not in (int, float) or not math.isfinite(value):
        raise ValueError("Physical constants must be finite numbers")
    return sp.Rational(str(value))


def _symbolic(formula, symbols, tree=None):
    functions = {"sin": sp.sin, "cos": sp.cos, "exp": sp.exp, "tanh": sp.tanh,
                 "sqrt": sp.sqrt, "log": sp.log, "abs": sp.Abs}
    def visit(node):
        if isinstance(node, ast.Constant): return _number(node.value)
        if isinstance(node, ast.Name):
            if node.id in formula.parameters: return _number(formula.parameters[node.id])
            if node.id == "pi": return sp.pi
            if node.id == "e": return sp.E
            return symbols[node.id]
        if isinstance(node, ast.UnaryOp): return -visit(node.operand) if isinstance(node.op, ast.USub) else visit(node.operand)
        if isinstance(node, ast.Call): return functions[node.func.id](visit(node.args[0]))
        left, right = visit(node.left), visit(node.right)
        if isinstance(node.op, ast.Add): return left + right
        if isinstance(node.op, ast.Sub): return left - right
        if isinstance(node.op, ast.Mult): return left * right
        if isinstance(node.op, ast.Div): return left / right
        if isinstance(node.op, ast.Pow): return left ** right
        raise ValueError("Unsupported symbolic AST")
    return visit(formula.tree if tree is None else tree)


def _physical(problem):
    # Whitelisting also avoids touching malicious or expensive metadata values.
    payload = {key: problem[key] for key in ("variables", "domain", "fields", "equations", "conditions")}
    payload["name"] = "physical_feature_input"
    for key in ("parameters", "branches"):
        if key in problem: payload[key] = problem[key]
    return validate_problem(payload)


def _float(expression, limit=1e12):
    try:
        value = float(sp.N(expression, 17))
        return value if math.isfinite(value) and abs(value) <= limit else None
    except (ValueError, TypeError, OverflowError):
        return None


def _linear(expression, jets, coordinates):
    coefficients = {jet: sp.simplify(sp.diff(expression, jet)) for jet in jets}
    if any(coefficient.free_symbols for coefficient in coefficients.values()): return None
    forcing = sp.simplify(expression.subs(dict.fromkeys(jets, 0)))
    if forcing.free_symbols - set(coordinates): return None
    if sp.simplify(expression - forcing - sum(jet * coefficient for jet, coefficient in coefficients.items())) != 0: return None
    return {str(jet): coefficient for jet, coefficient in coefficients.items() if coefficient != 0}


def propose(problem, bank):
    """Propose up to 48 absent functions from validated physical ASTs only.

    Recognizes affine sin/cos/exp/tanh data/source phases; scalar constant-coefficient
    advection/diffusion/reaction and wave dispersion; one-dimensional boundary
    layer exponents; and spectra of square first-order coupled ODE systems.
    A pattern mismatch returns no corresponding proposal, never an alleged
    solution or a private-answer shortcut. Caller may then use the V4 pool.
    """
    physical = _physical(problem)
    variables, fields = physical["variables"], physical["fields"]
    dimension = len(variables)
    if list(bank.variables) != variables or not np.array_equal(bank.bounds, np.array([physical["domain"][v] for v in variables], float)):
        raise ValueError("Feature bank coordinates must match the physical problem")
    parameters = physical.get("parameters")
    equations = [Formula(text, variables, fields, parameters) for text in physical["equations"]]
    data = [Formula(str(condition["target"]), variables, fields, parameters, False) for condition in physical["conditions"]]
    names = set(variables)
    for formula in equations + data: names.update(formula.jets)
    symbols = {name: sp.Symbol(name, real=True) for name in names}
    coordinates = [symbols[v] for v in variables]
    jets = [symbol for name, symbol in symbols.items() if name not in variables]
    linear = [_linear(_symbolic(formula, symbols), jets, coordinates) for formula in equations]
    lengths = bank.bounds[:, 1] - bank.bounds[:, 0]
    proposals, seen = [], set(bank._keys)

    def add(descriptor):
        if len(proposals) >= 48: return
        try: canonical = _canonical_v5(descriptor, dimension)
        except ValueError: return
        key = _descriptor_key(canonical)
        if key not in seen:
            seen.add(key)
            proposals.append(canonical)

    def trigs(rate):
        frequency = [float(value * length / math.pi) for value, length in zip(rate, lengths)]
        if not any(abs(value) > 1e-13 for value in frequency) or any(abs(value) > 1e8 for value in frequency): return []
        return [{"kind": kind, "frequency": frequency} for kind in ("sin", "cos")]

    def scaled_trigs(rate, decay):
        for trig in trigs(rate):
            add({"kind": "product", "factors": [trig, {"kind": "exp_ridge", "rate": decay}]})

    # A constant affine trigonometric phase is represented by a sin/cos pair.
    # An exponential's additive phase changes only its readout scale and is
    # discarded in favor of the stable boundary anchor. Tanh's affine phase
    # must retain its center; its external amplitude remains a readout weight.
    modes = []
    affine_features = []
    affine_keys = set()
    for formula in equations + data:
        for node in ast.walk(formula.tree):
            if not isinstance(node, ast.Call) or node.func.id not in ("sin", "cos", "exp", "tanh"): continue
            phase = _symbolic(formula, symbols, node.args[0])
            if phase.free_symbols - set(coordinates): continue
            coefficients = [sp.simplify(sp.diff(phase, coordinate)) for coordinate in coordinates]
            if any(coefficient.free_symbols for coefficient in coefficients): continue
            remainder = sp.simplify(phase - sum(coefficient * coordinate for coefficient, coordinate in zip(coefficients, coordinates)))
            if remainder.free_symbols: continue
            rate = [_float(coefficient) for coefficient in coefficients]
            if any(value is None for value in rate) or not any(rate): continue
            if node.func.id in ("sin", "cos"):
                if not any(np.allclose(rate, existing, rtol=1e-12, atol=1e-13) for existing in modes): modes.append(rate)
            else:
                if node.func.id == "exp":
                    descriptor = {"kind": "exp_ridge", "rate": rate}
                else:
                    # k*x+c = d*(2*(x-a)/L-1)+bias, with d=k*L/2.
                    direction = [_float(coefficient * _number(float(length)) / 2)
                                 for coefficient, length in zip(coefficients, lengths)]
                    midpoint = [_number(float((lower + upper) / 2)) for lower, upper in bank.bounds]
                    bias = _float(remainder + sum(coefficient * middle for coefficient, middle in zip(coefficients, midpoint)))
                    if bias is None or any(value is None for value in direction): continue
                    descriptor = {"kind": "tanh", "direction": direction, "bias": bias}
                key = _descriptor_key(descriptor)
                if key not in affine_keys:
                    affine_keys.add(key)
                    affine_features.append(descriptor)
            if len(modes) + len(affine_features) >= 16: break
        if len(modes) + len(affine_features) >= 16: break
    for rate in modes:
        for trig in trigs(rate): add(trig)
    for descriptor in affine_features: add(descriptor)

    if "t" in variables:
        time_axis = variables.index("t")
        space_axes = [axis for axis in range(dimension) if axis != time_axis]
        spatial_modes = [rate for rate in modes if abs(rate[time_axis]) < 1e-13 and any(rate[axis] for axis in space_axes)]
        for coefficients in linear:
            if coefficients is None: continue
            for field in fields:
                temporal, temporal2 = field + "_t", field + "_tt"
                spatial1 = [field + "_" + variables[axis] for axis in space_axes]
                spatial2 = [name + variables[axis] for name, axis in zip(spatial1, space_axes)]
                allowed_heat = {field, temporal, *spatial1, *spatial2}
                at = coefficients.get(temporal, 0)
                if at != 0 and set(coefficients) <= allowed_heat:
                    for rate in spatial_modes:
                        drift = -sum(coefficients.get(name, 0) * rate[axis] for name, axis in zip(spatial1, space_axes)) / at
                        decay = (sum(coefficients.get(name, 0) * rate[axis] ** 2 for name, axis in zip(spatial2, space_axes)) - coefficients.get(field, 0)) / at
                        omega, exponent = _float(drift), _float(decay)
                        if omega is None or exponent is None: continue
                        moving = list(rate); moving[time_axis] = omega
                        exponents = [0.] * dimension; exponents[time_axis] = exponent
                        scaled_trigs(moving, exponents)
                allowed_wave = {field, temporal2, *spatial2}
                att = coefficients.get(temporal2, 0)
                if att != 0 and set(coefficients) <= allowed_wave:
                    for rate in spatial_modes:
                        omega2 = sp.simplify((coefficients.get(field, 0) - sum(coefficients.get(name, 0) * rate[axis] ** 2 for name, axis in zip(spatial2, space_axes))) / att)
                        if omega2.is_positive is not True: continue
                        omega = _float(sp.sqrt(omega2))
                        if omega is None: continue
                        time_rate = [0.] * dimension; time_rate[time_axis] = omega
                        for spatial in trigs(rate):
                            for temporal_trig in trigs(time_rate): add({"kind": "product", "factors": [spatial, temporal_trig]})

    if dimension == 1:
        coordinate = variables[0]
        for coefficients in linear:
            if coefficients is None: continue
            for field in fields:
                first, second = field + "_" + coordinate, field + "_" + coordinate * 2
                if set(coefficients) <= {field, first, second} and coefficients.get(second, 0) != 0 and coefficients.get(field, 0) == 0:
                    rate = _float(-coefficients.get(first, 0) / coefficients[second])
                    if rate is not None and rate != 0: add({"kind": "exp_ridge", "rate": [rate]})
        # C*y' + D*y + f(x)=0 -> y'=A*y + g(x). Eigenmodes are candidate
        # functions for the homogeneous operator, not supplied output vectors.
        derivative_names = [field + "_" + coordinate for field in fields]
        allowed = set(fields + derivative_names)
        if 2 <= len(fields) <= 4 and len(linear) == len(fields) and all(coeff is not None and set(coeff) <= allowed for coeff in linear):
            c = sp.Matrix([[coeff.get(name, 0) for name in derivative_names] for coeff in linear])
            d = sp.Matrix([[coeff.get(name, 0) for name in fields] for coeff in linear])
            if sp.simplify(c.det()).is_zero is False:
                try:
                    eigenvalues = (-c.inv() * d).eigenvals()
                    for eigenvalue in eigenvalues:
                        real, imaginary = (_float(value) for value in eigenvalue.as_real_imag())
                        if real is None or imaginary is None: continue
                        if abs(imaginary) > 1e-12: scaled_trigs([abs(imaginary)], [real])
                        elif real != 0: add({"kind": "exp_ridge", "rate": [real]})
                except (NotImplementedError, ValueError, TypeError):
                    pass
    return proposals
