"""V5 fixed-input development, strict freeze and predictor-only final audit.

All requested fitting finishes before development references are constructed.
Final evaluation only loads frozen models; it never calls solve or propose.
"""
from __future__ import annotations

from dataclasses import asdict, replace
from datetime import datetime, timezone
import hashlib
from importlib.metadata import PackageNotFoundError, version
import json
from pathlib import Path
import platform
import sys

import numpy as np

from .solver import analyze
from research_v4.challenges import audit_candidate, list_challenges, make_problem
from research_v4.solver import points
from .evaluation import audit_catalog, catalog_cases, catalog_problem
from .solver import SolverConfig, load, physical_input, solve


ROOT = Path(__file__).resolve().parents[1]
DEVELOPMENT_COUNT = 1024
DEVELOPMENT_SEED = 84105
FINAL_COUNT = 8192
FINAL_SEED = 20261121
SUCCESS_STATUS = "physics_and_correction_tolerance"
DIFFICULT_CASES = frozenset({
    "helmholtz_near_resonance", "heat_high_frequency",
    "convection_boundary_layer", "coupled_oscillator",
})
ABLATION_SEMANTICS = {
    "full": "Physical structure proposals plus function-metric SVD corrections and the discrete correction stopping gate.",
    "no_structure": "Disable physical structure proposals; retain the same SVD correction and stability gate.",
    "no_stability": "Disable only the stability/correction stopping control; corrections still use the V5 function-metric SVD. This is not a conventional Gauss-Newton baseline.",
}


def _now():
    return datetime.now(timezone.utc).isoformat()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    temporary.replace(path)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _value_sha(value):
    return hashlib.sha256(_canonical(value).encode("utf-8")).hexdigest()


def source_hashes():
    """Freeze the actual V5/V4/legacy Python dependencies and catalog YAML."""
    paths = []
    excluded = {"validation", "runs", "__pycache__", ".pytest_cache", ".git"}
    for directory in (ROOT / "research_v5", ROOT / "research_v4", ROOT / "pinnlab"):
        paths.extend(p for p in directory.rglob("*.py") if not (set(p.relative_to(directory).parts) & excluded))
    paths.extend((ROOT / "examples" / "catalog").glob("*.yaml"))
    return {p.relative_to(ROOT).as_posix(): sha(p) for p in sorted(set(paths))}


def _inside(directory, relative):
    relative = Path(str(relative).replace("\\", "/"))
    if relative.is_absolute():
        raise RuntimeError("Experiment artifacts must have relative paths.")
    result = (directory / relative).resolve()
    if not result.is_relative_to(directory.resolve()):
        raise RuntimeError("Experiment artifact escaped its directory.")
    return result


def case_metadata():
    """Namespaced identifiers; catalog coverage and challenge diagnostics differ."""
    answer = []
    for suite, entries in (("catalog", catalog_cases()), ("challenges", list_challenges())):
        for entry in entries:
            answer.append({**entry, "suite": suite, "case_id": entry["id"],
                           "id": suite + "/" + entry["id"]})
    return answer


def get_problem(identifier):
    by_id = {item["id"]: item for item in case_metadata()}
    if identifier not in by_id:
        raise KeyError("Unknown namespaced V5 case: " + repr(identifier))
    info = by_id[identifier]
    return (catalog_problem(info["case_id"]) if info["suite"] == "catalog"
            else physical_input(make_problem(info["case_id"])))


def outcome(result, analysis):
    """Reuse conservative V4 outcome semantics with the V5 success status."""
    if analysis.get("incompatible"):
        return "incompatible"
    if result is None or result.status != SUCCESS_STATUS:
        return "undetermined"
    for symmetry in analysis.get("symmetries", []):
        if symmetry["type"] == "constant_shift":
            return "nonunique"
        if symmetry["type"] == "sign_reflection":
            values = result.predict(points(result.problem, 32, 184105))
            if any(np.max(np.abs(values[field])) > 1e-8 for field in symmetry["fields"]):
                return "nonunique"
    return "solution"


def _plan(case_ids, base, ablations):
    metadata = case_metadata()
    by_id = {item["id"]: item for item in metadata}
    selected = list(by_id) if case_ids is None else list(case_ids)
    if not selected or len(set(selected)) != len(selected):
        raise ValueError("case_ids must be a nonempty, unique sequence of namespaced ids.")
    unknown = [identifier for identifier in selected if identifier not in by_id]
    if unknown:
        raise KeyError("Unknown V5 cases: " + repr(unknown))
    # Finish all full cases first, followed by the two limited mechanism controls.
    plan = [(by_id[identifier], "full", replace(base)) for identifier in selected]
    if ablations:
        for identifier in selected:
            item = by_id[identifier]
            if item["suite"] == "challenges" and item["case_id"] in DIFFICULT_CASES:
                plan.extend([
                    (item, "no_structure", replace(base, informed_features=False)),
                    (item, "no_stability", replace(base, stability_control=False)),
                ])
    return plan


def summary(rows, expected_full=None):
    full = {(r["id"], r["variant"]): r for r in rows if r["variant"] == "full"}
    expected = expected_full if expected_full is not None else [r for r in rows if r["variant"] == "full"]
    catalog = [r for r in expected if r["suite"] == "catalog"]
    challenges = [r for r in expected if r["suite"] == "challenges"]
    accepted = lambda item: bool((full.get((item["id"], "full"), {}).get("audit") or {}).get("accepted_solution"))
    handled = lambda item: bool((full.get((item["id"], "full"), {}).get("audit") or {}).get("successful_handling"))
    families = sorted({r["canonical_family"] for r in catalog})
    passed_families = [family for family in families
                       if all(accepted(r) for r in catalog if r["canonical_family"] == family)]
    return {
        "record_count": len(rows), "full_record_count": len(full),
        "ablation_record_count": sum(r["variant"] != "full" for r in rows),
        "catalog": {
            "requested_cases": len(catalog), "canonical_families": len(families),
            "accepted_numerical_solutions": sum(accepted(r) for r in catalog),
            "passed_families": len(passed_families), "family_names": families,
            "passed_family_names": passed_families,
            "unresolved_case_ids": [r["id"] for r in catalog if not accepted(r)],
            "family_pass_rule": "Every requested case in that canonical family must pass both the V5 solver-status gate and independent audit.",
        },
        "challenges": {
            "requested_cases": len(challenges),
            "accepted_numerical_solutions": sum(accepted(r) for r in challenges),
            "successful_handling": sum(handled(r) for r in challenges),
            "unresolved_case_ids": [r["id"] for r in challenges if not handled(r)],
            "note": "Includes ODE/interface, nonunique, incompatible and branch variants; not a PDE-family coverage count.",
        },
        "coverage_claim": "Only newly fitted V5 catalog models passing the declared gates count toward catalog family coverage. Challenges and ablations add no family votes.",
    }


def _failure_audit(row, error):
    return {
        "id": row["case_id"], "expected_outcome": row.get("expected_outcome", "unique"),
        "accepted_solution": False, "successful_handling": False,
        "physics_consistent": False, "reference_errors": None,
        "audit_error": error, "solver_status_accepted": row.get("status") == SUCCESS_STATUS,
    }


def _audit(row, model, count, seed):
    try:
        if row["suite"] == "catalog":
            if model is None:
                return _failure_audit(row, "No frozen numerical predictor; catalog accuracy is not accepted.")
            audit = audit_catalog(row["case_id"], model.predict, count=count, seed=seed)
            independent = bool(audit.get("accepted_solution"))
            status_pass = model.status == SUCCESS_STATUS and row["status"] == SUCCESS_STATUS
            audit["independent_audit_accepted"] = independent
            audit["solver_status_accepted"] = status_pass
            accepted = bool(independent and status_pass)
            audit.update(accepted_solution=accepted, accepted_accuracy=accepted, successful_handling=accepted)
            if independent and not status_pass:
                audit["acceptance_note"] = "Independent physical/reference checks passed, but the declared V5 stopping status did not; not counted as a solved catalog case."
            return audit
        return audit_candidate(row["case_id"], model.predict if model else None,
                               row["reported_status"], count=count, seed=seed)
    except Exception as exc:
        return _failure_audit(row, type(exc).__name__ + ": " + str(exc))


def _model_map(directory, report):
    result = {}
    for row in report["rows"]:
        if row.get("run"):
            key = row["id"] + "/" + row["variant"]
            if key in result:
                raise RuntimeError("Duplicate model identity.")
            path = _inside(directory, row["run"]) / "model.json"
            if sha(path) != row["model_sha256"]:
                raise RuntimeError("Model changed: " + key)
            state = read(path)
            if _canonical(state["problem"]) != _canonical(read(_inside(directory, row["physical_input_path"]))):
                raise RuntimeError("Saved model problem differs from physical input: " + key)
            if _canonical(state["config"]) != _canonical(row["config"]):
                raise RuntimeError("Saved model configuration differs from run record: " + key)
            if state["status"] != row["status"]:
                raise RuntimeError("Saved model status differs from run record: " + key)
            result[key] = {"path": row["run"], "sha256": row["model_sha256"]}
    actual_files = {p.resolve() for p in (directory / "runs").rglob("model.json")}
    expected_files = {(_inside(directory, item["path"]) / "model.json").resolve() for item in result.values()}
    if actual_files != expected_files:
        raise RuntimeError("On-disk model set differs from the recorded set; untracked, missing or extra models.")
    return result


def _artifact_maps(directory, report):
    inputs, configurations = {}, {}
    for row in report["rows"]:
        path = _inside(directory, row["physical_input_path"])
        specification = read(path)
        if sha(path) != row["physical_input_sha256"] or _value_sha(specification) != row["physical_spec_sha256"]:
            raise RuntimeError("Physical input artifact changed.")
        if _canonical(specification) != _canonical(get_problem(row["id"])):
            raise RuntimeError("Physical input no longer matches its source case.")
        inputs[row["id"]] = {"path": row["physical_input_path"], "sha256": sha(path),
                             "canonical_sha256": _value_sha(specification)}
        path = _inside(directory, row["configuration_path"])
        if sha(path) != row["configuration_sha256"] or _canonical(read(path)) != _canonical(row["config"]):
            raise RuntimeError("Configuration artifact changed.")
        configurations[row["id"] + "/" + row["variant"]] = {
            "path": row["configuration_path"], "sha256": sha(path),
            "canonical_sha256": _value_sha(row["config"])}
    return inputs, configurations


def _validate_rows(report):
    expected = {(row["id"], row["variant"]) for row in report["request"]["planned_rows"]}
    found = [(row["id"], row["variant"]) for row in report["rows"]]
    if len(set(found)) != len(found) or set(found) != expected:
        raise RuntimeError("Development row set differs from the complete declared plan.")
    for row in report["rows"]:
        if row["suite"] + "/" + row["case_id"] != row["id"]:
            raise RuntimeError("Suite/case identity mismatch.")


def _verify_freeze(directory):
    manifest_path = directory / "frozen_v5.json"
    frozen = read(manifest_path)
    if source_hashes() != frozen["source_sha256"]:
        raise RuntimeError("Frozen V5/V4/legacy source or catalog inputs changed.")
    devpath = directory / "results_development.json"
    if sha(devpath) != frozen["development_sha256"]:
        raise RuntimeError("Frozen development record changed.")
    development = read(devpath)
    if development["source_sha256"] != frozen["source_sha256"]:
        raise RuntimeError("Development/freeze source mismatch.")
    _validate_rows(development)
    models = _model_map(directory, development)
    inputs, configurations = _artifact_maps(directory, development)
    if models != frozen["models"] or inputs != frozen["physical_inputs"] or configurations != frozen["configurations"]:
        raise RuntimeError("Frozen model/input/configuration set differs from the development artifacts.")
    if frozen["final_seed"] != FINAL_SEED or frozen["final_count"] != FINAL_COUNT:
        raise RuntimeError("Frozen final audit parameters changed.")
    if frozen["request_sha256"] != _value_sha(development["request"]):
        raise RuntimeError("Frozen experiment request changed.")
    return frozen, development


def run_development(directory="research_v5/validation", case_ids=None, ablations=True, config=None):
    """Fit the common plan, audit all fits afterward, then freeze every record.

    The default is 26 catalog cases + 17 challenges + eight limited ablations.
    Existing frozen experiments are verified and returned without refitting.
    """
    directory = Path(directory).resolve()
    directory.mkdir(parents=True, exist_ok=True)
    if config is None:
        base = SolverConfig(iterations=25, budget_seconds=20.0, candidate_limit=32, max_features=96)
    elif isinstance(config, dict):
        base = SolverConfig(**config)
    elif isinstance(config, SolverConfig):
        base = replace(config)
    else:
        raise TypeError("config must be a SolverConfig or mapping.")
    base.validate()
    plan = _plan(case_ids, base, ablations)
    planned = [{"id": info["id"], "suite": info["suite"], "case_id": info["case_id"], "variant": variant}
               for info, variant, _ in plan]
    request = {
        "cases": list(dict.fromkeys(item["id"] for item in planned)), "config": asdict(base),
        "ablations": bool(ablations), "planned_rows": planned,
        "audit_count": DEVELOPMENT_COUNT, "audit_seed": DEVELOPMENT_SEED,
        "final_count": FINAL_COUNT, "final_seed": FINAL_SEED,
    }
    output = directory / "results_development.json"
    source = source_hashes()
    if output.exists():
        report = read(output)
        if report["request"] != request or report["source_sha256"] != source:
            raise RuntimeError("Sources, physical catalog or configuration changed; use a new experiment directory.")
    else:
        if any((directory / "runs").rglob("model.json")) or (directory / "frozen_v5.json").exists():
            raise RuntimeError("Untracked experiment artifacts exist in this directory.")
        packages = {}
        for name in ("numpy", "scipy", "torch", "sympy", "PyYAML"):
            try:
                packages[name] = version(name)
            except PackageNotFoundError:
                packages[name] = None
        report = {
            "stage": "development", "phase": "training", "created_at_utc": _now(),
            "request": request, "source_sha256": source, "rows": [],
            "environment": {"python": sys.version, "platform": platform.platform(), "packages": packages},
            "training_uses_reference": False, "ablation_semantics": dict(ABLATION_SEMANTICS),
            "timing_definition": "Single-run exploratory solver time per row, including solver setup, physical feature proposals, SVD corrections and search; external admission, independent reference audit and file/report export are excluded. No repeated-timing interval or efficiency-superiority claim.",
        }
    if (directory / "frozen_v5.json").exists():
        _, verified = _verify_freeze(directory)
        return verified
    full_metadata = [info for info, variant, _ in plan if variant == "full"]
    completed = {(row["id"], row["variant"]): row for row in report["rows"]}
    if len(completed) != len(report["rows"]) or not set(completed) <= {(p["id"], p["variant"]) for p in planned}:
        raise RuntimeError("Unexpected or duplicate development records.")
    if report["rows"]:
        _artifact_maps(directory, report)
        _model_map(directory, report)
    # Stage 1 never calls either reference audit.
    for info, variant, cfg in plan:
        key = info["id"], variant
        if key in completed:
            continue
        problem = get_problem(info["id"])
        input_path = Path("inputs") / info["suite"] / (info["case_id"] + ".json")
        if (directory / input_path).exists() and read(directory / input_path) != problem:
            raise RuntimeError("Existing physical input differs.")
        write(directory / input_path, problem)
        configuration = Path("configurations") / info["suite"] / info["case_id"] / (variant + ".json")
        write(directory / configuration, asdict(cfg))
        row = {
            "id": info["id"], "suite": info["suite"], "case_id": info["case_id"], "variant": variant,
            "label": info["label"], "family": info.get("family"), "canonical_family": info.get("canonical_family"),
            "manufactured": info.get("manufactured"), "expected_outcome": info.get("expected_outcome", "unique"),
            "config": asdict(cfg), "configuration_path": configuration.as_posix(),
            "configuration_sha256": sha(directory / configuration),
            "physical_input_path": input_path.as_posix(), "physical_input_sha256": sha(directory / input_path),
            "physical_spec_sha256": _value_sha(problem), "run": None, "history": [], "diagnostics": {},
            "audit": None,
        }
        print("RUN", info["id"], variant, flush=True)
        try:
            analysis = analyze(problem)
            row["analysis"] = analysis
            if analysis["incompatible"]:
                result = None
                row.update(status="incompatible_with_certificate", seconds=0.0)
            else:
                result = solve(problem, cfg)
                run = directory / "runs" / info["suite"] / info["case_id"] / variant
                result.save(run)
                row.update(run=run.relative_to(directory).as_posix(), status=result.status, seconds=result.seconds,
                           diagnostics=result.diagnostics, history=result.history, model_sha256=sha(run / "model.json"))
            row["reported_status"] = outcome(result, analysis)
        except Exception as exc:
            row.update(status="failed", reported_status="failed", seconds=None,
                       error=type(exc).__name__ + ": " + str(exc))
        report["rows"].append(row)
        completed[key] = row
        report["summary"] = summary(report["rows"], full_metadata)
        write(output, report)
        print("FITTED", info["id"], variant, row["status"], flush=True)
    _validate_rows(report)
    if source_hashes() != source:
        raise RuntimeError("Sources changed during development; no freeze created.")
    # Stage 2: every requested fitting attempt is over before labels are read.
    report["phase"] = "development_audit"
    for row in report["rows"]:
        if row.get("audit") is None:
            model = load(_inside(directory, row["run"])) if row.get("run") else None
            row["audit"] = _audit(row, model, DEVELOPMENT_COUNT, DEVELOPMENT_SEED)
            report["summary"] = summary(report["rows"], full_metadata)
            write(output, report)
            print("DEV AUDIT", row["id"], row["variant"], row["audit"]["accepted_solution"], flush=True)
    report["phase"] = "complete"
    report["summary"] = summary(report["rows"], full_metadata)
    write(output, report)
    if source_hashes() != source:
        raise RuntimeError("Sources changed before freezing.")
    inputs, configurations = _artifact_maps(directory, report)
    frozen = {
        "frozen_at_utc": _now(), "source_sha256": source, "models": _model_map(directory, report),
        "physical_inputs": inputs, "configurations": configurations,
        "development_sha256": sha(output), "request_sha256": _value_sha(request),
        "final_seed": FINAL_SEED, "final_count": FINAL_COUNT,
        "training_uses_reference": False, "ablation_semantics": dict(ABLATION_SEMANTICS),
    }
    write(directory / "frozen_v5.json", frozen)
    return report


def run_final(directory="research_v5/validation"):
    """Validate every freeze artifact, load models, and audit new coordinates."""
    directory = Path(directory).resolve()
    frozen, development = _verify_freeze(directory)
    expected = [r for r in development["rows"] if r["variant"] == "full"]
    report = {
        "stage": "final", "seed": FINAL_SEED, "count": FINAL_COUNT, "created_at_utc": _now(),
        "freeze_sha256": sha(directory / "frozen_v5.json"),
        "development_sha256": frozen["development_sha256"], "source_sha256": frozen["source_sha256"],
        "training_uses_reference": False, "ablation_semantics": frozen["ablation_semantics"], "rows": [],
        "timing_definition": "Original single-run exploratory development solver times reused; final audit does not refit or retime models. No repeated-timing or efficiency-superiority claim.",
    }
    for old in development["rows"]:
        row = {key: value for key, value in old.items() if key != "audit"}
        model = load(_inside(directory, row["run"])) if row.get("run") else None
        row["audit"] = _audit(row, model, FINAL_COUNT, FINAL_SEED)
        row["timing_reused"] = True
        report["rows"].append(row)
        report["summary"] = summary(report["rows"], expected)
        write(directory / "results_final.json", report)
        print("FINAL", row["id"], row["variant"], row["audit"]["accepted_solution"], flush=True)
    # Recheck after reading/evaluation to detect concurrent edits.
    _verify_freeze(directory)
    return report
