"""Stability-aware physical neural correction research prototype."""
__version__='5.0.0-research'
