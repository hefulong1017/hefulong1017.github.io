"""Strong one-dimensional classical controls for two public difficult inputs.

Fitting uses only physical coefficients, source and boundary values. Analytic
references are a separate post-fit path. This is not an all-PDE baseline.
Times include physical parsing, mesh/operator/load assembly, linear solution
and interpolator construction; a separate numerical time excludes parsing.
All builds and queries use one numerical-library thread. No winner is assumed.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import statistics
import time

import numpy as np
from scipy.fft import dst, idst
from scipy.interpolate import CubicSpline
from scipy.linalg import solve_banded
from scipy.special import roots_legendre
from scipy.stats import qmc
import sympy as sp
from threadpoolctl import threadpool_limits

from research_v4.challenges import make_problem
from research_v4.spec import Formula, validate_problem
from research_v5.features import _symbolic


METHODS = {
    "helmholtz_near_resonance": ("fd2", "fd4", "p1_fem"),
    "convection_boundary_layer": ("centered_fd", "fitted_fd", "fitted_fd_graded",
                                  "fitted_fd_exponential", "supg_p1", "supg_p1_graded"),
}
DEVELOPMENT_SEED = 84105
DEVELOPMENT_COUNT = 1024


def _physical(case):
    if isinstance(case, str):
        if case not in METHODS: raise ValueError("Only the two declared public comparison inputs are available")
        raw = make_problem(case)
    elif isinstance(case, dict): raw = case
    else: raise ValueError("Provide a declared public input or a physical specification")
    # Name and evaluation metadata are intentionally not accessed.
    problem = {key: raw[key] for key in ("variables", "domain", "fields", "equations", "conditions")}
    problem["name"] = "classical_physical_input"
    for key in ("parameters", "branches"):
        if key in raw: problem[key] = raw[key]
    problem = validate_problem(problem)
    if len(problem["variables"]) != 1 or len(problem["fields"]) != 1 or len(problem["equations"]) != 1 or problem.get("branches"):
        raise ValueError("Classical controls require one scalar constant-coefficient equation and Dirichlet endpoints")
    variable, field = problem["variables"][0], problem["fields"][0]
    formula = Formula(problem["equations"][0], [variable], [field], problem.get("parameters"))
    x = sp.Symbol(variable, real=True)
    jet_names = [field, field + "_" + variable, field + "_" + variable * 2]
    symbols = {name: sp.Symbol(name, real=True) for name in set(jet_names) | {variable}}
    if formula.jets - set(jet_names): raise ValueError("Only second-order scalar equations are supported")
    expression = _symbolic(formula, symbols)
    coefficients = [sp.simplify(sp.diff(expression, symbols[name])) for name in jet_names]
    forcing = sp.simplify(expression.subs({symbols[name]: 0 for name in jet_names}))
    if any(coefficient.free_symbols for coefficient in coefficients) or forcing.free_symbols - {x}:
        raise ValueError("Classical comparison requires constant linear operator coefficients")
    if sp.simplify(expression - forcing - sum(coefficient * symbols[name] for coefficient, name in zip(coefficients, jet_names))) != 0:
        raise ValueError("The supplied operator is not linear")
    c, b, a = map(float, coefficients)
    if not np.isfinite([a, b, c]).all() or a == 0: raise ValueError("A finite nonzero diffusion coefficient is required")
    sign = -1. if a > 0 else 1.
    epsilon, beta, gamma = -sign * a, sign * b, sign * c
    left, right = map(float, problem["domain"][variable])
    values = {}
    for condition in problem["conditions"]:
        if set(condition["where"]) != {variable}: raise ValueError("Require endpoint Dirichlet conditions")
        point = float(condition["where"][variable])
        if point not in (left, right): raise ValueError("Only endpoint conditions are supported")
        op = Formula(condition["operator"], [variable], [field], problem.get("parameters"))
        target = Formula(str(condition["target"]), [variable], [field], problem.get("parameters"), False)
        if op.jets - {field}: raise ValueError("Only Dirichlet data are supported")
        residual = sp.simplify((_symbolic(op, symbols) - _symbolic(target, symbols)).subs(x, sp.Rational(str(point))))
        coefficient = sp.simplify(sp.diff(residual, symbols[field]))
        constant = sp.simplify(residual.subs(symbols[field], 0))
        if coefficient.free_symbols or constant.free_symbols or coefficient == 0 or sp.simplify(residual - coefficient * symbols[field] - constant) != 0:
            raise ValueError("Require scalar affine Dirichlet values")
        value = float(-constant / coefficient)
        if point in values and values[point] != value: raise ValueError("Conflicting endpoint conditions")
        values[point] = value
    if set(values) != {left, right}: raise ValueError("Both Dirichlet endpoints are required")
    source_expression = sp.simplify(-sp.Rational(str(sign)) * forcing)
    def source(points):
        points = np.asarray(points, dtype=float)
        value = -sign * np.asarray(formula(points.reshape(-1, 1), {name: np.zeros(points.size) for name in formula.jets}), dtype=float)
        return np.broadcast_to(value, (points.size,)).copy().reshape(points.shape)
    antisymmetric = (beta == 0 and values[left] == values[right] == 0 and
                     sp.simplify(source_expression.subs(x, sp.Rational(str(left + right)) - x) + source_expression) == 0)
    return {"problem": problem, "variable": variable, "field": field, "left": left, "right": right,
            "epsilon": epsilon, "beta": beta, "gamma": gamma, "boundary": (values[left], values[right]),
            "source": source, "source_expression": source_expression, "symbol": x,
            "source_zero": source_expression == 0, "antisymmetric": bool(antisymmetric)}


def bernoulli(value):
    """Stable Scharfetter-Gummel B(z)=z/(exp(z)-1)."""
    values = np.asarray(value, dtype=float)
    answer = np.empty_like(values)
    small, positive = np.abs(values) < 1e-4, values > 50
    negative = values < -50
    middle = ~(small | positive | negative)
    z = values[small]
    answer[small] = 1 - z / 2 + z * z / 12 - z ** 4 / 720 + z ** 6 / 30240
    z = values[positive]
    answer[positive] = z * np.exp(-z) / (-np.expm1(-z))
    z = values[negative]
    answer[negative] = -z / (-np.expm1(z))
    z = values[middle]
    answer[middle] = z / np.expm1(z)
    return answer


def supg_tau(h, epsilon, beta):
    h = np.asarray(h, dtype=float)
    if beta == 0: return h * h / (12 * epsilon)
    pe = abs(beta) * h / (2 * epsilon)
    factor = np.empty_like(pe)
    small = pe < 1e-3
    factor[small] = pe[small] / 3 - pe[small] ** 3 / 45 + 2 * pe[small] ** 5 / 945
    factor[~small] = 1 / np.tanh(pe[~small]) - 1 / pe[~small]
    return h / (2 * abs(beta)) * factor


def _mesh(data, n, graded):
    left, right = data["left"], data["right"]
    if not graded: return np.linspace(left, right, n + 1)
    beta, epsilon = data["beta"], data["epsilon"]
    if beta == 0: return np.linspace(left, right, n + 1)
    width = min((right - left) / 2, 2 * epsilon / abs(beta) * np.log(n))
    fine = n // 2
    if beta > 0:
        return np.r_[np.linspace(left, right - width, n - fine + 1)[:-1], np.linspace(right - width, right, fine + 1)]
    return np.r_[np.linspace(left, left + width, fine + 1)[:-1], np.linspace(left + width, right, n - fine + 1)]


def _tridiagonal(lower, diagonal, upper, rhs, antisymmetric=False, n=None):
    if antisymmetric:
        half = (n - 1) // 2
        d = diagonal[:half].copy()
        if n % 2: d[-1] -= upper[half - 1]
        l, u, r = lower[:max(half - 1, 0)], upper[:max(half - 1, 0)], rhs[:half]
    else: l, d, u, r = lower, diagonal, upper, rhs
    band = np.zeros((3, len(d)))
    band[0, 1:], band[1], band[2, :-1] = u, d, l
    result = solve_banded((1, 1), band, r, check_finite=True)
    if antisymmetric:
        result = np.r_[result, [0.] if n % 2 == 0 else [], -result[::-1]]
    return result


def _spectral_fd(data, nodes, order):
    if data["beta"] != 0 or any(data["boundary"]): raise ValueError("FD2/4 controls use zero Dirichlet symmetric constant operators")
    n, h = len(nodes) - 1, nodes[1] - nodes[0]
    source = data["source"](nodes[1:-1])
    if order == 4:
        x = data["symbol"]
        for endpoint in (data["left"], data["right"]):
            location = sp.Rational(str(endpoint))
            if any(sp.simplify(sp.diff(data["source_expression"], x, derivative).subs(x, location)) != 0 for derivative in (0, 2)):
                raise ValueError("FD4 odd ghosts require source and source second derivative zero at endpoints")
    if data["antisymmetric"]: source = .5 * (source - source[::-1])
    sine2 = np.sin(np.pi * np.arange(1, n) / (2 * n)) ** 2
    eigenvalues = data["epsilon"] / h ** 2 * (4 * sine2 + (4 / 3 * sine2 ** 2 if order == 4 else 0)) + data["gamma"]
    if np.any(eigenvalues == 0): raise np.linalg.LinAlgError("Exactly singular discrete operator")
    transformed = dst(source, type=1, norm="ortho", workers=1)
    if data["antisymmetric"]: transformed[::2] = 0.
    interior = idst(transformed / eigenvalues, type=1, norm="ortho", workers=1)
    if data["antisymmetric"]: interior = .5 * (interior - interior[::-1])
    return np.r_[0., interior, 0.], {"linear_solver": "DST-I diagonalization of the uniform FD matrix",
        "discrete_smallest_abs_eigenvalue": float(np.min(np.abs(eigenvalues))),
        "odd_ghost_endpoint_diagonal": 29 if order == 4 else None,
        "source_endpoint_compatibility_checked": order == 4}


def _centered(data, nodes):
    h = nodes[1] - nodes[0]
    epsilon, beta, gamma = (data[key] for key in ("epsilon", "beta", "gamma"))
    count = len(nodes) - 2
    lo, up = -epsilon / h ** 2 - beta / (2 * h), -epsilon / h ** 2 + beta / (2 * h)
    diagonal = np.full(count, 2 * epsilon / h ** 2 + gamma)
    rhs = data["source"](nodes[1:-1])
    rhs[0] -= lo * data["boundary"][0]; rhs[-1] -= up * data["boundary"][1]
    value = _tridiagonal(np.full(count - 1, lo), diagonal, np.full(count - 1, up), rhs)
    return np.r_[data["boundary"][0], value, data["boundary"][1]], {"linear_solver": "general tridiagonal LU", "can_oscillate_for_large_cell_peclet": True}


def _fitted(data, nodes):
    if data["gamma"] != 0 or not data["source_zero"]: raise ValueError("Fitted layer control requires zero reaction and homogeneous source")
    widths = np.diff(nodes); epsilon, beta = data["epsilon"], data["beta"]
    p = beta * widths / epsilon
    left_flux, right_flux = epsilon / widths * bernoulli(-p), epsilon / widths * bernoulli(p)
    diagonal = right_flux[:-1] + left_flux[1:]
    lower, upper = -left_flux[1:-1], -right_flux[1:-1]
    rhs = np.zeros(len(nodes) - 2)
    rhs[0] += left_flux[0] * data["boundary"][0]; rhs[-1] += right_flux[-1] * data["boundary"][1]
    interior = _tridiagonal(lower, diagonal, upper, rhs)
    return np.r_[data["boundary"][0], interior, data["boundary"][1]], {"linear_solver": "SG conservative flux tridiagonal LU", "bernoulli_stable_branches": True}


def _fem(data, nodes, stabilized):
    epsilon, beta, gamma = (data[key] for key in ("epsilon", "beta", "gamma"))
    if stabilized and (gamma != 0 or not data["source_zero"]): raise ValueError("SUPG layer control currently requires homogeneous zero-reaction equation")
    widths = np.diff(nodes)
    tau = supg_tau(widths, epsilon, beta) if stabilized else np.zeros_like(widths)
    d = np.array([-1., 1.])
    local = ((epsilon + tau * beta ** 2) / widths)[:, None, None] * np.outer(d, d)
    local += beta / 2 * np.tile(np.array([[-1., 1.], [-1., 1.]]), (len(widths), 1, 1))
    local += gamma * widths[:, None, None] / 6 * np.array([[2., 1.], [1., 2.]])
    diagonal = np.zeros(len(nodes)); diagonal[:-1] += local[:, 0, 0]; diagonal[1:] += local[:, 1, 1]
    lower, upper = local[:, 1, 0], local[:, 0, 1]
    gauss, weights = roots_legendre(12)
    position = nodes[:-1, None] + widths[:, None] * (gauss + 1) / 2
    shape = np.stack([(1 - gauss) / 2, (1 + gauss) / 2], axis=-1)
    load = widths[:, None] / 2 * np.einsum("eq,q,qi->ei", data["source"](position), weights, shape)
    rhs = np.zeros(len(nodes)); rhs[:-1] += load[:, 0]; rhs[1:] += load[:, 1]
    interior_rhs = rhs[1:-1].copy()
    interior_rhs[0] -= lower[0] * data["boundary"][0]; interior_rhs[-1] -= upper[-1] * data["boundary"][1]
    if data["antisymmetric"]: interior_rhs = .5 * (interior_rhs - interior_rhs[::-1])
    interior = _tridiagonal(lower[1:-1], diagonal[1:-1], upper[1:-1], interior_rhs, data["antisymmetric"], len(nodes) - 1)
    return np.r_[data["boundary"][0], interior, data["boundary"][1]], {"linear_solver": "tridiagonal LU in declared reflection subspace" if data["antisymmetric"] else "general tridiagonal LU",
        "mass_matrix": "consistent P1", "load_gauss_order": 12, "supg": stabilized,
        "tau_range": [float(np.min(tau)), float(np.max(tau))],
        "note": "For this constant homogeneous layer, optimal-Pe SUPG and SG have identical nodal values; their relation is not independent evidence." if stabilized else "No mass lumping or post-fit smoothing."}


@dataclass
class ClassicalModel:
    nodes: np.ndarray
    values: np.ndarray
    metadata: dict

    def __post_init__(self):
        self.nodes, self.values = np.array(self.nodes, dtype=float, copy=True), np.array(self.values, dtype=float, copy=True)
        if self.nodes.ndim != 1 or self.values.shape != self.nodes.shape or len(self.nodes) < 3 or not np.isfinite(self.nodes).all() or not np.isfinite(self.values).all() or np.any(np.diff(self.nodes) <= 0):
            raise ValueError("A classical state needs matching finite values on strictly increasing nodes")
        kind = self.metadata["interpolation"]
        if kind not in ("cubic_spline", "piecewise_linear", "local_exponential_flux"):
            raise ValueError("Unknown classical interpolator")
        self._spline = CubicSpline(self.nodes, self.values, bc_type=self.metadata.get("spline_boundary", "not-a-knot")) if kind == "cubic_spline" else None

    def predict(self, points, derivatives=()):
        points = np.asarray(points, dtype=float)
        if points.ndim != 2 or points.shape[1] != 1 or not np.isfinite(points).all() or np.any(points[:, 0] < self.nodes[0]) or np.any(points[:, 0] > self.nodes[-1]):
            raise ValueError("Provide finite in-domain one-dimensional coordinates")
        x = points[:, 0]; field, coordinate = self.metadata["field"], self.metadata["variable"]
        result = {}
        cell = np.clip(np.searchsorted(self.nodes, x, side="right") - 1, 0, len(self.nodes) - 2)
        width = self.nodes[cell + 1] - self.nodes[cell]
        fraction = (x - self.nodes[cell]) / width
        with threadpool_limits(limits=1):
            for name in (field,) + tuple(derivatives):
                if name == field: order = 0
                elif isinstance(name, str) and name.startswith(field + "_") and set(name[len(field) + 1:]) == {coordinate}:
                    order = len(name) - len(field) - 1
                else: raise ValueError("Unknown classical field or derivative")
                if not 0 <= order <= 6: raise ValueError("Derivative request exceeds six")
                if self._spline is not None:
                    if order > 3: raise ValueError("A cubic spline does not provide classical derivatives above three")
                    value = self._spline(x, nu=order)
                elif self.metadata["interpolation"] == "piecewise_linear":
                    if order > 1: raise ValueError("P1 second derivatives are distributions at nodes, not classical point residuals")
                    slope = (self.values[cell + 1] - self.values[cell]) / width
                    value = self.values[cell] + fraction * (self.values[cell + 1] - self.values[cell]) if order == 0 else slope
                else:
                    rate = self.metadata["beta"] / self.metadata["epsilon"]
                    p = rate * width
                    difference = self.values[cell + 1] - self.values[cell]
                    if rate == 0:
                        value = self.values[cell] + fraction * difference if order == 0 else difference / width if order == 1 else np.zeros(len(x))
                    elif rate > 0:
                        if order == 0:
                            ratio = np.exp(p * (fraction - 1)) * (-np.expm1(-p * fraction)) / (-np.expm1(-p))
                            value = self.values[cell] + difference * ratio
                        else: value = difference * rate ** order * np.exp(p * (fraction - 1)) / (-np.expm1(-p))
                    else:
                        if order == 0:
                            ratio = (-np.expm1(p * fraction)) / (-np.expm1(p))
                            value = self.values[cell] + difference * ratio
                        else: value = -difference * rate ** order * np.exp(p * fraction) / (-np.expm1(p))
                if not np.isfinite(value).all(): raise FloatingPointError("Non-finite classical prediction")
                result[name] = np.asarray(value, dtype=float)
        return result

    def to_dict(self):
        return {"nodes": self.nodes.tolist(), "values": self.values.tolist(), "metadata": self.metadata,
                "fitting_uses_reference": False, "state_version": 1}

    @classmethod
    def from_dict(cls, state):
        return cls(np.asarray(state["nodes"], float), np.asarray(state["values"], float), dict(state["metadata"]))


def build_classical(case, method, n):
    """Build from physical inputs. n is intervals, so every model has n+1 nodes."""
    if type(n) is not int or not 4 <= n <= 131072: raise ValueError("Use 4..131072 mesh intervals")
    valid = set(it for methods in METHODS.values() for it in methods)
    if method not in valid: raise ValueError("Unknown classical method")
    if isinstance(case, str) and method not in METHODS.get(case, ()): raise ValueError("Method not declared for this comparison case")
    started = time.perf_counter()
    with threadpool_limits(limits=1):
        data = _physical(case)
        parsed = time.perf_counter()
        graded = method.endswith("_graded")
        nodes = _mesh(data, n, graded)
        if method in ("fd2", "fd4"):
            values, detail = _spectral_fd(data, nodes, int(method[-1]))
        elif method == "centered_fd": values, detail = _centered(data, nodes)
        elif method.startswith("fitted_fd"): values, detail = _fitted(data, nodes)
        else: values, detail = _fem(data, nodes, method.startswith("supg"))
        interpolation = "piecewise_linear" if method in ("p1_fem", "supg_p1", "supg_p1_graded") else "local_exponential_flux" if method == "fitted_fd_exponential" else "cubic_spline"
        metadata = {"method": method, "intervals": n, "nodes": n + 1, "unknowns": n - 1,
            "variable": data["variable"], "field": data["field"], "epsilon": data["epsilon"], "beta": data["beta"], "gamma": data["gamma"],
            "interpolation": interpolation, "spline_boundary": "natural" if method in ("fd2", "fd4") else "not-a-knot",
            "mesh": "Shishkin: half cells in outflow layer; width min(L/2,2*epsilon/abs(beta)*log(n))" if graded else "uniform",
            "min_cell_width": float(np.min(np.diff(nodes))), "max_cell_peclet": float(np.max(abs(data["beta"]) * np.diff(nodes) / (2 * data["epsilon"]))),
            "symmetry_preserved": data["antisymmetric"], "symmetry_derived_from": "exact constant operator, zero endpoint values and anti-reflection source identity",
            "threads": 1, "fitting_uses_reference": False,
            "timing_definition": "total includes physical parse and numerical setup; numerical includes mesh, matrix/load/eigenvalue assembly, solve and interpolator; excludes reference, audit and file I/O", **detail}
        model = ClassicalModel(nodes, values, metadata)
        stopped = time.perf_counter()
    metadata.update(build_seconds=stopped - started, numerical_seconds=stopped - parsed, physical_parse_seconds=parsed - started)
    return model


def _reference(case, points):
    """Analytic post-fit evaluation only, kept out of build_classical."""
    x = points[:, 0]
    if case == "helmholtz_near_resonance": return np.sin(2 * np.pi * x) / (np.pi ** 2 * (3 - 1e-6))
    if case == "convection_boundary_layer": return (np.exp((x - 1) / .001) - np.exp(-1000.)) / (-np.expm1(-1000.))
    raise ValueError("No independent reference declared")


def audit_values(case, predictor, points):
    truth = _reference(case, points)
    actual = np.asarray(predictor(points)["u"])
    error = actual - truth
    return {"relative_l2": float(np.linalg.norm(error) / max(np.linalg.norm(truth), 1e-14)),
            "max_abs_error": float(np.max(np.abs(error))), "rmse": float(np.sqrt(np.mean(error ** 2))),
            "count": len(points), "metric_scope": "function values; no unfair classical second-derivative residual ranking for C0 finite elements"}


def _audit_points(seed=DEVELOPMENT_SEED, count=DEVELOPMENT_COUNT):
    return qmc.Sobol(1, scramble=True, seed=seed).random_base2(int(np.ceil(np.log2(count))))[:count]


def run_comparison(v5_final_results_path, output_path, repeats=3):
    """Optional development comparison, with fixed grids and no tuning on truth.

    Report stores fitted nodal states so a later final audit can re-evaluate
    these exact models on fresh points, without rebuilding or selecting grids.
    The supplied V5 development or final report is preserved as provenance;
    full-variant records with a model path are re-evaluated on the same
    development coordinates. Ablations are disclosed separately and excluded
    from the primary V5 control. The historical argument name is retained.
    """
    if type(repeats) is not int or not 1 <= repeats <= 20: raise ValueError("Use 1..20 independent builds")
    origin, output = Path(v5_final_results_path).resolve(), Path(output_path).resolve()
    payload = json.loads(origin.read_text(encoding="utf-8"))
    points = _audit_points()
    focused = .99 + .01 * _audit_points(DEVELOPMENT_SEED + 1)
    report = {"stage": "classical_development_comparison", "audit_seed": DEVELOPMENT_SEED,
              "audit_count": DEVELOPMENT_COUNT, "repeats": repeats,
              "v5_report_sha256": hashlib.sha256(origin.read_bytes()).hexdigest(), "rows": [],
              "v5_source_stage": payload.get("stage", "unspecified") if isinstance(payload, dict) else "unspecified",
              "not_equal_time_or_unknown_count": True,
              "comparison_scope": "two public difficult 1D inputs only; structural priors, interpolation and setup/query cost are disclosed; no assumed winner",
              "final_audit_policy": "Freeze nodal states/configuration first; evaluate fixed states on fresh points. Do not rebuild, tune n or choose checkpoints using final truth."}
    for case, methods in METHODS.items():
        for method in methods:
            for n in (32, 128, 512):
                models = [build_classical(case, method, n) for _ in range(repeats)]
                model = models[0]
                timing = {key: [item.metadata[key] for item in models] for key in ("build_seconds", "numerical_seconds", "physical_parse_seconds")}
                query_times = []
                for _ in range(repeats):
                    start = time.perf_counter(); model.predict(points); query_times.append(time.perf_counter() - start)
                row = {"case": case, "method": method, "intervals": n, "audit": audit_values(case, model.predict, points),
                       "timing_runs": timing, "median_build_seconds": statistics.median(timing["build_seconds"]),
                       "median_numerical_seconds": statistics.median(timing["numerical_seconds"]),
                       "query_seconds_runs": query_times, "median_query_seconds": statistics.median(query_times),
                       "model_state": model.to_dict()}
                if case == "convection_boundary_layer": row["focused_audit"] = audit_values(case, model.predict, focused)
                report["rows"].append(row)
    v5_rows, excluded_variants = [], []
    def visit(value):
        if isinstance(value, dict):
            # Runner ids may include a suite prefix, while case_id is the
            # explicit physical case. Never let a namespaced id hide that key.
            case = None
            for key in ("case_id", "case", "id"):
                raw_case = value.get(key)
                if isinstance(raw_case, str) and raw_case.rsplit("/", 1)[-1] in METHODS:
                    case = raw_case.rsplit("/", 1)[-1]
                    break
            variant = value.get("variant", "full")
            if case is not None and variant != "full":
                excluded_variants.append({"case": case, "variant": variant,
                    "reason": "Ablation excluded from primary full-method comparison."})
            elif case is not None:
                item = {"case": case, "variant": "full", "original_report_row": value}
                candidate = next((value.get(key) for key in ("model_path", "run", "model") if isinstance(value.get(key), str)), None)
                if candidate:
                    try:
                        from research_v5.solver import load
                        path = Path(candidate); path = path if path.is_absolute() else origin.parent / path
                        model = load(path.parent if path.name == "model.json" else path)
                        item["common_point_audit"] = audit_values(case, model.predict, points)
                        if case == "convection_boundary_layer": item["focused_audit"] = audit_values(case, model.predict, focused)
                    except Exception as exc: item["reevaluation_error"] = f"{type(exc).__name__}: {exc}"
                else: item["reevaluation_error"] = "No model path supplied; original reported error is not relabeled as a common-point audit."
                v5_rows.append(item)
            for nested in value.values(): visit(nested)
        elif isinstance(value, list):
            for nested in value: visit(nested)
    visit(payload)
    report["v5_records"] = v5_rows
    report["excluded_v5_variants"] = excluded_variants
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    return report
