"""V5 CLI: physical solving/querying, controlled experiments and offline reports."""
from __future__ import annotations

import argparse
import csv
from datetime import datetime
import json
from pathlib import Path
import re
import uuid


def _mapping(path):
    import yaml
    data = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("The supplied YAML/JSON file must contain an object.")
    return data


def main(argv=None):
    parser = argparse.ArgumentParser(description="PINNLab V5 · discrete-stability and physical-feature research prototype")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("list", help="List separately named catalog and challenge cases.")
    command = commands.add_parser("solve")
    source = command.add_mutually_exclusive_group(required=True)
    source.add_argument("--case", help="Namespaced id, e.g. catalog/heat_1d or challenges/heat_high_frequency.")
    source.add_argument("--problem", help="Physical problem YAML/JSON; reference metadata is stripped.")
    command.add_argument("--output", default="research_v5/runs/manual")
    command.add_argument("--config")
    command.add_argument("--budget", type=float)
    command.add_argument("--no-structure", action="store_true")
    command.add_argument("--no-stability", action="store_true",
                         help="Disable stopping control only; the correction still uses V5 SVD.")
    command = commands.add_parser("query")
    command.add_argument("--run", required=True)
    command.add_argument("--points", required=True, help="JSON coordinate matrix or a JSON file containing it.")
    command.add_argument("--derivatives", default="")
    command.add_argument("--output", help="Optional .csv or .json output.")
    command = commands.add_parser("experiment")
    command.add_argument("--stage", choices=("development", "final"), default="development")
    command.add_argument("--directory", default="research_v5/validation")
    command.add_argument("--cases", help="Comma-separated namespaced ids; development only.")
    command.add_argument("--config", help="Common SolverConfig YAML/JSON; development only.")
    command.add_argument("--no-ablations", action="store_true")
    command = commands.add_parser("report")
    command.add_argument("--results", default="research_v5/validation/results_final.json")
    command.add_argument("--output", default="../PINNLabV5实测报告.html")
    args = parser.parse_args(argv)
    if args.command == "list":
        from .experiment import case_metadata
        result = case_metadata()
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return result
    if args.command == "solve":
        from .solver import analyze
        from .evaluation import _physical_problem
        from .experiment import get_problem, outcome
        from .solver import SolverConfig, physical_input, solve
        problem = (get_problem(args.case) if args.case else
                   physical_input(_physical_problem(_mapping(args.problem))))
        analysis = analyze(problem)
        if analysis["incompatible"]:
            answer = {"status": "incompatible_with_certificate", "reported_status": "incompatible",
                      "analysis": analysis, "run": None}
        else:
            configuration = _mapping(args.config) if args.config else {
                "iterations": 25, "budget_seconds": 20.0, "candidate_limit": 32, "max_features": 96}
            if args.budget is not None:
                configuration["budget_seconds"] = args.budget
            if args.no_structure:
                configuration["informed_features"] = False
            if args.no_stability:
                configuration["stability_control"] = False
            result = solve(problem, SolverConfig(**configuration),
                           callback=lambda event: print(json.dumps(event, ensure_ascii=False, allow_nan=False), flush=True))
            label = re.sub(r"[^\w-]+", "_", str(problem["name"]), flags=re.UNICODE).strip("_")[:64] or "problem"
            run = Path(args.output) / (datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + label + "_" + uuid.uuid4().hex[:6])
            result.save(run)
            answer = {"run": str(run), "status": result.status, "reported_status": outcome(result, analysis),
                      "seconds": result.seconds, "diagnostics": result.diagnostics, "analysis": analysis,
                      "interpretation": "Solver physical/correction stopping status is not independent reference-error acceptance."}
        print(json.dumps(answer, ensure_ascii=False, indent=2, allow_nan=False))
        return answer
    if args.command == "query":
        import numpy as np
        from .solver import load
        text = args.points.strip()
        coordinates = json.loads(text if text.startswith("[") else Path(text).read_text(encoding="utf-8"))
        model = load(args.run)
        points = np.asarray(coordinates, dtype=float)
        derivatives = tuple(name.strip() for name in args.derivatives.split(",") if name.strip())
        values = model.predict(points, derivatives=derivatives)
        columns = {name: points[:, index].tolist() for index, name in enumerate(model.problem["variables"])}
        columns.update({key: value.tolist() for key, value in values.items()})
        if args.output:
            output = Path(args.output)
            output.parent.mkdir(parents=True, exist_ok=True)
            if output.suffix.lower() == ".csv":
                with output.open("w", encoding="utf-8-sig", newline="") as stream:
                    writer = csv.writer(stream)
                    writer.writerow(columns)
                    writer.writerows(zip(*columns.values()))
            else:
                output.write_text(json.dumps(columns, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
        print(json.dumps(columns, ensure_ascii=False, indent=2, allow_nan=False))
        return columns
    if args.command == "experiment":
        from .experiment import run_development, run_final
        if args.stage == "final":
            if args.cases or args.config or args.no_ablations:
                parser.error("Final evaluation uses the frozen cases/configuration; development overrides are not accepted.")
            report = run_final(args.directory)
        else:
            case_ids = [part.strip() for part in args.cases.split(",") if part.strip()] if args.cases else None
            report = run_development(args.directory, case_ids=case_ids, ablations=not args.no_ablations,
                                     config=_mapping(args.config) if args.config else None)
        print(json.dumps(report["summary"], ensure_ascii=False, indent=2, allow_nan=False))
        return report
    from research_v4.report import build_report
    path = build_report(args.results, args.output)
    print(path)
    return path


if __name__ == "__main__":
    main()
