"""V6 first, with an optional V5 retry inside the remaining common budget.

This compatibility policy is an engineering safeguard, not a new solver or an
independent accuracy certificate. A retry replaces the primary only after its
own physical residual, branch and configured correction stopping tests pass.
Partial fits are never ranked using losses on different adaptive point sets.
No reference, case identifier or evaluation metric participates in dispatch.

The core solvers implement cooperative time limits. Their indivisible setup
and final diagnostic work can overrun a deadline; this wrapper records the
actual total and overrun instead of claiming a hard real-time guarantee.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, fields
import json
from pathlib import Path
import time

import numpy as np

from research_v5.features import V5Bank
from research_v5.solver import (
    Result as V5Result, SolverConfig as V5Config, physical_input,
    solve as solve_v5,
)
from research_v6.basis import V6Bank
from research_v6.solver import (
    Result as V6Result, SolverConfig as V6Config, solve as solve_v6,
)


PASS_STATUS = "physics_and_correction_tolerance"
MINIMUM_RETRY_SECONDS = .05
VERSION = "1.0.0-compatibility-dispatch"


@dataclass
class SolverConfig(V6Config):
    compatibility_retry: bool = True

    def validate(self):
        super().validate()
        if type(self.compatibility_retry) is not bool:
            raise ValueError("compatibility_retry must be a boolean.")


def _configuration(config):
    if config is None:
        config = SolverConfig()
    elif not isinstance(config, SolverConfig):
        if not isinstance(config, V5Config):
            raise TypeError("Expected a V5, V6 or dispatch SolverConfig.")
        config = SolverConfig(**asdict(config))
    config.validate()
    return config


def _subset(config, target):
    values = asdict(config)
    return target(**{field.name: values[field.name] for field in fields(target)})


def _passed(result):
    """Recheck the solver's declared stop using only its own diagnostics."""
    if result.status != PASS_STATUS:
        return False
    d, cfg = result.diagnostics, result.config
    def bounded(key, limit):
        value = d.get(key)
        return isinstance(value, (int, float, np.number)) and np.isfinite(value) and 0 <= value <= limit
    return (
        bounded("training_score", cfg.tolerance)
        and bounded("guard_score", cfg.tolerance)
        and bounded("max_branch_violation", cfg.branch_tolerance)
        and (not cfg.stability_control or (
            d.get("discrete_stability_reliable") is True
            and bounded("function_correction_proxy", cfg.value_tolerance)))
    )


def _state(result, engine):
    if result is None:
        return None
    return {
        "engine": engine, "problem": result.problem,
        "config": asdict(result.config), "features": result.bank.features,
        "coefficients": result.coefficients.tolist(), "history": result.history,
        "status": result.status, "seconds": result.seconds,
        "diagnostics": result.diagnostics, "analysis": result.analysis,
        "training_uses_reference": False,
    }


def _restore(state, engine):
    if state is None:
        return None
    if state.get("engine") != engine:
        raise ValueError("Saved candidate has the wrong engine identity.")
    p = physical_input(state["problem"])
    if engine == "V6":
        cfg = V6Config(**state["config"])
        bank = V6Bank(p["variables"], p["domain"], features=state["features"])
        result_class = V6Result
    else:
        cfg = V5Config(**state["config"])
        bank = V5Bank(p["variables"], [p["domain"][v] for v in p["variables"]], features=state["features"])
        result_class = V5Result
    cfg.validate()
    return result_class(p, cfg, bank, np.asarray(state["coefficients"], float),
                        state["history"], state["status"], state["seconds"],
                        state["diagnostics"], state.get("analysis"))


@dataclass
class Result:
    primary: V6Result
    retry: V5Result | None
    config: SolverConfig
    chosen: str
    seconds: float
    routing: dict
    retry_error: dict | None = None

    @property
    def selected(self):
        return self.primary if self.chosen == "primary" else self.retry

    @property
    def problem(self):
        return self.selected.problem

    @property
    def bank(self):
        return self.selected.bank

    @property
    def coefficients(self):
        return self.selected.coefficients

    @property
    def history(self):
        return self.selected.history

    @property
    def status(self):
        return self.selected.status

    @property
    def analysis(self):
        return self.selected.analysis

    @property
    def diagnostics(self):
        exceeded = bool(self.config.budget_seconds and self.seconds > self.config.budget_seconds)
        return {
            **self.selected.diagnostics,
            "budget_seconds": self.config.budget_seconds,
            "budget_exceeded": exceeded,
            "budget_overrun_seconds": max(0., self.seconds - self.config.budget_seconds) if exceeded else 0.,
            "training_uses_reference": False,
            "dispatch": {
                **self.routing, "chosen": self.chosen,
                "primary_status": self.primary.status,
                "retry_status": self.retry.status if self.retry is not None else None,
                "primary_diagnostics": self.primary.diagnostics,
                "retry_diagnostics": self.retry.diagnostics if self.retry is not None else None,
                "retry_error": self.retry_error,
                "interpretation": "Physical stopping only; fresh independent validation is still required.",
            },
        }

    def predict(self, points, derivatives=()):
        return self.selected.predict(points, derivatives)

    def to_dict(self):
        return {
            "version": VERSION, "problem": self.problem,
            "config": asdict(self.config), "chosen": self.chosen,
            "seconds": self.seconds, "routing": self.routing,
            "primary": _state(self.primary, "V6"),
            "retry": _state(self.retry, "V5"), "retry_error": self.retry_error,
            "diagnostics": self.diagnostics, "training_uses_reference": False,
            "claim": "Compatibility dispatch; no universal or global-error guarantee.",
        }

    def save(self, path):
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)
        (path / "model.json").write_text(
            json.dumps(self.to_dict(), ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
        return path


def load(path):
    path = Path(path)
    state = json.loads((path if path.is_file() else path / "model.json").read_text(encoding="utf-8"))
    if state.get("version") != VERSION:
        raise ValueError("Unsupported dispatch model version.")
    cfg = _configuration(SolverConfig(**state["config"]))
    primary, retry = _restore(state["primary"], "V6"), _restore(state["retry"], "V5")
    chosen = state["chosen"]
    if primary is None or chosen not in ("primary", "retry") or chosen == "retry" and retry is None:
        raise ValueError("Invalid saved candidate selection.")
    if retry is not None and retry.problem != primary.problem:
        raise ValueError("Saved candidates do not describe the same physical input.")
    if chosen == "retry" and not _passed(retry):
        raise ValueError("A saved retry can be selected only after its physical stopping tests pass.")
    return Result(primary, retry, cfg, chosen, float(state["seconds"]),
                  state["routing"], state.get("retry_error"))


def _finish(primary, cfg, started, historical_primary_seconds, callback, *, replay=False):
    """Use one wall clock, optionally preceded by a recorded historical fit."""
    def elapsed():
        return historical_primary_seconds + time.perf_counter() - started
    retry, retry_error, chosen = None, None, "primary"
    routing = {
        "policy": "V6_then_V5_only_if_own_physical_stop_passes",
        "timing_mode": "fixed_primary_replay" if replay else "live_wallclock",
        "recorded_primary_seconds": float(primary.seconds),
        "historical_primary_seconds": float(historical_primary_seconds),
        "retry_wall_seconds": 0., "retry_budget_seconds": None,
        "selection_uses_reference": False, "partial_losses_compared": False,
    }
    if _passed(primary):
        routing["reason"] = "primary_passed_physical_stop"
    elif not cfg.compatibility_retry:
        routing["reason"] = "compatibility_retry_disabled"
    else:
        remaining = max(0., cfg.budget_seconds - elapsed()) if cfg.budget_seconds else None
        if remaining is not None and remaining <= MINIMUM_RETRY_SECONDS:
            routing["reason"] = "insufficient_remaining_budget"
        else:
            retry_cfg = _subset(cfg, V5Config)
            # Include conversion/dispatch overhead in the same common budget.
            remaining = max(0., cfg.budget_seconds - elapsed()) if cfg.budget_seconds else None
            if remaining is not None and remaining <= MINIMUM_RETRY_SECONDS:
                routing["reason"] = "insufficient_remaining_budget"
            else:
                retry_cfg.budget_seconds = remaining if remaining is not None else 0.
                routing["retry_budget_seconds"] = retry_cfg.budget_seconds
                before = time.perf_counter()
                try:
                    retry = solve_v5(physical_input(primary.problem), retry_cfg, callback=callback)
                except (ValueError, FloatingPointError, OverflowError, np.linalg.LinAlgError) as exc:
                    retry_error = {"type": type(exc).__name__, "message": str(exc)}
                routing["retry_wall_seconds"] = max(0., time.perf_counter() - before)
                if retry is not None and _passed(retry):
                    chosen, routing["reason"] = "retry", "retry_passed_physical_stop"
                else:
                    routing["reason"] = "retry_failed_retained_primary" if retry_error is None else "retry_error_retained_primary"
    return Result(primary, retry, cfg, chosen, float(elapsed()), routing, retry_error)


def solve(problem, config=None, callback=None):
    """Fit V6, then spend only the remaining time on a compatible V5 retry."""
    started = time.perf_counter()
    cfg = _configuration(config)
    primary_cfg = _subset(cfg, V6Config)
    p = physical_input(problem)
    if cfg.budget_seconds:
        primary_cfg.budget_seconds = max(np.finfo(float).eps, cfg.budget_seconds - (time.perf_counter() - started))
    primary = solve_v6(p, primary_cfg, callback=callback)
    return _finish(primary, cfg, started, 0., callback)


def apply_fixed_primary(primary_result, config=None, callback=None):
    """Replay the same policy over an already frozen V6 primary without refit.

    Timing is its original recorded seconds plus this dispatch/retry's actual
    wall time. This is a historical replay, not a new simultaneous timing run.
    All primary V6 settings, including its requested total budget, must match.
    No development/final audit fields are read or used for selection.
    """
    started = time.perf_counter()
    cfg = _configuration(config if config is not None else SolverConfig(**asdict(primary_result.config)))
    actual, requested = asdict(primary_result.config), asdict(_subset(cfg, V6Config))
    if actual != requested:
        raise ValueError("Fixed-primary replay requires exactly the original V6 configuration.")
    seconds = float(primary_result.seconds)
    if not np.isfinite(seconds) or seconds < 0:
        raise ValueError("Recorded primary seconds must be finite and nonnegative.")
    return _finish(primary_result, cfg, started, seconds, callback, replay=True)
