"""Audit a fixed-primary compatibility replay without refitting the V6 core."""
from dataclasses import asdict
from pathlib import Path
import argparse
import hashlib
import json
import zipfile

from research_v6 import experiment as core
from research_v6.solver import load as load_primary
from research_v5.experiment import _audit
from .dispatch import apply_fixed_primary, SolverConfig, load

ROOT=Path(__file__).resolve().parents[1]
DIRECTORY=ROOT/'pinn_engine/validation/compatibility'
PRIMARY=ROOT/'research_v6/validation/formal'
FINAL_SEED,FINAL_COUNT=20261201,4096
DEVELOPMENT_SEED,DEVELOPMENT_COUNT=89113,512


def sources():
    result=core.sources()
    for path in (ROOT/'pinn_engine').rglob('*.py'):
        if not set(path.relative_to(ROOT/'pinn_engine').parts)&{'validation','__pycache__'}:
            result[path.relative_to(ROOT).as_posix()]=core.sha(path)
    return dict(sorted(result.items()))


def verify(directory=DIRECTORY):
    directory=Path(directory).resolve()
    core.verify(PRIMARY)
    frozen=core.read(directory/'frozen_dispatch.json')
    development=core.read(directory/'results_development.json')
    if frozen['source_sha256']!=sources() or core.sha(directory/'results_development.json')!=frozen['development_sha256']:
        raise RuntimeError('Compatibility source or development evidence changed.')
    if frozen['primary_freeze_sha256']!=core.sha(PRIMARY/'frozen_v6.json'):
        raise RuntimeError('Primary experiment changed.')
    if (frozen['final_seed'],frozen['final_count'])!=(FINAL_SEED,FINAL_COUNT): raise RuntimeError('Audit plan changed.')
    expected=set()
    for row in development['rows']:
        path=(directory/row['run']/'model.json').resolve()
        if not path.is_relative_to(directory): raise RuntimeError('Invalid model path.')
        expected.add(path)
        if core.sha(path)!=frozen['models'][row['id']]: raise RuntimeError('Compatibility model changed.')
        primary=PRIMARY/row['primary_run']/'model.json'
        if core.sha(primary)!=row['primary_model_sha256']: raise RuntimeError('Primary model changed.')
        model=load(path)
        if model.problem!=core.get_problem(row['id']) or asdict(model.config)!=row['config'] or model.status!=row['status']:
            raise RuntimeError('Loaded model identity no longer matches its recorded input/configuration.')
        if model.chosen!=row['chosen'] or model.routing['timing_mode']!='fixed_primary_replay':
            raise RuntimeError('Dispatch route changed.')
    if {p.resolve() for p in (directory/'runs').rglob('model.json')}!=expected: raise RuntimeError('Compatibility model set changed.')
    with zipfile.ZipFile(directory/'source_before_retries.zip') as archive:
        for name,digest in frozen['source_sha256'].items():
            if hashlib.sha256(archive.read(name)).hexdigest()!=digest: raise RuntimeError('Source snapshot changed.')
    return frozen,development


def run_development(directory=DIRECTORY):
    directory=Path(directory).resolve(); directory.mkdir(parents=True,exist_ok=True)
    if (directory/'frozen_dispatch.json').exists(): return verify(directory)[1]
    if (directory/'results_development.json').exists(): raise RuntimeError('Preserve a partial replay; use a new directory.')
    frozen,primary_report=core.verify(PRIMARY)
    full=[r for r in primary_report['rows'] if r['variant']=='full']
    source=sources()
    with zipfile.ZipFile(directory/'source_before_retries.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for name in source: archive.write(ROOT/name,name)
    report={'stage':'development','phase':'retries','source_sha256':source,
            'primary_freeze_sha256':core.sha(PRIMARY/'frozen_v6.json'),
            'policy':'Every fixed V6 primary: retry V5 only when primary own stop failed and its original common budget has time left; select retry only on its own physical stopping checks.',
            'timing_policy':'Historical fixed-primary replay: recorded original primary time plus actual new retry/dispatch time, not a simultaneous wallclock speed benchmark.',
            'selection_uses_reference':False,'primary_refitting':False,'rows':[]}
    for primary_row in full:
        model=load_primary(PRIMARY/primary_row['run'])
        cfg=SolverConfig(**asdict(model.config))
        result=apply_fixed_primary(model,cfg)
        row={k:v for k,v in primary_row.items() if k not in ('audit','history','diagnostics','run','model_sha256')}
        row.update(algorithm='V6_with_V5_compatibility',primary_run=primary_row['run'],
                   primary_model_sha256=primary_row['model_sha256'],config=asdict(cfg),
                   run='runs/'+primary_row['id'],status=result.status,
                   reported_status='solution' if result.status=='physics_and_correction_tolerance' else 'undetermined',
                   chosen=result.chosen,routing=result.routing,seconds=result.seconds,diagnostics=result.diagnostics)
        result.save(directory/row['run'])
        row['model_sha256']=core.sha(directory/row['run']/'model.json')
        report['rows'].append(row);core.write(directory/'results_development.json',report)
        print('REPLAY',row['id'],row['chosen'],row['status'],flush=True)
    if source!=sources(): raise RuntimeError('Sources changed during compatibility retries.')
    # No reference audit is constructed until all scheduled retries finish.
    for row in report['rows']:
        model=load(directory/row['run'])
        row['audit']=_audit(row,model,DEVELOPMENT_COUNT,DEVELOPMENT_SEED)
    report.update(phase='complete',summary=core.summarize(report['rows']))
    core.write(directory/'results_development.json',report)
    core.write(directory/'frozen_dispatch.json',{'source_sha256':source,
        'development_sha256':core.sha(directory/'results_development.json'),
        'primary_freeze_sha256':core.sha(PRIMARY/'frozen_v6.json'),
        'final_count':FINAL_COUNT,'final_seed':FINAL_SEED,
        'models':{r['id']:r['model_sha256'] for r in report['rows']}})
    verify(directory)
    return report


def run_final(directory=DIRECTORY):
    directory=Path(directory).resolve();frozen,development=verify(directory)
    output=directory/'results_final.json'
    if output.exists(): raise RuntimeError('Preserve the existing final replay audit.')
    report={'stage':'final','phase':'audit','count':FINAL_COUNT,'seed':FINAL_SEED,
            'freeze_sha256':core.sha(directory/'frozen_dispatch.json'),
            'development_sha256':frozen['development_sha256'],'training':False,
            'timing_policy':development['timing_policy'],'primary_refitting':False,
            'selection_uses_reference':False,'rows':[]}
    for old in development['rows']:
        row={k:v for k,v in old.items() if k!='audit'}
        row['audit']=_audit(row,load(directory/row['run']),FINAL_COUNT,FINAL_SEED)
        report['rows'].append(row)
    verify(directory)
    report.update(phase='complete',summary=core.summarize(report['rows']))
    core.write(output,report)
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage',choices=['development','final','verify'],required=True)
    parser.add_argument('--directory',default=str(DIRECTORY))
    args=parser.parse_args()
    if args.stage=='verify': print(json.dumps({'verified':bool(verify(args.directory))}))
    else:
        report=(run_development if args.stage=='development' else run_final)(args.directory)
        print(json.dumps(report['summary'],ensure_ascii=True,indent=2))
