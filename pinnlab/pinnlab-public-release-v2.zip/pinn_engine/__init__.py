"""Budgeted physical-criterion dispatch over frozen research solvers."""

from .dispatch import Result, SolverConfig, apply_fixed_primary, load, solve

__all__ = ["Result", "SolverConfig", "apply_fixed_primary", "load", "solve"]
