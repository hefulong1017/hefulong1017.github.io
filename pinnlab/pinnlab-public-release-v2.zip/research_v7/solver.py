"""Curvature-closed adaptive correction for the V6 structured PINN.

V6 chooses new atoms from a first-order residual range. V7 measures the
nonlinear secant remainder of the PDE residual and closes the trial space under
products of existing atoms that explain that remainder. Re-linearized joint
corrections use backtracking to find feasible improvements. The method is
deliberately experimental: the secant is a local diagnostic, not a
global Hessian or an error bound.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
import json
from pathlib import Path
import time

import numpy as np
from scipy import linalg

from research_v6.solver import SolverConfig as V6Config, Result as V6Result, solve as solve_v6
from research_v6.solver import System
from research_v6.basis import V6Bank
from research_v4.basis import _descriptor_key
from research_v5.solver import physical_input, _accepted


VERSION = "7.0.0-curvature-closed-correction"


@dataclass
class SolverConfig(V6Config):
    """V6 controls plus the curvature closure and correction controls."""

    curvature_probe: float = 0.25
    curvature_candidates: int = 160
    curvature_sources: int = 36
    curvature_batch: int = 8
    curvature_weight: float = 1.0
    algebraic_quota: float = 0.25
    correction_steps: int = 4
    corrector_damping: float = 0.5
    max_refine_seconds: float = 4.0

    def validate(self):
        super().validate()
        if not np.isfinite(self.curvature_probe) or not 1e-4 <= self.curvature_probe <= 2.0:
            raise ValueError("curvature_probe must be in [1e-4, 2]")
        for name, low, high in (("curvature_candidates", 8, 1024), ("curvature_sources", 4, 128),
                                ("curvature_batch", 1, 32), ("correction_steps", 1, 12)):
            value = getattr(self, name)
            if type(value) is not int or not low <= value <= high:
                raise ValueError(f"Invalid {name}")
        if not np.isfinite(self.curvature_weight) or self.curvature_weight < 0:
            raise ValueError("curvature_weight must be nonnegative")
        if not np.isfinite(self.algebraic_quota) or not 0 <= self.algebraic_quota <= 1:
            raise ValueError("algebraic_quota must be in [0,1]")
        if not 0 < self.corrector_damping <= 1:
            raise ValueError("corrector_damping must be in (0,1]")
        if not np.isfinite(self.max_refine_seconds) or self.max_refine_seconds <= 0:
            raise ValueError("max_refine_seconds must be positive")


@dataclass
class Result:
    problem: dict
    config: SolverConfig
    bank: V6Bank
    coefficients: np.ndarray
    history: list
    status: str
    seconds: float
    diagnostics: dict
    base: V6Result | None = None

    def predict(self, points, derivatives=None):
        # Reuse the stable V6 result evaluator by constructing a light result.
        if derivatives is None:
            derivatives = ()
        proxy = V6Result(self.problem, self.config, self.bank, self.coefficients,
                         self.history, self.status, self.seconds, self.diagnostics,
                         self.diagnostics.get("analysis"))
        return proxy.predict(points, derivatives)

    def to_dict(self):
        return {
            "version": VERSION,
            "problem": self.problem,
            "config": asdict(self.config),
            "features": self.bank.features,
            "coefficients": self.coefficients.tolist(),
            "history": self.history,
            "status": self.status,
            "seconds": self.seconds,
            "diagnostics": self.diagnostics,
            "training_uses_reference": False,
            "claim": "curvature_secant_feature_algebra_and_feasible_damped_gauss_newton; global_originality_and_generalization_unproven",
        }

    def save(self, path):
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)
        (path / "model.json").write_text(json.dumps(self.to_dict(), ensure_ascii=False,
                                                     indent=2, allow_nan=False), encoding="utf-8")
        return path


def _indices(old_size, new_size, fields):
    old = np.concatenate([np.arange(old_size) + i * new_size for i in range(fields)])
    new = np.concatenate([np.arange(old_size, new_size) + i * new_size for i in range(fields)])
    return old, new


def _pad(coefficients, old_size, new_size, fields):
    c = np.asarray(coefficients).reshape(fields, old_size)
    return np.c_[c, np.zeros((fields, new_size - old_size))].ravel()


def _projected_curvature(old_j, new_j, curvature, residual, weight=1.0):
    """Score a candidate by the part of the curvature remainder it explains.

    The old Jacobian range is removed before scoring. The residual term keeps
    the closure useful when a secant is small but the current defect is large.
    """
    if old_j.size:
        q = linalg.orth(old_j, rcond=1e-11)
        target = curvature - q @ (q.T @ curvature)
        response = new_j - q @ (q.T @ new_j)
    else:
        target, response = curvature, new_j
    norms = np.linalg.norm(response, axis=0)
    curvature_gain = np.abs(response.T @ target) / np.maximum(norms, 1e-30)
    residual_gain = np.abs(response.T @ residual) / np.maximum(norms, 1e-30)
    score = curvature_gain + float(weight) * residual_gain
    score[(norms <= 1e-12) | ~np.isfinite(score)] = -np.inf
    return score, curvature_gain, residual_gain


def _product_pool(bank, coefficients, fields, limit, source_limit):
    """Build a bounded algebraic closure from active and low-order atoms."""
    magnitudes = np.linalg.norm(np.asarray(coefficients).reshape(fields, bank.size), axis=0)
    # Enumerate the polynomial jet algebra first, then active localized atoms;
    # otherwise a bounded pair pool can spend its entire budget on local
    # products before ever constructing a mixed monomial.
    polynomial = [i for i, f in enumerate(bank.features) if f.get("kind") == "poly"]
    preferred = polynomial + list(np.argsort(-magnitudes))
    source = list(dict.fromkeys(preferred))[:source_limit]
    candidates, seen = [], set(bank._keys)
    for left_index, left in enumerate(source):
        for right in source[left_index:]:
            if len(candidates) >= limit:
                return candidates
            descriptor = {"kind": "product", "factors": [bank.features[left], bank.features[right]]}
            try:
                candidate = bank.append(descriptor).features[-1]
            except (ValueError, TypeError, OverflowError):
                continue
            key = _descriptor_key(candidate)
            if key not in seen:
                seen.add(key)
                candidates.append(candidate)
    return candidates


def _is_algebraic_closure(feature):
    """True for products of polynomial atoms, the jet-algebra closure family."""
    return feature.get("kind") == "product" and all(
        factor.get("kind") == "poly" for factor in feature.get("factors", [])
    )


def _evaluate_secant(system, coefficients, direction, alpha):
    residual, jacobian = system.evaluate(coefficients, True)
    probe = coefficients + alpha * direction
    remainder = (system.evaluate(probe) - residual - alpha * (jacobian @ direction)) / (alpha * alpha)
    return residual, jacobian, remainder


def _feasible_secant(system, control, coefficients, direction, alpha, cfg):
    """Shrink the curvature probe until real-domain and branch checks hold."""
    old_branch = max(system.branch_violation(coefficients), control.branch_violation(coefficients))
    for backtrack in range(14):
        probe_size = alpha * 0.5 ** backtrack
        trial = coefficients + probe_size * direction
        try:
            residual, jacobian, remainder = _evaluate_secant(system, coefficients, direction, probe_size)
            control_residual = control.evaluate(trial)
            loss = system.loss(trial)
            branch = max(system.branch_violation(trial), control.branch_violation(trial))
            feasible = branch <= cfg.branch_tolerance if old_branch <= cfg.branch_tolerance else branch < old_branch
            if np.isfinite(loss) and np.isfinite(control_residual).all() and feasible and np.isfinite(remainder).all():
                return residual, jacobian, remainder, probe_size
        except (FloatingPointError, ValueError, ZeroDivisionError, OverflowError):
            continue
    residual, jacobian = system.evaluate(coefficients, True)
    return residual, jacobian, np.zeros_like(residual), 0.0


def _constrained_direction(system, residual, jacobian):
    lift, z, hard = system.boundary_space()
    if hard:
        direction = z @ linalg.lstsq(jacobian @ z, -residual, cond=1e-11, lapack_driver="gelsy")[0]
        return direction, lift, z, hard
    direction = linalg.lstsq(jacobian, -residual, cond=1e-11, lapack_driver="gelsy")[0]
    return direction, np.zeros_like(direction), np.eye(len(direction)), hard


def _joint_direction(train, control, current, lift, z, hard):
    train_residual, train_jacobian = train.evaluate(current, True)
    control_residual, control_jacobian = control.evaluate(current, True)
    residual = np.r_[train_residual, control_residual] / np.sqrt(2.0)
    jacobian = np.vstack([train_jacobian, control_jacobian]) / np.sqrt(2.0)
    tangent = jacobian @ z
    step = linalg.lstsq(tangent, -residual, cond=1e-11, lapack_driver="gelsy")[0]
    direction = z @ step if hard else step
    return direction


def _correct(train, control, current, direction, lift, z, hard, cfg, deadline):
    """Backtrack a recomputed nonlinear correction against both point groups."""
    if not np.isfinite(direction).all() or np.linalg.norm(direction) <= 1e-14:
        return None
    for backtrack in range(18):
        if time.perf_counter() >= deadline:
            return None
        amplitude = 2.0 ** (-backtrack)
        trial = current + amplitude * direction
        if hard:
            trial = lift + z @ (z.T @ (trial - lift))
        accepted, train_after, control_after, branch = _accepted(train, control, current, trial, cfg)
        if accepted:
            return trial, {"amplitude": amplitude, "backtracks": backtrack,
                           "training_after": train_after, "control_after": control_after,
                           "branch_after": branch}
    return None


def refine(base_result, config=None, callback=None):
    """Apply one curvature-closed nonlinear correction pass to a V6 result."""
    cfg = config or SolverConfig(**asdict(base_result.config))
    if not isinstance(cfg, SolverConfig):
        cfg = SolverConfig(**asdict(cfg))
    cfg.validate()
    problem = physical_input(base_result.problem)
    started = time.perf_counter()
    bank = base_result.bank
    current = np.asarray(base_result.coefficients, dtype=float).copy()
    fields = len(problem["fields"])
    train = System(problem, bank, cfg, cfg.seed)
    guard = System(problem, bank, cfg, cfg.seed + 1, True, train.normalizers)
    residual, jacobian = train.evaluate(current, True)
    # The direction is rescaled to make the secant probe comparable across
    # coefficient normalizations. A zero direction means no local curvature.
    direction, lift, z, hard = _constrained_direction(train, residual, jacobian)
    coefficient_direction_norm = np.linalg.norm(direction)
    value_matrix = train.value_matrix()
    direction_norm = float(np.linalg.norm(value_matrix @ direction) / np.sqrt(max(1, value_matrix.shape[0])))
    if direction_norm > 1e-12:
        # Normalize in function L2, not coefficient space. Raw coefficients can
        # be huge for nearly dependent atoms; choosing alpha from that Euclidean
        # norm makes the secant probe tiny and amplifies cancellation by alpha^-2.
        direction = direction / direction_norm
        alpha = cfg.curvature_probe
        residual, jacobian, remainder, alpha = _feasible_secant(train, guard, current, direction,
                                                                 cfg.curvature_probe, cfg)
    else:
        alpha = 0.0
        remainder = np.zeros_like(residual)
    guard_residual, guard_jacobian = guard.evaluate(current, True)
    if alpha:
        guard_remainder = (guard.evaluate(current + alpha * direction) - guard_residual -
                           alpha * (guard_jacobian @ direction)) / (alpha * alpha)
    else:
        guard_remainder = np.zeros_like(guard_residual)

    candidates = _product_pool(bank, current, fields, cfg.curvature_candidates, cfg.curvature_sources)
    augmented = V6Bank(bank.variables, bank.bounds, features=bank.features + candidates)
    augmented_train = System(problem, augmented, cfg, cfg.seed, normalizers=train.normalizers)
    augmented_guard = System(problem, augmented, cfg, cfg.seed + 1, True, train.normalizers)
    old, new = _indices(bank.size, augmented.size, fields)
    _, augmented_jacobian = augmented_train.evaluate(_pad(current, bank.size, augmented.size, fields), True)
    _, augmented_guard_jacobian = augmented_guard.evaluate(_pad(current, bank.size, augmented.size, fields), True)
    curvature = np.r_[remainder, guard_remainder] / np.sqrt(2.0)
    old_j = np.vstack([jacobian, guard_jacobian]) / np.sqrt(2.0)
    new_j = np.vstack([augmented_jacobian[:, new], augmented_guard_jacobian[:, new]]) / np.sqrt(2.0)
    combined_residual = np.r_[residual, guard_residual] / np.sqrt(2.0)
    scores, curvature_gain, residual_gain = _projected_curvature(
        old_j, new_j, curvature, combined_residual, cfg.curvature_weight)
    order = np.argsort(-scores)
    selected = []
    response_columns = []
    # Reserve a small, explicit quota for the polynomial jet algebra. This is
    # the mechanism that lets a fully nonlinear determinant request mixed
    # monomials such as x^2 y^2 even when localized atoms dominate the score.
    quota = min(int(np.ceil(cfg.curvature_batch * cfg.algebraic_quota)), cfg.curvature_batch)
    algebraic_order = [int(i) for i in order if np.isfinite(scores[i]) and _is_algebraic_closure(candidates[int(i)])]
    # High total jet degree is the first missing direction for determinant-like
    # operators. Keep its response score as the primary order, then break ties
    # toward the largest mixed monomial so the closure is not only low degree.
    algebraic_order.sort(key=lambda i: (float(scores[i]), sum(sum(f["powers"]) for f in candidates[i]["factors"])), reverse=True)
    scan_order = algebraic_order[:quota] + [int(i) for i in order if int(i) not in set(algebraic_order[:quota])]
    for index in scan_order:
        if not np.isfinite(scores[index]):
            continue
        column = new_j[:, index]
        normalized = column / max(np.linalg.norm(column), 1e-30)
        if response_columns and max(abs(float(normalized @ other)) for other in response_columns) > .995:
            continue
        selected.append(candidates[int(index)])
        response_columns.append(normalized)
        if len(selected) >= cfg.curvature_batch:
            break

    history = [{"step": -1, "guard_before": float(guard.loss(current)),
                "action": "curvature_probe", "probe": alpha,
                "direction_norm": float(direction_norm),
                "coefficient_direction_norm": float(coefficient_direction_norm),
                "candidate_count": len(candidates),
                "selected_count": len(selected),
                "selected_curvature_scores": [float(scores[i]) for i in order[:len(selected)] if np.isfinite(scores[i])] }]
    if selected:
        bank = V6Bank(bank.variables, bank.bounds, features=bank.features + selected)
        current = _pad(current, base_result.bank.size, bank.size, fields)
    # Keep the old block normalizers so the before/after losses are measured in
    # exactly the same physical metric. Recomputing scales after adding atoms
    # would make an apparent gain that is only a change of units.
    system = System(problem, bank, cfg, cfg.seed, normalizers=train.normalizers)
    control = System(problem, bank, cfg, cfg.seed + 1, True, train.normalizers)
    lift, z, hard = system.boundary_space()
    base_train = system.loss(current)
    base_guard = control.loss(current)
    residual, jacobian = system.evaluate(current, True)
    guard_residual, guard_jacobian = control.evaluate(current, True)
    combined_j = np.vstack([jacobian, guard_jacobian]) / np.sqrt(2.0)
    combined_r = np.r_[residual, guard_residual] / np.sqrt(2.0)
    if hard:
        direction = z @ linalg.lstsq(combined_j @ z, -combined_r, cond=1e-11, lapack_driver="gelsy")[0]
    else:
        direction = linalg.lstsq(combined_j, -combined_r, cond=1e-11, lapack_driver="gelsy")[0]
    accepted = None
    refinement_started = time.perf_counter()
    refinement_deadline = refinement_started + cfg.max_refine_seconds
    current_train, current_control = base_train, base_guard
    for stage in range(1, cfg.correction_steps + 1):
        if time.perf_counter() >= refinement_deadline:
            break
        direction = _joint_direction(system, control, current, lift, z, hard)
        trial = _correct(system, control, current, direction, lift, z, hard, cfg, refinement_deadline)
        if trial is None:
            history.append({"action": "curvature_corrector_rejected", "stage": stage,
                            "step": stage - 1, "training_before": current_train,
                            "control_before": current_control})
            break
        candidate, correction_info = trial
        train_loss, guard_loss = system.loss(candidate), control.loss(candidate)
        branch = max(system.branch_violation(candidate), control.branch_violation(candidate))
        row = {"action": "curvature_correction_accepted", "stage": stage,
               "step": stage - 1, "guard_before": current_control,
               "training_before": current_train, "training": train_loss,
               "control": guard_loss, "branch": branch, **correction_info}
        history.append(row)
        if train_loss < current_train and guard_loss < current_control and branch <= cfg.branch_tolerance:
            accepted = candidate
            current_train, current_control = train_loss, guard_loss
            current = candidate
        else:
            break
        if callback:
            callback(row)
    if accepted is None:
        bank = base_result.bank
        current = np.asarray(base_result.coefficients, dtype=float).copy()
        system = System(problem, bank, cfg, cfg.seed, normalizers=train.normalizers)
        control = System(problem, bank, cfg, cfg.seed + 1, True, train.normalizers)
        current_train, current_control = system.loss(current), control.loss(current)
    status = "curvature_correction_applied" if accepted is not None else "no_curvature_improvement"
    seconds = time.perf_counter() - started
    diagnostics = {
        "training_score": float(current_train),
        "guard_score": float(current_control),
        "max_branch_violation": float(max(system.branch_violation(current), control.branch_violation(current))),
        "features_before": base_result.bank.size,
        "features_after": bank.size,
        "curvature_probe": alpha,
        "curvature_direction_norm": float(direction_norm),
        "curvature_coefficient_direction_norm": float(coefficient_direction_norm),
        "curvature_candidates": len(candidates),
        "curvature_selected": len(selected),
        "curvature_selected_descriptors": selected,
        "curvature_closure": "products_of_existing_atoms_scored_against_projected_second_order_residual_secant",
        "correction": "relinearized_joint_gauss_newton_with_backtracking_and_train_control_branch_acceptance",
        "training_uses_reference": False,
        "analysis": base_result.diagnostics.get("analysis") if base_result.diagnostics else None,
    }
    # Presentation and downstream plotting can use the familiar V6 metrics;
    # the V7-specific scores above remain the source for the new mechanism.
    if base_result.diagnostics:
        for key in ("function_correction_proxy", "guard_stability", "discrete_stability_reliable",
                    "training_stability"):
            if key in base_result.diagnostics:
                diagnostics[key] = base_result.diagnostics[key]
    return Result(problem, cfg, bank, current, history, status, seconds, diagnostics, base_result)


def solve(problem, config=None, callback=None):
    """Fit V6 once, then apply the V7 curvature closure."""
    cfg = config or SolverConfig()
    if not isinstance(cfg, SolverConfig):
        cfg = SolverConfig(**asdict(cfg))
    cfg.validate()
    started = time.perf_counter()
    base = solve_v6(problem, cfg, callback=callback)
    elapsed = time.perf_counter() - started
    remaining = cfg.max_refine_seconds if not cfg.budget_seconds else min(
        cfg.max_refine_seconds, max(0.0, cfg.budget_seconds - elapsed))
    if remaining <= 0:
        diagnostics = dict(base.diagnostics)
        diagnostics.update(v7_skipped="shared_time_budget_exhausted",
                           v6_fit_seconds=float(base.seconds),
                           training_uses_reference=False,
                           analysis=base.analysis)
        return Result(base.problem, cfg, base.bank, base.coefficients.copy(), base.history,
                      "curvature_budget_exhausted", elapsed, diagnostics, base)
    refined = refine(base, replace(cfg, max_refine_seconds=remaining), callback=callback)
    refined.seconds = time.perf_counter() - started
    refined.diagnostics["v6_fit_seconds"] = float(base.seconds)
    refined.diagnostics["v7_refinement_seconds"] = float(refined.seconds - base.seconds)
    refined.diagnostics["shared_budget_seconds"] = float(cfg.budget_seconds)
    refined.config = cfg
    return refined


def load(path):
    path = Path(path)
    state = json.loads((path if path.is_file() else path / "model.json").read_text(encoding="utf-8"))
    problem = physical_input(state["problem"])
    cfg = SolverConfig(**state["config"])
    bank = V6Bank(problem["variables"], problem["domain"], features=state["features"])
    return Result(problem, cfg, bank, np.asarray(state["coefficients"], float), state["history"],
                  state["status"], state["seconds"], state["diagnostics"])
