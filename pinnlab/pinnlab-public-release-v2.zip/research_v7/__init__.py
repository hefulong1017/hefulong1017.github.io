"""Research V7: curvature-closed adaptive corrections for physics-informed trial spaces."""

from .solver import SolverConfig, Result, solve, refine

__all__ = ["SolverConfig", "Result", "solve", "refine"]
