"""Fixed-plan V6 development, strict dependency freeze, fresh-point audit.

All fitting attempts finish before reference audits. Final evaluation loads
exact models only. Templates and previous-version successes add no votes.
"""
from __future__ import annotations

from dataclasses import asdict, fields, replace
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import zipfile

from research_v5.experiment import case_metadata, get_problem, _audit, source_hashes as v5_sources
from research_v5.solver import SolverConfig as V5Config, solve as v5_solve, load as v5_load
from research_v5.solver import analyze
from .solver import SolverConfig, solve, load

ROOT = Path(__file__).resolve().parents[1]
DEVELOPMENT_COUNT, DEVELOPMENT_SEED = 1024, 84105
FINAL_COUNT, FINAL_SEED = 4096, 20261129
DIFFICULT = ('helmholtz_near_resonance', 'heat_high_frequency', 'convection_boundary_layer', 'coupled_oscillator')
PREVIOUS_FAILURES = ('burgers_standard', 'fisher_kpp', 'viscous_hamilton_jacobi')
ABLATIONS = {'no_adaptive_birth': 'adaptive_birth', 'no_defect_centers': 'defect_centers',
             'no_predicted_filter': 'predicted_filter', 'no_coverage_probes': 'coverage_probes'}


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def canonical(value): return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
def value_sha(value): return hashlib.sha256(canonical(value).encode('utf-8')).hexdigest()
def read(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def write(path, value):
    path=Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temporary=path.with_name(path.name+'.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    temporary.replace(path)


def sources():
    result=v5_sources()
    excluded={'validation','__pycache__','.pytest_cache'}
    for directory in (ROOT/'research_v6',ROOT/'pde_frontend'):
        for path in directory.rglob('*.py'):
            if not set(path.relative_to(directory).parts)&excluded:
                result[path.relative_to(ROOT).as_posix()]=sha(path)
    return dict(sorted(result.items()))


def _inside(directory, relative):
    path=(directory/relative).resolve()
    if not path.is_relative_to(directory.resolve()): raise RuntimeError('Artifact escaped the experiment directory.')
    return path


def plan(config=None):
    cfg=config or SolverConfig()
    cfg.validate()
    info=[r for r in case_metadata() if r['suite']=='catalog' or r['case_id'] in DIFFICULT]
    answer=[]
    for row in info:
        answer.append(dict(row,variant='full',algorithm='V6',config=asdict(cfg)))
    for case in PREVIOUS_FAILURES:
        row=next(r for r in info if r['case_id']==case)
        for variant,flag in ABLATIONS.items():
            if not hasattr(cfg,flag): raise RuntimeError('Final core must expose ablation flag: '+flag)
            answer.append(dict(row,variant=variant,algorithm='V6',config=asdict(replace(cfg,**{flag:False}))))
        names={f.name for f in fields(V5Config)}
        base=V5Config(**{k:v for k,v in asdict(cfg).items() if k in names})
        base.validate()
        answer.append(dict(row,variant='v5_equal_budget',algorithm='V5',config=asdict(base)))
    return answer


def summarize(rows):
    full=[r for r in rows if r['variant']=='full']
    catalog=[r for r in full if r['suite']=='catalog']
    hard=[r for r in full if r['suite']=='challenges']
    accepted=lambda r: bool(r.get('audit',{}).get('accepted_solution'))
    families=sorted({r['canonical_family'] for r in catalog})
    passed=[family for family in families if all(accepted(r) for r in catalog if r['canonical_family']==family)]
    return {'record_count':len(rows),'full_record_count':len(full),
        'ablation_record_count':sum(r['variant'].startswith('no_') for r in rows),
        'equal_budget_v5_baseline_count':sum(r['variant']=='v5_equal_budget' for r in rows),
        'catalog':{'requested_cases':len(catalog),'canonical_families':len(families),
                   'accepted_numerical_solutions':sum(map(accepted,catalog)),'passed_families':len(passed),
                   'passed_family_names':passed,'unresolved_case_ids':[r['id'] for r in catalog if not accepted(r)]},
        'challenges':{'requested_cases':len(hard),'accepted_numerical_solutions':sum(map(accepted,hard)),
                      'unresolved_case_ids':[r['id'] for r in hard if not accepted(r)]},
        'coverage_rule':'Every requested catalog case in a canonical family must pass the V6 stopping gate AND independent physical/reference audit. Prior V5 results and 44 editable templates add no votes.'}


def verify(directory):
    directory=Path(directory).resolve()
    frozen=read(directory/'frozen_v6.json')
    if sources()!=frozen['source_sha256']: raise RuntimeError('Frozen dependencies changed.')
    if sha(directory/'results_development.json')!=frozen['development_sha256']: raise RuntimeError('Development evidence changed.')
    development=read(directory/'results_development.json')
    if value_sha(development['request'])!=frozen['request_sha256']: raise RuntimeError('Request changed.')
    if frozen['final_count']!=FINAL_COUNT or frozen['final_seed']!=FINAL_SEED: raise RuntimeError('Final parameters changed.')
    identities={(r['id'],r['variant']) for r in development['request']['plan']}
    actual=[(r['id'],r['variant']) for r in development['rows']]
    if set(actual)!=identities or len(set(actual))!=len(actual): raise RuntimeError('Run plan changed.')
    expected_models=set()
    for row in development['rows']:
        key=row['id']+'/'+row['variant']
        input_path=_inside(directory,row['input_path']); config_path=_inside(directory,row['config_path'])
        if sha(input_path)!=row['input_sha256'] or sha(config_path)!=row['config_sha256']: raise RuntimeError('Input or configuration changed.')
        if canonical(read(input_path))!=canonical(get_problem(row['id'])) or canonical(read(config_path))!=canonical(row['config']):
            raise RuntimeError('Physical source/config identity changed.')
        expected=frozen['artifacts'][key]
        if expected['input_sha256']!=row['input_sha256'] or expected['config_sha256']!=row['config_sha256']:
            raise RuntimeError('Artifact identity changed.')
        if row.get('run'):
            path=_inside(directory,row['run'])/'model.json'; expected_models.add(path)
            if sha(path)!=row['model_sha256'] or expected['model_sha256']!=row['model_sha256']: raise RuntimeError('Model changed.')
            state=read(path)
            if canonical(state['problem'])!=canonical(read(input_path)) or canonical(state['config'])!=canonical(row['config']) or state['status']!=row['status']:
                raise RuntimeError('Saved model no longer matches its physical run.')
    if {p.resolve() for p in (directory/'runs').rglob('model.json')}!=expected_models: raise RuntimeError('Untracked or missing fitted models.')
    with zipfile.ZipFile(directory/'source_before_fitting.zip') as archive:
        if set(archive.namelist())!=set(frozen['source_sha256']): raise RuntimeError('Source snapshot set changed.')
        for name,digest in frozen['source_sha256'].items():
            if hashlib.sha256(archive.read(name)).hexdigest()!=digest: raise RuntimeError('Source snapshot mismatch.')
    return frozen,development


def run_development(directory='research_v6/validation/formal'):
    directory=Path(directory).resolve(); directory.mkdir(parents=True,exist_ok=True)
    config=SolverConfig()
    schedule=plan(config); dependency=sources()
    request={'plan':schedule,'source_sha256':dependency,'development_count':DEVELOPMENT_COUNT,
             'development_seed':DEVELOPMENT_SEED,'final_count':FINAL_COUNT,'final_seed':FINAL_SEED,
             'all_fits_before_reference_audits':True,'training_uses_reference':False,
             'timing_policy':'Single exploratory solve times, no repeated speed-superiority inference.'}
    output=directory/'results_development.json'
    if (directory/'frozen_v6.json').exists():
        frozen,report=verify(directory)
        if report['request']!=request: raise RuntimeError('Frozen plan differs; use a new directory.')
        return report
    if output.exists():
        report=read(output)
        if report['request']!=request: raise RuntimeError('Source or plan changed; use a new directory.')
    else:
        with zipfile.ZipFile(directory/'source_before_fitting.zip','w',zipfile.ZIP_DEFLATED) as archive:
            for name in dependency: archive.write(ROOT/name,name)
        report={'stage':'development','phase':'fitting','request':request,'rows':[]}
        write(output,report)
    done={(r['id'],r['variant']) for r in report['rows']}
    for planned in schedule:
        if (planned['id'],planned['variant']) in done: continue
        row=dict(planned)
        p=get_problem(row['id'])
        stem=row['id']+'/'+row['variant']
        row['input_path']='inputs/'+stem+'.json'; row['config_path']='configurations/'+stem+'.json'
        write(directory/row['input_path'],p); write(directory/row['config_path'],row['config'])
        row['input_sha256']=sha(directory/row['input_path']); row['config_sha256']=sha(directory/row['config_path'])
        row['analysis']=analyze(p)
        try:
            if row['analysis']['incompatible']:
                row.update(status='incompatible',reported_status='incompatible',seconds=0.)
            else:
                if row['algorithm']=='V6': result=solve(p,SolverConfig(**row['config']))
                else: result=v5_solve(p,V5Config(**row['config']))
                row['run']='runs/'+stem; result.save(directory/row['run'])
                row.update(status=result.status,reported_status='solution' if result.status=='physics_and_correction_tolerance' else 'undetermined',
                           seconds=result.seconds,diagnostics=result.diagnostics,history=result.history,
                           model_sha256=sha(directory/row['run']/'model.json'))
        except Exception as exc:
            row.update(status='failed',reported_status='failed',error=f'{type(exc).__name__}: {exc}',seconds=None)
        report['rows'].append(row); write(output,report)
        print('FITTED',row['id'],row['variant'],row['status'],flush=True)
    if sources()!=dependency: raise RuntimeError('Source changed during fits; preserve this run and start a new directory.')
    report['phase']='development_audit'
    for row in report['rows']:
        if 'audit' in row: continue
        model=(load if row['algorithm']=='V6' else v5_load)(directory/row['run']) if row.get('run') else None
        row['audit']=_audit(row,model,DEVELOPMENT_COUNT,DEVELOPMENT_SEED)
        write(output,report)
    report.update(phase='complete',summary=summarize(report['rows']))
    write(output,report)
    if sources()!=dependency: raise RuntimeError('Source changed before freeze.')
    artifacts={r['id']+'/'+r['variant']:{'input_sha256':r['input_sha256'],'config_sha256':r['config_sha256'],
                'model_sha256':r.get('model_sha256')} for r in report['rows']}
    write(directory/'frozen_v6.json',{'created_at_utc':datetime.now(timezone.utc).isoformat(),
        'source_sha256':dependency,'development_sha256':sha(output),'request_sha256':value_sha(request),
        'final_count':FINAL_COUNT,'final_seed':FINAL_SEED,'artifacts':artifacts})
    verify(directory)
    return report


def run_final(directory='research_v6/validation/formal'):
    directory=Path(directory).resolve(); frozen,development=verify(directory)
    output=directory/'results_final.json'
    if output.exists():
        previous=read(output)
        if previous.get('phase')=='complete' and previous.get('freeze_sha256')==sha(directory/'frozen_v6.json'):
            return previous
        raise RuntimeError('Preserve an earlier partial final evaluation; do not overwrite it.')
    report={'stage':'final','phase':'audit','count':FINAL_COUNT,'seed':FINAL_SEED,
            'freeze_sha256':sha(directory/'frozen_v6.json'),'development_sha256':frozen['development_sha256'],
            'source_sha256':frozen['source_sha256'],'training':False,'rows':[]}
    for old in development['rows']:
        row={k:v for k,v in old.items() if k!='audit'}
        model=(load if row['algorithm']=='V6' else v5_load)(directory/row['run']) if row.get('run') else None
        row['audit']=_audit(row,model,FINAL_COUNT,FINAL_SEED)
        row['timing_reused']=True
        report['rows'].append(row)
        write(output,report)
        print('FINAL',row['id'],row['variant'],row['audit'].get('accepted_solution'),flush=True)
    verify(directory)
    report.update(phase='complete',summary=summarize(report['rows']))
    write(output,report)
    return report
