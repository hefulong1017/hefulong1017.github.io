"""Defect/cross-correction driven batches of integrable local trial functions.

The experimental contribution is residual-range-defect localization plus
cross-guard projected-response filtering and nonlinear gain-ratio acceptance.
Homogeneous envelopes repair an older constraint-space failure. They, RBFs,
least squares, greedy enrichment and response tests individually have known
precedents. No universal, global error or originality claim is made here.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
import json
from pathlib import Path
import time

import numpy as np
import torch
from scipy import linalg
from threadpoolctl import threadpool_limits

from research_v4.basis import _descriptor_key, _multiindices
from research_v4.solver import _direction_candidates, _response_step, _birth_pool
from research_v5.features import propose
from research_v5.structured_modes import structured_proposals
from research_v5.stability import linearized_stability
from research_v5.solver import (SolverConfig as V5Config, System, Result as V5Result,
    physical_input, analyze, IncompatibleProblem, _finite_initial, _snapshot, _accepted)
from .basis import V6Bank, homogeneous_envelope, wrap
from .adaptation import adaptive_pool, defect_cloud, response_ranking
from .coverage import AdaptiveSystem, scale_probes, merge_points, coverage_statistics


@dataclass
class SolverConfig(V5Config):
    budget_seconds: float = 12.
    iterations: int = 100
    max_features: int = 112
    max_births: int = 24
    adaptive_candidates: int = 80
    adaptive_centers: int = 4
    birth_batch: int = 6
    refit_steps: int = 3
    envelope_repair: bool = True
    adaptive_birth: bool = True
    defect_centers: bool = True
    correction_disagreement: bool = True
    predicted_filter: bool = True
    gain_ratio_control: bool = True
    joint_response: bool = True
    coverage_probes: bool = True
    coverage_per_feature: int = 12
    coverage_max_points: int = 384
    minimum_gain_ratio: float = .01
    stagnation_fraction: float = .005

    def validate(self):
        super().validate()
        for name, low, high in (("adaptive_candidates", 8, 256), ("adaptive_centers", 1, 12),
                                ("birth_batch", 1, 24), ("refit_steps", 1, 12),
                                ("coverage_per_feature", 4, 64), ("coverage_max_points", 16, 2048)):
            if type(getattr(self, name)) is not int or not low <= getattr(self, name) <= high: raise ValueError("Invalid " + name)
        for name in ("minimum_gain_ratio", "stagnation_fraction"):
            if not np.isfinite(getattr(self, name)) or not 0 <= getattr(self, name) < 1: raise ValueError("Invalid " + name)


@dataclass
class Result(V5Result):
    def to_dict(self):
        return {"version": "6.0.0-research", "problem": self.problem, "config": asdict(self.config),
            "features": self.bank.features, "coefficients": self.coefficients.tolist(),
            "history": self.history, "status": self.status, "seconds": self.seconds,
            "diagnostics": self.diagnostics, "analysis": self.analysis,
            "training_uses_reference": False,
            "claim": "residual_range_defect_and_cross_correction_driven_batch_enrichment; originality_and_generality_unproven"}

    def save(self, path):
        path = Path(path); path.mkdir(parents=True, exist_ok=True)
        (path / "model.json").write_text(json.dumps(self.to_dict(), ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
        return path


def load(path):
    path = Path(path)
    state = json.loads((path if path.is_file() else path / "model.json").read_text(encoding="utf-8"))
    p = physical_input(state["problem"])
    bank = V6Bank(p["variables"], p["domain"], features=state["features"])
    return Result(p, SolverConfig(**state["config"]), bank, np.asarray(state["coefficients"], float),
                  state["history"], state["status"], state["seconds"], state["diagnostics"], state.get("analysis"))


def _pad(c, old, new, fields):
    return np.c_[c.reshape(fields, old), np.zeros((fields, new - old))].ravel()


def _indices(old, new, fields):
    old_columns = np.concatenate([np.arange(old) + index * new for index in range(fields)])
    new_columns = np.concatenate([np.arange(old, new) + index * new for index in range(fields)])
    return old_columns, new_columns


def conservative_gain_ratio(actual_train, actual_guard, predicted_train, predicted_guard):
    """Each point group must justify its own nonlinear prediction."""
    if predicted_train <= 0 or predicted_guard <= 0: return 0.
    return min(float(actual_train / predicted_train), float(actual_guard / predicted_guard), 1e300)


def _step(a, g, c, direction, cfg, deadline=None):
    ra, ja = a.evaluate(c, True); rg, jg = g.evaluate(c, True)
    before = max(float(np.dot(ra, ra)), float(np.dot(rg, rg)))
    for k in range(14):
        if deadline is not None and time.perf_counter() >= deadline: break
        amplitude = 2. ** (-k)
        candidate = c + amplitude * direction
        okay, la, lg, branch = _accepted(a, g, c, candidate, cfg)
        if not okay: continue
        predicted_a = float(np.dot(ra, ra) - np.linalg.norm(ra + amplitude * (ja @ direction)) ** 2)
        predicted_g = float(np.dot(rg, rg) - np.linalg.norm(rg + amplitude * (jg @ direction)) ** 2)
        actual_a, actual_g = float(np.dot(ra, ra) - la ** 2), float(np.dot(rg, rg) - lg ** 2)
        ratio = conservative_gain_ratio(actual_a, actual_g, predicted_a, predicted_g)
        if cfg.gain_ratio_control and (min(predicted_a, predicted_g) <= 0 or ratio < cfg.minimum_gain_ratio): continue
        return candidate, {"training_after": la, "guard_after": lg, "damping": amplitude,
            "predicted_train_gain": predicted_a, "predicted_guard_gain": predicted_g,
            "actual_train_gain": actual_a, "actual_guard_gain": actual_g,
            "actual_to_predicted_gain_ratio": ratio, "relative_actual_gain": min(actual_a, actual_g) / max(before, 1e-30)}
    return None


def solve(problem, config=None, callback=None):
    cfg = config or SolverConfig()
    if isinstance(cfg, V5Config) and not isinstance(cfg, SolverConfig): cfg = SolverConfig(**asdict(cfg))
    cfg.validate(); p = physical_input(problem)
    started = time.perf_counter()
    deadline = started + cfg.budget_seconds if cfg.budget_seconds else None
    def expired(): return deadline is not None and time.perf_counter() >= deadline
    torch.set_num_threads(cfg.threads)
    analysis = analyze(p)
    if analysis["incompatible"]: raise IncompatibleProblem(analysis)
    bank = V6Bank(p["variables"], p["domain"], poly_degree=cfg.poly_degree, neural_frequencies=cfg.neural_frequencies)
    added = []
    if cfg.informed_features:
        for feature in structured_proposals(p, bank) + propose(p, bank):
            if len(added) >= cfg.max_initial_informed or bank.size >= cfg.max_features: break
            if _descriptor_key(feature) not in bank._keys:
                bank = bank.append(feature); added.append(feature)
    a = System(p, bank, cfg, cfg.seed); normalizers = a.normalizers
    g = System(p, bank, cfg, cfg.seed + 1, True, normalizers)
    c, z, hard = a.boundary_space()
    envelope = homogeneous_envelope(p) if hard and cfg.envelope_repair else None
    repaired = 0
    if envelope:
        for total in range(3):
            for power in _multiindices(len(p["variables"]), total):
                feature = wrap({"kind": "poly", "powers": list(power)}, envelope)
                if bank.size < cfg.max_features and _descriptor_key(feature) not in bank._keys:
                    bank = bank.append(feature); repaired += 1
        a = System(p, bank, cfg, cfg.seed, normalizers=normalizers)
        g = System(p, bank, cfg, cfg.seed + 1, True, normalizers)
        c, z, hard = a.boundary_space()
    c = _finite_initial(a, g, c, z, hard)
    values = (a.value_matrix(), g.value_matrix())
    history, births, status = [], 0, "iteration_limit"
    dimension = len(p["variables"])
    train_extra, guard_extra = np.empty((0, dimension)), np.empty((0, dimension))
    last_enrichment = {}
    def state(aa, gg, cc, zz, vv): return _snapshot(aa, gg, cc, zz, cfg, vv, analysis)
    def correction(aa, gg, cc, zz, vv, snapshot):
        if not cfg.joint_response: return snapshot["train_stability"].correction
        ra, ja = aa.evaluate(cc, True); rg, jg = gg.evaluate(cc, True)
        return linearized_stability(np.r_[ra, rg] / np.sqrt(2), np.vstack([ja, jg]) / np.sqrt(2),
            np.vstack(vv), zz, mass_rtol=cfg.mass_rtol, jacobian_rtol=cfg.jacobian_rtol).correction
    def passed(s):
        return max(s["train"], s["guard"]) <= cfg.tolerance and s["branch"] <= cfg.branch_tolerance and (
            not cfg.stability_control or s["reliable"] and s["proxy"] <= cfg.value_tolerance)
    def install(newbank, proposed_train=None, proposed_guard=None):
        aa = AdaptiveSystem(p, newbank, cfg, cfg.seed, normalizers=normalizers,
                            extra_points=train_extra if proposed_train is None else proposed_train)
        gg = AdaptiveSystem(p, newbank, cfg, cfg.seed + 1, True, normalizers,
                            extra_points=guard_extra if proposed_guard is None else proposed_guard)
        lift, zz, hh = aa.boundary_space()
        return aa, gg, lift, zz, hh, (aa.value_matrix(), gg.value_matrix())
    def enrich(snapshot, step):
        nonlocal last_enrichment
        last_enrichment = {"attempted": True}
        cloud, indicator, defect_info = defect_cloud(g, c, snapshot["train_stability"], snapshot["guard_stability"],
            disagreement=cfg.correction_disagreement, value_floor=cfg.value_tolerance)
        if cfg.adaptive_birth:
            pool, proposal_info = adaptive_pool(g, c, cloud, indicator, envelope, cfg, step)
        else:
            pool = [wrap(feature, envelope) for feature in _birth_pool(bank, cfg.adaptive_candidates, cfg.max_frequency)]
            proposal_info = {"candidates": len(pool), "source": "fixed_v4_pool"}
        pool = [feature for feature in pool if _descriptor_key(feature) not in bank._keys]
        if not pool or expired(): return None
        augmented = V6Bank(bank.variables, bank.bounds, features=bank.features + pool)
        aa = AdaptiveSystem(p, augmented, cfg, cfg.seed, normalizers=normalizers, extra_points=train_extra)
        gg = AdaptiveSystem(p, augmented, cfg, cfg.seed + 1, True, normalizers, extra_points=guard_extra)
        padded = _pad(c, bank.size, augmented.size, len(p["fields"]))
        try:
            ra, ja = aa.evaluate(padded, True); rg, jg = gg.evaluate(padded, True)
        except (FloatingPointError, ValueError, ZeroDivisionError): return None
        old_indices, new_indices = _indices(bank.size, augmented.size, len(p["fields"]))
        old_j, new_j = ja[:, old_indices], ja[:, new_indices]
        ranking, predicted = response_ranking(ra, old_j, new_j, z, rg,
            np.c_[jg[:, old_indices], jg[:, new_indices]], filter_enabled=cfg.predicted_filter, joint=cfg.joint_response)
        # Scores aggregate individual field responses for a shared scalar atom.
        score = predicted["scores"].reshape(len(p["fields"]), len(pool))
        aggregate = np.max(score, axis=0)
        order = np.argsort(-aggregate)
        chosen, chosen_indices, response_columns = [], [], []
        for index in order:
            if not np.isfinite(aggregate[index]) or expired(): break
            column = new_j[:, [field * len(pool) + index for field in range(len(p["fields"]))]].ravel()
            norm = np.linalg.norm(column)
            normalized = column / norm if norm > 0 else column
            if response_columns and max(abs(float(normalized @ other)) for other in response_columns) > .995: continue
            chosen.append(pool[index]); chosen_indices.append(int(index)); response_columns.append(normalized)
            if len(chosen) >= min(cfg.birth_batch, cfg.max_features - bank.size): break
        if not chosen: return None
        newbank = bank
        for descriptor in chosen: newbank = newbank.append(descriptor)
        coverage_start = time.perf_counter()
        proposed_train, proposed_guard = train_extra, guard_extra
        if cfg.coverage_probes:
            probe_seed = cfg.seed + 1009 * (step + 1)
            proposed_train = merge_points(train_extra, scale_probes(chosen, bank.bounds, cfg.coverage_per_feature, probe_seed), cfg.coverage_max_points)
            proposed_guard = merge_points(guard_extra, scale_probes(chosen, bank.bounds, cfg.coverage_per_feature, probe_seed, True), cfg.coverage_max_points)
        coverage_seconds = time.perf_counter() - coverage_start
        setup_start = time.perf_counter()
        aa, gg, lift, zz, hh, vv = install(newbank, proposed_train, proposed_guard)
        setup_seconds = time.perf_counter() - setup_start
        padded = _pad(c, bank.size, newbank.size, len(p["fields"]))
        current = lift + zz @ (zz.T @ (padded - lift)) if hh else padded
        last_enrichment = {"attempted": True, "selected_candidate_indices": chosen_indices,
            "coverage_generation_seconds": coverage_seconds, "augmented_system_setup_seconds": setup_seconds,
            "old_guard_on_augmented_points": gg.loss(padded), "old_training_on_augmented_points": aa.loss(padded),
            "adaptive_training_points": len(proposed_train), "adaptive_control_points": len(proposed_guard),
            "normalizers_reused": True, "same_augmented_points_for_old_and_new": True,
            "coverage": coverage_statistics(chosen, bank.bounds, aa.interior_points, gg.interior_points)}
        accepted_info, best = [], None
        for _ in range(cfg.refit_steps):
            if expired(): break
            s = state(aa, gg, current, zz, vv)
            trial = _step(aa, gg, current, correction(aa, gg, current, zz, vv, s), cfg, deadline)
            if trial is None: break
            current, info = trial; accepted_info.append(info)
            okay, la, lg, branch = _accepted(aa, gg, padded, current, cfg)
            if okay: best = (current.copy(), state(aa, gg, current, zz, vv))
            if best is not None and passed(best[1]): break
        if best is None:
            last_enrichment["rejection"] = "No nonlinear refit improved both identical augmented point sets."
            return None
        return best[0], newbank, aa, gg, zz, hh, vv, {"features_added": chosen,
            "defect": defect_info, "proposals": proposal_info, "accepted_refit_steps": accepted_info,
            "selected_candidate_indices": chosen_indices,
            "selected_projected_gain": [float(aggregate[index]) for index in chosen_indices],
            "coverage_attempt": last_enrichment,
            "guard_after": best[1]["guard"], "function_correction_after": best[1]["proxy"]}, proposed_train, proposed_guard
    with threadpool_limits(limits=cfg.threads):
        for step in range(cfg.iterations):
            if expired(): status = "budget"; break
            snapshot = state(a, g, c, z, values)
            if passed(snapshot): status = "physics_and_correction_tolerance"; break
            record = {"step": step, "features": bank.size, "seconds": time.perf_counter() - started,
                "training_before": snapshot["train"], "guard_before": snapshot["guard"],
                "function_correction_before": snapshot["proxy"], "stability_reliable": snapshot["reliable"],
                "relative_unrepresented_residual": snapshot["train_stability"].relative_remaining_residual,
                "births": births, "action": "no_accepted_direction"}
            history.append(record)
            trial = _step(a, g, c, correction(a, g, c, z, values, snapshot), cfg, deadline)
            need_birth = trial is None or trial[1]["relative_actual_gain"] < cfg.stagnation_fraction
            accepted = False
            if need_birth and cfg.allow_birth and births < cfg.max_births and bank.size < cfg.max_features and not expired():
                extension = enrich(snapshot, step)
                record["enrichment_attempt"] = last_enrichment
                if extension is not None:
                    c, bank, a, g, z, hard, values, info, train_extra, guard_extra = extension
                    births += 1; record.update(action="defect_response_batch", **info); accepted = True
            if not accepted and trial is not None:
                c, info = trial; record.update(action="function_metric_correction", **info); accepted = True
            if not accepted and cfg.response_search and not expired():
                for direction in _direction_candidates(z, bank, p["fields"], cfg.seed + step):
                    if expired(): break
                    response = _response_step(a, g, c, direction, cfg, deadline)
                    if response is not None:
                        c = response.pop("coefficients"); record.update(action="high_order_response", **response); accepted = True; break
            if callback: callback(record)
            if not accepted:
                status = "budget" if expired() else "inconclusive"; break
        snapshot = state(a, g, c, z, values)
        if passed(snapshot): status = "physics_and_correction_tolerance"
        elif expired(): status = "budget"
    seconds = time.perf_counter() - started
    diagnostics = {"training_score": snapshot["train"], "guard_score": snapshot["guard"],
        "max_branch_violation": snapshot["branch"], "function_correction_proxy": snapshot["proxy"],
        "discrete_stability_reliable": snapshot["reliable"], "features": bank.size, "births": births,
        "training_stability": snapshot["train_stability"].to_dict(), "guard_stability": snapshot["guard_stability"].to_dict(),
        "initial_informed_features": added, "envelope_repair_features": repaired,
        "condition_eliminated_at_sample_points": hard, "budget_seconds": cfg.budget_seconds,
        "budget_exceeded": bool(cfg.budget_seconds and seconds > cfg.budget_seconds),
        "budget_overrun_seconds": max(0., seconds - cfg.budget_seconds) if cfg.budget_seconds else 0.,
        "training_uses_reference": False, "mechanism": "residual_range_defect_plus_cross_correction_disagreement; projected_cross_guard_batch_gain; actual_to_predicted_nonlinear_gain_ratio",
        "adaptive_training_points": train_extra.tolist(), "adaptive_control_points": guard_extra.tolist(),
        "training_point_count": len(a.interior_points), "control_point_count": len(g.interior_points),
        "interpretation": "Discrete local diagnostics and adaptively used guard points, not a global error/existence certificate. Fresh post-freeze tests are required."}
    return Result(p, cfg, bank, c, history, status, seconds, diagnostics, analysis)
