"""Integrable local Gaussian and homogeneous-envelope features, jets to six.

These are trial functions, not independently fitted derivative values. The
envelope is a conventional constraint repair; it is not the new contribution.
"""
from __future__ import annotations

import itertools
import math

import numpy as np
from numpy.polynomial import polynomial, hermite_e

from research_v4.basis import _descriptor_key, _vector
from research_v5.features import V5Bank, _canonical_v5


def canonical(descriptor, dimension, depth=0):
    if not isinstance(descriptor, dict) or depth > 6: raise ValueError("Invalid V6 feature nesting")
    kind = descriptor.get("kind")
    if kind == "gaussian":
        if set(descriptor) != {"kind", "center", "width"}: raise ValueError("A Gaussian needs center and physical widths")
        center = _vector(descriptor["center"], dimension, "center")
        width = _vector(descriptor["width"], dimension, "width")
        if any(not 1e-8 <= value <= 1e8 for value in width): raise ValueError("Gaussian widths must be in 1e-8..1e8")
        return {"kind": kind, "center": center, "width": width}
    if kind == "enveloped":
        if set(descriptor) != {"kind", "base", "powers"}: raise ValueError("An enveloped function needs a base and endpoint powers")
        powers = descriptor["powers"]
        if not isinstance(powers, (list, tuple)) or len(powers) != dimension or any(not isinstance(pair, (list, tuple)) or len(pair) != 2 or any(type(value) is not int or not 0 <= value <= 4 for value in pair) for pair in powers):
            raise ValueError("Envelope endpoint powers must be integer pairs in 0..4")
        base = canonical(descriptor["base"], dimension, depth + 1)
        return {"kind": kind, "base": base, "powers": [list(pair) for pair in powers]} if any(any(pair) for pair in powers) else base
    if kind == "product":
        factors = descriptor.get("factors")
        if set(descriptor) != {"kind", "factors"} or not isinstance(factors, (list, tuple)) or not 1 <= len(factors) <= 4:
            raise ValueError("A product requires one to four factors")
        flattened = []
        for raw in factors:
            factor = canonical(raw, dimension, depth + 1)
            if factor["kind"] == "product": flattened.extend(factor["factors"])
            elif factor["kind"] != "poly" or any(factor["powers"]): flattened.append(factor)
        if len(flattened) > 4: raise ValueError("A product may have at most four factors")
        if not flattened: return {"kind": "poly", "powers": [0] * dimension}
        if len(flattened) == 1: return flattened[0]
        return {"kind": kind, "factors": sorted(flattened, key=_descriptor_key)}
    return _canonical_v5(descriptor, dimension)


class V6Bank(V5Bank):
    def __init__(self, variables, bounds, features=None, poly_degree=2, neural_frequencies=1):
        super().__init__(variables, bounds, features=[] if features is not None else None,
                         poly_degree=poly_degree, neural_frequencies=neural_frequencies)
        if features is None: return
        if not isinstance(features, (list, tuple)): raise ValueError("A bank needs a descriptor sequence")
        unique = {}
        for descriptor in features:
            descriptor = canonical(descriptor, len(self.variables))
            unique.setdefault(_descriptor_key(descriptor), descriptor)
        self.features, self._keys = list(unique.values()), frozenset(unique)
        self.size = len(self.features)

    def append(self, descriptor):
        descriptor = canonical(descriptor, len(self.variables))
        features = list(self.features)
        if _descriptor_key(descriptor) not in self._keys: features.append(descriptor)
        return V6Bank(self.variables, self.bounds, features=features,
                      poly_degree=self.poly_degree, neural_frequencies=self.neural_frequencies)

    def values(self, points, names):
        points = np.asarray(points, dtype=float)
        if points.ndim != 2 or points.shape[1] != len(self.variables) or not np.isfinite(points).all(): raise ValueError("Invalid physical points")
        orders = self._orders(names)
        leaves = {}
        def collect(feature):
            if feature["kind"] == "product":
                for factor in feature["factors"]: collect(factor)
            elif feature["kind"] == "enveloped": collect(feature["base"])
            elif feature["kind"] != "gaussian": leaves.setdefault(_descriptor_key(feature), feature)
        for feature in self.features: collect(feature)
        needed = {beta for alpha in orders.values() for beta in itertools.product(*(range(order + 1) for order in alpha))}
        def name(alpha):
            suffix = "".join(variable * order for variable, order in zip(self.variables, alpha))
            return "u_" + suffix if suffix else "u"
        old = V5Bank(self.variables, self.bounds, features=list(leaves.values()))
        old_values = old.values(points, [name(alpha) for alpha in needed])
        columns = {key: index for index, key in enumerate(leaves)}
        length = np.ptp(self.bounds, axis=1)
        unit = (points - self.bounds[:, 0]) / length
        cache, axis_cache = {}, {}
        def envelope(powers, alpha):
            answer = np.ones(len(points))
            for axis, ((left, right), order) in enumerate(zip(powers, alpha)):
                key = (axis, left, right, order)
                if key not in axis_cache:
                    coefficients = np.r_[np.zeros(left), [(-1) ** j * math.comb(right, j) for j in range(right + 1)]]
                    scale = ((left + right) ** (left + right) / (left ** left * right ** right)) if left and right else 1.
                    axis_cache[key] = scale * polynomial.polyval(unit[:, axis], polynomial.polyder(coefficients, order)) / length[axis] ** order
                answer *= axis_cache[key]
            return answer
        def multiply(left, right, alpha):
            answer = np.zeros(len(points))
            for beta in itertools.product(*(range(order + 1) for order in alpha)):
                remainder = tuple(a - b for a, b in zip(alpha, beta))
                answer += math.prod(math.comb(a, b) for a, b in zip(alpha, beta)) * left(beta) * right(remainder)
            return answer
        def product(factors, alpha):
            if len(factors) == 1: return evaluate(factors[0], alpha)
            return multiply(lambda beta: evaluate(factors[0], beta), lambda beta: product(factors[1:], beta), alpha)
        def evaluate(feature, alpha):
            key = (_descriptor_key(feature), alpha)
            if key not in cache:
                kind = feature["kind"]
                if kind == "gaussian":
                    widths = np.asarray(feature["width"])
                    q = (points - feature["center"]) / widths
                    value = np.exp(-.5 * np.sum(q * q, axis=1))
                    for axis, order in enumerate(alpha):
                        value *= (-1) ** order * hermite_e.hermeval(q[:, axis], [0.] * order + [1.]) / widths[axis] ** order
                elif kind == "enveloped":
                    value = multiply(lambda beta: envelope(feature["powers"], beta), lambda beta: evaluate(feature["base"], beta), alpha)
                elif kind == "product": value = product(feature["factors"], alpha)
                else: value = old_values[name(alpha)][:, columns[_descriptor_key(feature)]]
                cache[key] = value
            return cache[key]
        result = {}
        with np.errstate(over="raise", invalid="raise", divide="raise"):
            for requested, alpha in orders.items():
                value = np.column_stack([evaluate(feature, alpha) for feature in self.features]) if self.features else np.empty((len(points), 0))
                if not np.isfinite(value).all(): raise FloatingPointError("Invalid V6 physical jet")
                result[requested] = value
        return result


def homogeneous_envelope(problem):
    """Sufficient common envelope for local value conditions on box faces.

    Derivative/periodic conditions are deliberately left to the numerical
    constraint algebra. This does not silently fix unknown Neumann values.
    """
    from research_v4.spec import Formula
    powers = [[0, 0] for _ in problem["variables"]]
    for condition in problem["conditions"]:
        expression = Formula(condition["operator"], problem["variables"], problem["fields"], problem.get("parameters"))
        if condition.get("kind") == "periodic" or not expression.affine() or any("_" in name for name in expression.jets) or len(condition.get("where", {})) != 1:
            return None
        variable, value = next(iter(condition["where"].items()))
        lower, upper = problem["domain"][variable]
        if value not in (lower, upper): return None
        powers[problem["variables"].index(variable)][int(value == upper)] = 1
    return powers


def wrap(feature, powers):
    return {"kind": "enveloped", "base": feature, "powers": powers} if powers else feature
