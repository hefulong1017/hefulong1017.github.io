"""Predeclared development comparisons; reference access only after fitting.

No final seed is defined here. Freeze source/models/configs before declaring a
fresh final seed, and retain every failed/unfinished row in subsequent reports.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict, replace
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

from research_v5.evaluation import catalog_problem, audit_catalog
from .solver import SolverConfig, solve, load


DEFAULT_CASES = ("burgers_standard", "fisher_kpp", "viscous_hamilton_jacobi")


def _write(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def core_hashes():
    root = Path(__file__).resolve().parent
    return {name: hashlib.sha256((root / name).read_bytes()).hexdigest()
            for name in ("solver.py", "basis.py", "adaptation.py", "coverage.py", "benchmark.py")}


def configurations(budget_seconds=12., size="standard"):
    base = SolverConfig(budget_seconds=float(budget_seconds))
    if size == "large":
        base = replace(base, interior=256, guard=512, max_features=176, adaptive_candidates=112, birth_batch=8)
    elif size != "standard": raise ValueError("Unknown predeclared scale")
    return {"full": base, "fixed_centers": replace(base, defect_centers=False),
            "no_disagreement": replace(base, correction_disagreement=False),
            "no_predicted_filter": replace(base, predicted_filter=False),
            "no_gain_ratio": replace(base, gain_ratio_control=False),
            "train_only_response": replace(base, joint_response=False),
            "no_coverage_probes": replace(base, coverage_probes=False),
            "fixed_pool": replace(base, adaptive_birth=False),
            "no_envelope": replace(base, envelope_repair=False)}


def run_development(directory, cases=DEFAULT_CASES, variants=("full",), budget_seconds=12., size="standard"):
    directory = Path(directory).resolve()
    if (directory / "request.json").exists(): raise FileExistsError("Preserve earlier development evidence; use a new directory")
    cfgs = configurations(budget_seconds, size)
    for variant in variants:
        if variant not in cfgs: raise ValueError("Unknown ablation")
    request = {"stage": "development", "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "cases": list(cases), "variants": list(variants), "size": size,
        "configurations": {variant: asdict(cfgs[variant]) for variant in variants},
        "source_sha256": core_hashes(), "audit_count": 1024, "audit_seed": 84105,
        "reference_uses": "independent post-fit audit only; no private references provided to solve",
        "audit_phase": "All planned fits finish before any reference audit is called.",
        "threads": 1, "time_budget_scope": "soft solver time budget per case; setup and final sensitivity included, reference and file export excluded"}
    _write(directory / "request.json", request)
    report = {"stage": "development", "request": request, "rows": []}
    for case_id in cases:
        physical = catalog_problem(case_id)
        for variant in variants:
            print("RUN", case_id, variant, flush=True)
            row = {"case_id": case_id, "variant": variant, "config": asdict(cfgs[variant])}
            try:
                result = solve(physical, cfgs[variant])
                path = directory / case_id / variant
                result.save(path)
                row.update(status=result.status, seconds=result.seconds,
                    run=str(path.relative_to(directory)), diagnostics=result.diagnostics,
                    history=result.history, model_sha256=hashlib.sha256((path / "model.json").read_bytes()).hexdigest())
                row["audit_pending"] = True
            except Exception as exc:
                row.update(status="failed", error=f"{type(exc).__name__}: {exc}", accepted_numerical_solution=False)
            report["rows"].append(row)
            _write(directory / "results.json", report)
            print("DONE", case_id, variant, row["status"], row.get("audit", {}).get("reference_errors", {}).get("relative_l2"), flush=True)
    # The fit phase is complete. Reload exactly the recorded models, so no
    # reference value can influence a later fit or checkpoint choice in this
    # predeclared development request.
    for row in report["rows"]:
        if not row.get("run"): continue
        model = load(directory / row["run"])
        row["audit"] = audit_catalog(row["case_id"], model.predict, count=1024, seed=84105)
        row["accepted_numerical_solution"] = bool(row["status"] == "physics_and_correction_tolerance" and row["audit"]["accepted_solution"])
        row["audit_pending"] = False
        _write(directory / "results.json", report)
        print("AUDIT", row["case_id"], row["variant"], row["audit"].get("reference_errors", {}).get("relative_l2"), flush=True)
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True)
    parser.add_argument("--cases", nargs="+", default=list(DEFAULT_CASES))
    parser.add_argument("--variants", nargs="+", default=["full"])
    parser.add_argument("--budget", type=float, default=12.)
    parser.add_argument("--size", choices=("standard", "large"), default="standard")
    args = parser.parse_args()
    run_development(args.output, args.cases, args.variants, args.budget, args.size)
