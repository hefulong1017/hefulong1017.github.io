"""Residual-range defect, correction disagreement and adaptive feature births.

The score is computed from physical residuals/linearizations, never references.
Guard data validate predicted gains and actual nonlinear gains. They are not
an untouched final test set; fresh-point post-freeze audits remain necessary.
"""
from __future__ import annotations

import itertools
import math

import numpy as np
from scipy import linalg
import torch

from research_v4.basis import _descriptor_key, _multiindices
from .basis import canonical, wrap


def defect_cloud(system, coefficients, train_report, guard_report, *, disagreement=True, value_floor=1e-6):
    """Locate unrepresented r+J*delta and cross-fit correction disagreement."""
    points = system.interior_points
    count, fields = len(points), len(system.problem["fields"])
    defect = guard_report.linearized_residual
    block_scores, cursor = [], 0
    for block in system.blocks:
        size = len(block.points)
        if cursor + size <= len(defect): block_scores.append((block.points, np.abs(defect[cursor:cursor + size])))
        cursor += size
    coordinates = np.vstack([item[0] for item in block_scores])
    raw = np.concatenate([item[1] for item in block_scores])
    scale = max(float(np.sqrt(np.mean(raw ** 2))), 1e-15)
    indicator = raw / scale
    difference = guard_report.correction - train_report.correction
    phi = system.bank.values(points, ["u"])["u"]
    delta = phi @ difference.reshape(fields, system.bank.size).T
    mismatch = np.linalg.norm(delta, axis=1) / np.sqrt(fields)
    denominator = max(train_report.function_correction_norm, guard_report.function_correction_norm, value_floor)
    if disagreement:
        # Equation blocks share the interior coordinates; conditions have
        # their own defect scores and are not assigned fictitious corrections.
        for index in range(system.equation_count):
            start = index * count
            indicator[start:start + count] += mismatch / denominator
    return coordinates, indicator, {"unrepresented_residual_norm": float(np.linalg.norm(defect)),
        "relative_unrepresented_residual": guard_report.relative_remaining_residual,
        "correction_disagreement_rms": float(np.sqrt(np.mean(mismatch ** 2))),
        "score_formula": "abs(r+J*delta)/rms(defect) + abs(delta_train-delta_guard)/max(correction_rms,value_floor) on equation points"}


def select_centers(points, scores, bounds, count=4, adaptive=True, seed=42):
    bounds = np.asarray(bounds, float)
    unit = (np.asarray(points) - bounds[:, 0]) / np.ptp(bounds, axis=1)
    scores = np.maximum(np.asarray(scores, float), 0)
    if not adaptive:
        rng = np.random.default_rng(seed)
        return bounds[:, 0] + rng.uniform(.1, .9, (count, len(bounds))) * np.ptp(bounds, axis=1)
    # A defect-weighted centroid captures paired lobes around a narrow front;
    # subsequent centers maximize defect times distance from existing centers.
    weights = scores ** 2
    centroid = np.average(unit, axis=0, weights=weights) if np.sum(weights) > 0 else np.mean(unit, axis=0)
    centers = [centroid]
    distance = np.linalg.norm(unit - centroid, axis=1)
    for _ in range(count - 1):
        index = int(np.argmax(scores * np.maximum(distance, .02)))
        centers.append(unit[index])
        distance = np.minimum(distance, np.linalg.norm(unit - unit[index], axis=1))
    return bounds[:, 0] + np.asarray(centers) * np.ptp(bounds, axis=1)


def local_scales(system, coefficients):
    """Jet sensitivities provide diffusion/advection/reaction length hints."""
    dimension = len(system.problem["variables"])
    lengths = np.ptp(system.bank.bounds, axis=1)
    scales = .2 * lengths
    fields = system.problem["fields"]
    reshaped = coefficients.reshape(len(fields), system.bank.size)
    for block in system.blocks[:system.equation_count]:
        latent = {name: torch.tensor(block.phi[name] @ reshaped[block.indices[name]], dtype=torch.float64, requires_grad=True) for name in block.names}
        value = block.formula(torch.tensor(block.points, dtype=torch.float64), latent)
        if not isinstance(value, torch.Tensor) or not value.requires_grad: continue
        partials = torch.autograd.grad(value, list(latent.values()), torch.ones_like(value), allow_unused=True)
        sensitivity = {name: float(np.quantile(np.abs(partial.detach().numpy()), .8)) if partial is not None else 0. for name, partial in zip(block.names, partials)}
        for axis, variable in enumerate(system.problem["variables"]):
            for field in fields:
                diffusion = sensitivity.get(field + "_" + variable * 2, 0.)
                first, zero = sensitivity.get(field + "_" + variable, 0.), sensitivity.get(field, 0.)
                if diffusion > 1e-14:
                    length = diffusion / max(first, np.sqrt(diffusion * zero), 1e-12)
                    scales[axis] = np.clip(length, .001 * lengths[axis], .7 * lengths[axis])
    return scales


def adaptive_pool(system, coefficients, cloud_points, scores, powers, cfg, step):
    bank = system.bank
    dimension, lengths = len(bank.variables), np.ptp(bank.bounds, axis=1)
    centers = select_centers(cloud_points, scores, bank.bounds, cfg.adaptive_centers,
                             cfg.defect_centers, cfg.seed + step)
    scales = local_scales(system, coefficients)
    candidates, seen = [], set(bank._keys)
    def add(feature):
        feature = canonical(wrap(feature, powers), dimension)
        key = _descriptor_key(feature)
        if key not in seen:
            seen.add(key); candidates.append(feature)
    def tanh(normal, center):
        normal = np.asarray(normal, float)
        return {"kind": "tanh", "direction": (normal * lengths / 2).tolist(),
                "bias": float(normal @ (np.mean(bank.bounds, axis=1) - center))}
    # Mixed temporal lifts repair the zero-tangent Burgers failure and supply
    # smooth global changes. Harmonic scales come from existing physical modes.
    time_axis = bank.variables.index("t") if "t" in bank.variables else None
    temporal_powers = [0, 1, 2, 3, 4] if time_axis is not None else [0]
    trig_modes = []
    def leaves(feature):
        if feature["kind"] == "product":
            for factor in feature["factors"]: yield from leaves(factor)
        elif feature["kind"] == "enveloped": yield from leaves(feature["base"])
        else: yield feature
    for descriptor in bank.features:
        for primitive in leaves(descriptor):
            if primitive["kind"] in ("sin", "cos") and (time_axis is None or primitive["frequency"][time_axis] == 0):
                frequency = np.asarray(primitive["frequency"], float)
                if any(frequency) and not any(np.array_equal(frequency, old) for old in trig_modes): trig_modes.append(frequency)
    # Interleave global and local families; filtering later compares their
    # actual operator responses rather than trusting a fixed dictionary order.
    local, global_features = [], []
    for frequency in trig_modes[:3]:
        for multiplier in (1, 2, 3, 4, 6, 8):
            for order in temporal_powers:
                for kind in ("sin", "cos"):
                    factors = [{"kind": kind, "frequency": (frequency * multiplier).tolist()}]
                    if order:
                        polynomial = [0] * dimension; polynomial[time_axis] = order
                        factors.append({"kind": "poly", "powers": polynomial})
                    global_features.append(factors[0] if len(factors) == 1 else {"kind": "product", "factors": factors})
    for center in centers:
        for factor in (1., 4., .5):
            width = np.minimum(np.maximum(scales * factor, .003 * lengths), lengths)
            local.append({"kind": "gaussian", "center": center.tolist(), "width": width.tolist()})
        names = ["u_" + variable for variable in bank.variables]
        derivatives = bank.values(center[None, :], names)
        field_coefficients = coefficients.reshape(len(system.problem["fields"]), bank.size)
        gradient = np.array([float(derivatives[name][0] @ field_coefficients[0]) for name in names])
        norm = np.linalg.norm(gradient * lengths)
        normals = []
        if norm > 1e-10: normals.append(gradient / max(norm, 1e-10) / .2)
        for axis in range(dimension):
            if axis != time_axis:
                direction = np.zeros(dimension); direction[axis] = 1 / scales[axis]
                normals.append(direction)
        for normal in normals:
            for factor in (.25, 1., 4.):
                primitive = tanh(normal * factor, center)
                local.extend([primitive, {"kind": "product", "factors": [primitive, primitive]}])
                if time_axis is not None:
                    for order in (1, 2):
                        polynomial = [0] * dimension; polynomial[time_axis] = order
                        local.append({"kind": "product", "factors": [primitive, {"kind": "poly", "powers": polynomial}]})
    # Public exponential data rates imply a generic sigmoid/tanh scale. The
    # time tilt is estimated from the current field's gradient, not an answer.
    for descriptor in bank.features:
        for primitive in leaves(descriptor):
            if primitive["kind"] != "exp_ridge": continue
            rate = np.asarray(primitive["rate"], float) / 2
            if time_axis is not None and abs(rate[time_axis]) > 1e-12: continue
            if not np.any(rate): continue
            center = np.mean(bank.bounds, axis=1)
            center[np.abs(rate) > 1e-12] = 0.
            if time_axis is not None: center[time_axis] = bank.bounds[time_axis, 0]
            for tilt in (0., -.25, -.5, -.75, -1., .5):
                normal = rate.copy()
                if time_axis is not None: normal[time_axis] = tilt * np.linalg.norm(rate * lengths) / lengths[time_axis]
                primitive = tanh(normal, center)
                global_features.insert(0, {"kind": "product", "factors": [primitive, primitive]})
                global_features.insert(0, primitive)
    for group in itertools.zip_longest(local, global_features):
        for feature in group:
            if feature is not None: add(feature)
            if len(candidates) >= cfg.adaptive_candidates: break
        if len(candidates) >= cfg.adaptive_candidates: break
    return candidates, {"centers": centers.tolist(), "physical_scales": scales.tolist(), "candidates": len(candidates)}


def response_ranking(residual, jacobian, new_columns, old_tangent, guard_residual, guard_jacobian,
                     *, filter_enabled=True, joint=False, floor=1e-14):
    """Projected scalar/group response gain validated on cross-guard residual.

    s=(e^T g_perp)^2/||g_perp||^2 after removing existing Jacobian range.
    The same proposed coefficient step must predict improvement on guard.
    """
    matrix = jacobian @ old_tangent
    guard_old = guard_jacobian[:, :jacobian.shape[1]] @ old_tangent
    guard_new = guard_jacobian[:, jacobian.shape[1]:]
    working_matrix = np.vstack([matrix, guard_old]) / np.sqrt(2) if joint else matrix
    working_new = np.vstack([new_columns, guard_new]) / np.sqrt(2) if joint else new_columns
    working_residual = np.r_[residual, guard_residual] / np.sqrt(2) if joint else residual
    norms = np.maximum(np.linalg.norm(working_matrix, axis=0), 1e-30)
    q = linalg.orth(working_matrix / norms, rcond=1e-11) if matrix.shape[1] else np.empty((len(working_residual), 0))
    defect = working_residual - q @ (q.T @ working_residual)
    projected = working_new - q @ (q.T @ working_new)
    numerators = projected.T @ defect
    denominators = np.sum(projected ** 2, axis=0)
    alpha = -numerators / np.maximum(denominators, floor)
    gains = numerators ** 2 / np.maximum(denominators, floor)
    # The old readout refit accompanies the new atom. Include that projected
    # compensation when cross-validating each linearized candidate response.
    correction, *_ = linalg.lstsq(working_matrix, -working_new, cond=1e-11, lapack_driver="gelsy") if matrix.shape[1] else (np.empty((0, new_columns.shape[1])),)
    train_response = matrix @ correction + new_columns
    guard_response = guard_old @ correction + guard_new
    train_gain = float(np.dot(residual, residual)) - np.sum((residual[:, None] + train_response * alpha) ** 2, axis=0)
    guard_before = float(np.dot(guard_residual, guard_residual))
    guard_after = np.sum((guard_residual[:, None] + guard_response * alpha) ** 2, axis=0)
    guard_gain = guard_before - guard_after
    valid = (denominators > floor) & (gains > floor)
    if filter_enabled: valid &= (guard_gain > 0) & (train_gain > 0)
    score = np.minimum(np.maximum(train_gain, 0), np.maximum(guard_gain, 0)) if filter_enabled else gains
    score[~valid] = -np.inf
    return np.argsort(-score), {"predicted_train_gain": train_gain, "predicted_guard_gain": guard_gain,
                              "alpha": alpha, "scores": score, "projected_response_norm": np.sqrt(denominators)}
