"""Descriptor-only scale coverage for localized candidate trial functions.

The two point sets have separate Sobol scrambles and transition strata. No
solution value or reference is consulted. They are adaptive fit/control points,
not a final test set. Values/jet scales remain physical and normalizers fixed.
"""
from __future__ import annotations

import math
import numpy as np
from scipy.stats import qmc

from research_v4.basis import _descriptor_key
from research_v5.solver import System as BaseSystem, Block


def localized_primitives(descriptors):
    found = {}
    def visit(feature):
        if feature["kind"] == "enveloped": visit(feature["base"])
        elif feature["kind"] == "product":
            for factor in feature["factors"]: visit(factor)
        elif feature["kind"] in ("gaussian", "tanh"):
            found.setdefault(_descriptor_key(feature), feature)
    for descriptor in descriptors: visit(descriptor)
    return list(found.values())


def scale_probes(descriptors, bounds, per_feature=12, seed=42, control=False):
    bounds = np.asarray(bounds, float)
    dimension, length = len(bounds), np.ptp(bounds, axis=1)
    batches = []
    primitives = localized_primitives(descriptors)
    for index, feature in enumerate(primitives):
        unit = qmc.Sobol(dimension, scramble=True, seed=int(seed + 19 * index + (104729 if control else 0))).random_base2(int(math.ceil(math.log2(per_feature))))[:per_feature]
        if feature["kind"] == "gaussian":
            physical = np.asarray(feature["center"]) + 2 * (2 * unit - 1) * feature["width"]
            physical = np.clip(physical, bounds[:, 0], bounds[:, 1])
        else:
            direction = np.asarray(feature["direction"], float)
            if not np.any(direction): continue
            axis = int(np.argmax(np.abs(direction)))
            # Solve the affine ridge phase for one coordinate. Other
            # coordinates span the full box, e.g. all times along a thin shock.
            phase = (2 * unit - 1) @ direction + feature["bias"]
            offset = .75 if control else .25
            target = -2.5 + 5 * (np.arange(per_feature) + offset) / per_feature
            unit[:, axis] += (target - phase) / (2 * direction[axis])
            physical = bounds[:, 0] + np.clip(unit, 0, 1) * length
        batches.append(physical)
    points = np.unique(np.vstack(batches), axis=0) if batches else np.empty((0, dimension))
    return points


def merge_points(previous, proposed, limit=384):
    previous, proposed = np.asarray(previous, float), np.asarray(proposed, float)
    if len(previous) == 0: merged = proposed
    elif len(proposed) == 0: merged = previous
    else:
        keep = max(limit - len(proposed), 0)
        subset = previous[np.linspace(0, len(previous) - 1, min(keep, len(previous)), dtype=int)]
        merged = np.vstack([subset, proposed])
    if len(merged) > limit:
        merged = merged[np.linspace(0, len(merged) - 1, limit, dtype=int)]
    return np.unique(merged, axis=0)


def coverage_statistics(descriptors, bounds, train_points, control_points):
    bounds = np.asarray(bounds, float)
    summaries = []
    for feature in localized_primitives(descriptors):
        counts = []
        for points in (train_points, control_points):
            if feature["kind"] == "gaussian":
                inside = np.sum(((points - feature["center"]) / feature["width"]) ** 2, axis=1) <= 4 * len(bounds)
            else:
                unit = (points - bounds[:, 0]) / np.ptp(bounds, axis=1)
                inside = np.abs((2 * unit - 1) @ feature["direction"] + feature["bias"]) <= 2.5 + 1e-12
            counts.append(int(np.count_nonzero(inside)))
        summaries.append({"kind": feature["kind"], "training_hits": counts[0], "control_hits": counts[1]})
    return {"localized_primitives": len(summaries),
            "minimum_training_hits": min((item["training_hits"] for item in summaries), default=0),
            "minimum_control_hits": min((item["control_hits"] for item in summaries), default=0), "details": summaries}


class AdaptiveSystem(BaseSystem):
    def __init__(self, problem, bank, config, seed, guard=False, normalizers=None, extra_points=None):
        super().__init__(problem, bank, config, seed, guard, normalizers)
        if extra_points is None or len(extra_points) == 0: return
        extra_points = np.asarray(extra_points, float)
        if extra_points.ndim != 2 or extra_points.shape[1] != len(problem["variables"]) or not np.isfinite(extra_points).all():
            raise ValueError("Invalid scale-coverage coordinates")
        if np.any(extra_points < bank.bounds[:, 0]) or np.any(extra_points > bank.bounds[:, 1]):
            raise ValueError("Scale-coverage coordinates outside physical box")
        all_points = np.vstack([self.interior_points, extra_points])
        equality = [Block(problem, bank, all_points, equation, "0", 1., scale=self.blocks[index].normalizer)
                    for index, equation in enumerate(problem["equations"])]
        conditions = self.blocks[self.equation_count:self.equation_count + len(self.condition_blocks)]
        branches = []
        for branch, old in zip(problem.get("branches", []), self.branch_blocks):
            kind = "min" if "min" in branch else "max"
            branches.append(Block(problem, bank, all_points, branch["operator"], str(branch[kind]), config.branch_weight,
                                  branch=kind, scale=old.normalizer))
        self.interior_points = all_points
        self.blocks = equality + conditions + branches
        self.branch_blocks = branches
        self.normalizers = [block.normalizer for block in self.blocks]
