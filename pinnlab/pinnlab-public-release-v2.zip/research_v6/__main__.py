"""Reproduce the fixed V6 scientific experiment from the project directory."""
import argparse
import json
from .experiment import run_development, run_final, verify

parser=argparse.ArgumentParser(description='V6 fixed-plan development and frozen-model final audit')
parser.add_argument('command',choices=['experiment','verify'])
parser.add_argument('--stage',choices=['development','final'],default='development')
parser.add_argument('--directory',default='research_v6/validation/formal')
args=parser.parse_args()
if args.command=='verify':
    frozen,development=verify(args.directory)
    print(json.dumps({'frozen':True,'rows':len(development['rows']),'source_files':len(frozen['source_sha256'])}))
else:
    result=(run_development if args.stage=='development' else run_final)(args.directory)
    print(json.dumps(result.get('summary',{}),ensure_ascii=True,indent=2))
