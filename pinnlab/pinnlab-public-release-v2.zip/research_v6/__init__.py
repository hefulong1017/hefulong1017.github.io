"""Experimental residual-defect adaptive neural trial spaces, version six."""
