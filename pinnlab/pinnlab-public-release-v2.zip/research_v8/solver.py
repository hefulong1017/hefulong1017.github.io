"""History-aware PINN with delay-residual curvature closure.

The supported delay and kernel functions are prescribed functions of space,
time, lag, and scalar parameters. They do not depend on the unknown solution.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, fields as dataclass_fields
import json
from pathlib import Path
import time

import numpy as np
from scipy import linalg
from scipy.special import roots_legendre
import torch

from pde_frontend.delay_spec import validate_delay_problem
from research_v4.solver import points
from research_v4.spec import Formula
from research_v5.solver import PairBlock
from research_v6.basis import V6Bank
from research_v6.solver import (Block as LocalBlock, Result as V6Result,
                                SolverConfig as V6Config, System as V6System,
                                _accepted, _finite_initial)
from research_v7.solver import _indices, _pad, _product_pool, _projected_curvature


VERSION = "8.0.0-history-aware-delay-curvature"


@dataclass
class SolverConfig(V6Config):
    delay_curvature_probe: float = 0.25
    delay_curvature_weight: float = 1.0
    delay_curvature_candidates: int = 96
    delay_curvature_sources: int = 24
    delay_curvature_batch: int = 4
    delay_curvature_births: int = 3

    def validate(self):
        super().validate()
        if not np.isfinite(self.delay_curvature_probe) or not 1e-4 <= self.delay_curvature_probe <= 2:
            raise ValueError("delay_curvature_probe must be in [1e-4, 2]")
        if not np.isfinite(self.delay_curvature_weight) or self.delay_curvature_weight < 0:
            raise ValueError("delay_curvature_weight must be nonnegative")
        for name, low, high in (("delay_curvature_candidates", 8, 512),
                                ("delay_curvature_sources", 4, 64),
                                ("delay_curvature_batch", 1, 16),
                                ("delay_curvature_births", 0, 12)):
            value = getattr(self, name)
            if type(value) is not int or not low <= value <= high:
                raise ValueError(f"Invalid {name}")


def _vector(value, count, label):
    values = np.asarray(value, dtype=float)
    try:
        values = np.broadcast_to(values, (count,)).copy()
    except ValueError as exc:
        raise ValueError(f"{label} must evaluate to one real value per point.") from exc
    if not np.isfinite(values).all():
        raise ValueError(f"{label} must remain finite on the sampled points.")
    return values


def _formula(expression, variables, parameters):
    return Formula(str(expression), variables, [], parameters, allow_fields=False)


def _shift_response(problem, bank, points_array, lag, history_formula):
    shifted = np.asarray(points_array, dtype=float).copy()
    time_index = problem["variables"].index("t")
    shifted[:, time_index] -= lag
    start = float(problem["domain"]["t"][0])
    past = shifted[:, time_index] < start
    matrix = np.zeros((len(shifted), bank.size))
    offset = np.zeros(len(shifted))
    present = ~past
    if present.any():
        matrix[present] = bank.values(shifted[present], ["u"])["u"]
    if past.any():
        offset[past] = _vector(history_formula(shifted[past], {}), int(past.sum()), "history")
    return matrix, offset


def _delay_response(problem, bank, sample_points, delay, history_formula):
    variables, parameters = problem["variables"], problem.get("parameters", {})
    count = len(sample_points)
    if delay["kind"] == "point":
        lag = _vector(_formula(delay["delay"], variables, parameters)(sample_points, {}),
                      count, delay["symbol"] + " delay")
        if np.any(lag <= 0):
            raise ValueError(f"Delay {delay['symbol']} must be strictly positive everywhere sampled.")
        matrix, offset = _shift_response(problem, bank, sample_points, lag, history_formula)
        return matrix, offset

    lower = _vector(_formula(delay["lower"], variables, parameters)(sample_points, {}),
                    count, delay["symbol"] + " lower lag")
    upper = _vector(_formula(delay["upper"], variables, parameters)(sample_points, {}),
                    count, delay["symbol"] + " upper lag")
    if np.any(lower < 0) or np.any(upper <= lower):
        raise ValueError(f"Distributed delay {delay['symbol']} requires 0 <= lower < upper everywhere sampled.")
    nodes, weights = roots_legendre(delay["quadrature"])
    kernel_formula = _formula(delay["kernel"], variables + ["s"], parameters)
    matrix = np.zeros((count, bank.size))
    offset = np.zeros(count)
    midpoint, halfwidth = (lower + upper) * 0.5, (upper - lower) * 0.5
    for node, weight in zip(nodes, weights):
        lag = midpoint + halfwidth * node
        kernel_points = np.column_stack([sample_points, lag])
        kernel = _vector(kernel_formula(kernel_points, {}), count, delay["symbol"] + " kernel")
        if np.any(kernel < 0):
            raise ValueError(f"Distributed-delay kernel {delay['symbol']} must be nonnegative on sampled points.")
        response, history = _shift_response(problem, bank, sample_points, lag, history_formula)
        quadrature_weight = halfwidth * float(weight) * kernel
        matrix += quadrature_weight[:, None] * response
        offset += quadrature_weight * history
    return matrix, offset


class DelayBlock:
    def __init__(self, problem, bank, points_array, equation, weight, scale=None):
        self.problem, self.bank, self.points = problem, bank, points_array
        self.aliases = {item["symbol"]: item for item in problem["delays"]}
        self.formula = Formula(equation, problem["variables"],
                               problem["fields"] + list(self.aliases), problem.get("parameters", {}))
        self.target = np.zeros(len(points_array))
        self.branch = None
        self.names = sorted(self.formula.jets)
        self.local_names = [name for name in self.names if name not in self.aliases]
        suffixes = {"u" + ("_" + name.split("_", 1)[1] if "_" in name else "")
                    for name in self.local_names}
        values = bank.values(points_array, suffixes) if suffixes else {}
        self.phi = {name: values["u" + ("_" + name.split("_", 1)[1] if "_" in name else "")]
                    for name in self.local_names}
        self.indices = {name: problem["fields"].index(name.split("_", 1)[0])
                        for name in self.local_names}
        self.delay_designs = {}
        for alias in self.names:
            if alias not in self.aliases:
                continue
            definition = self.aliases[alias]
            history_formula = _formula(problem["history"][definition["field"]],
                                       problem["variables"], problem.get("parameters", {}))
            self.delay_designs[alias] = _delay_response(problem, bank, points_array,
                                                        definition, history_formula)
        self.size = bank.size * len(problem["fields"])
        if scale is None:
            try:
                residual = self.raw(np.zeros(self.size))
                self.normalizer = max(1., float(np.sqrt(np.mean(residual * residual))))
            except (FloatingPointError, ValueError, ZeroDivisionError):
                self.normalizer = 1.
        else:
            self.normalizer = scale
        self.scale = np.sqrt(weight / len(points_array)) / self.normalizer

    def raw(self, coefficients, jacobian=False):
        matrix = np.asarray(coefficients, dtype=float).reshape(len(self.problem["fields"]), self.bank.size)
        latent = {}
        for name in self.local_names:
            field = self.indices[name]
            latent[name] = torch.tensor(self.phi[name] @ matrix[field], dtype=torch.float64,
                                        requires_grad=jacobian)
        for name, (response, history) in self.delay_designs.items():
            field = self.problem["fields"].index(self.aliases[name]["field"])
            values = response @ matrix[field] + history
            latent[name] = torch.tensor(values, dtype=torch.float64, requires_grad=jacobian)
        coordinates = torch.tensor(self.points, dtype=torch.float64)
        value = self.formula(coordinates, latent)
        if not isinstance(value, torch.Tensor):
            value = torch.full((len(self.points),), float(value), dtype=torch.float64)
        value = value - torch.tensor(self.target, dtype=torch.float64)
        residual = value.detach().numpy()
        if not np.isfinite(residual).all():
            raise FloatingPointError("Non-finite delay residual.")
        if not jacobian:
            return residual
        result = np.zeros((len(residual), self.size))
        partials = torch.autograd.grad(value, list(latent.values()), torch.ones_like(value),
                                       allow_unused=True) if value.requires_grad and latent else [None] * len(latent)
        for name, partial in zip(latent, partials):
            if partial is None:
                continue
            derivative = partial.detach().numpy()[:, None]
            if name in self.aliases:
                field = self.problem["fields"].index(self.aliases[name]["field"])
                response = self.delay_designs[name][0]
            else:
                field = self.indices[name]
                response = self.phi[name]
            result[:, field * self.bank.size:(field + 1) * self.bank.size] += derivative * response
        if not np.isfinite(result).all():
            raise FloatingPointError("Non-finite delay Jacobian.")
        return residual, result


class DelaySystem(V6System):
    def __init__(self, problem, bank, config, seed, guard=False, normalizers=None):
        self.bank, self.problem = bank, problem
        self.blocks, self.condition_blocks, self.branch_blocks = [], [], []
        self.interior_points = points(problem, config.guard if guard else config.interior, seed)
        scales = iter(normalizers) if normalizers is not None else None

        def add(block):
            self.blocks.append(block)
            return block

        for equation in problem["equations"]:
            scale = next(scales) if scales is not None else None
            add(DelayBlock(problem, bank, self.interior_points, equation, 1., scale))
        self.equation_count = len(self.blocks)
        for index, condition in enumerate(problem["conditions"]):
            q = points(problem, config.condition_points, seed + 100 + index, condition.get("where", {}))
            pair_axis = condition.get("pair_axis") if condition.get("kind") == "periodic" else None
            scale = next(scales) if scales is not None else None
            if pair_axis is not None:
                block = PairBlock(problem, bank, q, condition["operator"], condition["target"],
                                  config.boundary_weight * condition.get("weight", 1.), pair_axis, scale)
            else:
                block = LocalBlock(problem, bank, q, condition["operator"], condition["target"],
                                   config.boundary_weight * condition.get("weight", 1.), scale=scale)
            self.condition_blocks.append(add(block))

        # Histories and the neural solution must agree at the start time.
        start = float(problem["domain"]["t"][0])
        delayed_fields = sorted({item["field"] for item in problem["delays"]})
        for index, field in enumerate(delayed_fields):
            q = points(problem, config.condition_points, seed + 1000 + index, {"t": start})
            scale = next(scales) if scales is not None else None
            block = LocalBlock(problem, bank, q, field, problem["history"][field],
                               config.boundary_weight, scale=scale)
            self.condition_blocks.append(add(block))

        for branch in problem.get("branches", []):
            kind = "min" if "min" in branch else "max"
            scale = next(scales) if scales is not None else None
            block = LocalBlock(problem, bank, self.interior_points, branch["operator"],
                               str(branch[kind]), config.branch_weight, kind, scale)
            self.branch_blocks.append(add(block))
        self.normalizers = [block.normalizer for block in self.blocks]


@dataclass
class Result:
    problem: dict
    config: SolverConfig
    bank: V6Bank
    coefficients: np.ndarray
    history: list
    status: str
    seconds: float
    diagnostics: dict

    def predict(self, points_array, derivatives=None):
        proxy = V6Result(self.problem, self.config, self.bank, self.coefficients,
                          self.history, self.status, self.seconds, self.diagnostics, None)
        return proxy.predict(points_array, derivatives or ())

    def to_dict(self):
        return {"version": VERSION, "problem": self.problem, "config": asdict(self.config),
                "features": self.bank.features, "coefficients": self.coefficients.tolist(),
                "history": self.history, "status": self.status, "seconds": self.seconds,
                "diagnostics": self.diagnostics, "training_uses_reference": False,
                "claim": "history_aware_delay_residual_curvature_closure; generality_and_global_originality_unproven"}

    def save(self, path):
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)
        (path / "model.json").write_text(json.dumps(self.to_dict(), ensure_ascii=False,
                                                      indent=2, allow_nan=False), encoding="utf-8")
        return path


def load(path):
    path = Path(path)
    state = json.loads((path if path.is_file() else path / "model.json").read_text(encoding="utf-8"))
    problem = validate_delay_problem(state["problem"])
    config = SolverConfig(**state["config"])
    bank = V6Bank(problem["variables"], problem["domain"], features=state["features"])
    return Result(problem, config, bank, np.asarray(state["coefficients"], dtype=float),
                  state["history"], state["status"], state["seconds"], state["diagnostics"])


def _joint_direction(train, guard, current, lift, nullspace, hard):
    train_residual, train_jacobian = train.evaluate(current, True)
    guard_residual, guard_jacobian = guard.evaluate(current, True)
    residual = np.r_[train_residual, guard_residual] / np.sqrt(2.)
    jacobian = np.vstack([train_jacobian, guard_jacobian]) / np.sqrt(2.)
    tangent = jacobian @ nullspace
    step = linalg.lstsq(tangent, -residual, cond=1e-11, lapack_driver="gelsy")[0]
    return nullspace @ step if hard else step


def _curvature_birth(train, guard, bank, current, config, lift, nullspace, hard, deadline):
    if time.perf_counter() >= deadline:
        return None
    residual, jacobian = train.evaluate(current, True)
    direction = _joint_direction(train, guard, current, lift, nullspace, hard)
    value_matrix = train.value_matrix()
    function_norm = np.linalg.norm(value_matrix @ direction) / np.sqrt(max(1, value_matrix.shape[0]))
    if not np.isfinite(function_norm) or function_norm <= 1e-12:
        return None
    direction = direction / function_norm
    guard_residual, guard_jacobian = guard.evaluate(current, True)
    alpha = config.delay_curvature_probe
    train_remainder = guard_remainder = None
    for backtrack in range(14):
        alpha = config.delay_curvature_probe * 0.5**backtrack
        probe = current + alpha * direction
        if hard:
            probe = lift + nullspace @ (nullspace.T @ (probe - lift))
        try:
            train_remainder = (train.evaluate(probe) - residual - alpha * (jacobian @ direction)) / alpha**2
            guard_remainder = (guard.evaluate(probe) - guard_residual - alpha * (guard_jacobian @ direction)) / alpha**2
            if np.isfinite(train_remainder).all() and np.isfinite(guard_remainder).all():
                break
        except (FloatingPointError, ValueError, ZeroDivisionError, OverflowError):
            train_remainder = guard_remainder = None
    if train_remainder is None or guard_remainder is None:
        return None

    fields = len(train.problem["fields"])
    candidates = _product_pool(bank, current, fields,
                               config.delay_curvature_candidates,
                               config.delay_curvature_sources)
    remaining = config.max_features - bank.size
    if not candidates or remaining <= 0:
        return None
    augmented = V6Bank(bank.variables, bank.bounds, features=bank.features + candidates)
    padded = _pad(current, bank.size, augmented.size, fields)
    aug_train = DelaySystem(train.problem, augmented, config, config.seed, normalizers=train.normalizers)
    aug_guard = DelaySystem(train.problem, augmented, config, config.seed + 1, True, train.normalizers)
    _, aug_train_jacobian = aug_train.evaluate(padded, True)
    _, aug_guard_jacobian = aug_guard.evaluate(padded, True)
    _, new_indices = _indices(bank.size, augmented.size, fields)
    old_jacobian = np.vstack([jacobian, guard_jacobian]) / np.sqrt(2.)
    new_jacobian = np.vstack([aug_train_jacobian[:, new_indices],
                              aug_guard_jacobian[:, new_indices]]) / np.sqrt(2.)
    curvature = np.r_[train_remainder, guard_remainder] / np.sqrt(2.)
    joint_residual = np.r_[residual, guard_residual] / np.sqrt(2.)
    scores, _, _ = _projected_curvature(old_jacobian, new_jacobian, curvature,
                                         joint_residual, config.delay_curvature_weight)
    order = np.argsort(-scores)
    chosen, responses = [], []
    for index in order:
        if not np.isfinite(scores[index]):
            continue
        column = new_jacobian[:, index]
        norm = np.linalg.norm(column)
        if norm <= 1e-12:
            continue
        normalized = column / norm
        if responses and max(abs(float(normalized @ prior)) for prior in responses) > .995:
            continue
        chosen.append(candidates[int(index)])
        responses.append(normalized)
        if len(chosen) >= min(config.delay_curvature_batch, remaining):
            break
        if time.perf_counter() >= deadline:
            break
    if not chosen:
        return None
    new_bank = V6Bank(bank.variables, bank.bounds, features=bank.features + chosen)
    return new_bank, _pad(current, bank.size, new_bank.size, fields), alpha, chosen


def solve(problem, config=None, callback=None):
    config = config or SolverConfig()
    if not isinstance(config, SolverConfig):
        accepted = {item.name for item in dataclass_fields(SolverConfig)}
        config = SolverConfig(**{key: value for key, value in asdict(config).items() if key in accepted})
    config.validate()
    problem = validate_delay_problem(problem)
    started = time.perf_counter()
    deadline = started + config.budget_seconds if config.budget_seconds else float("inf")
    torch.set_num_threads(config.threads)
    bank = V6Bank(problem["variables"], problem["domain"], poly_degree=config.poly_degree,
                  neural_frequencies=config.neural_frequencies)
    if bank.size > config.max_features:
        raise ValueError("Initial delay-PINN basis exceeds max_features.")
    train = DelaySystem(problem, bank, config, config.seed)
    guard = DelaySystem(problem, bank, config, config.seed + 1, True, train.normalizers)
    lift, nullspace, hard = train.boundary_space()
    current = _finite_initial(train, guard, lift, nullspace, hard)
    births = 0
    history = []
    status = "iteration_limit"

    for step in range(config.iterations):
        if time.perf_counter() >= deadline:
            status = "budget"
            break
        train_before, guard_before = train.loss(current), guard.loss(current)
        direction = _joint_direction(train, guard, current, lift, nullspace, hard)
        accepted = None
        if np.isfinite(direction).all() and np.linalg.norm(direction) > 1e-14:
            for backtrack in range(18):
                if time.perf_counter() >= deadline:
                    break
                amplitude = 2.**(-backtrack)
                trial = current + amplitude * direction
                if hard:
                    trial = lift + nullspace @ (nullspace.T @ (trial - lift))
                okay, _, _, branch = _accepted(train, guard, current, trial, config)
                if okay:
                    accepted = trial
                    history.append({"step": step, "action": "delay_joint_correction",
                                    "training_before": train_before, "control_before": guard_before,
                                    "guard_before": guard_before, "guard": guard.loss(trial),
                                    "training": train.loss(trial), "control": guard.loss(trial),
                                    "amplitude": amplitude, "branch": branch})
                    current = trial
                    break
        if accepted is not None:
            if callback:
                callback(history[-1])
            continue

        if births < config.delay_curvature_births and bank.size < config.max_features:
            addition = _curvature_birth(train, guard, bank, current, config,
                                        lift, nullspace, hard, deadline)
            if addition is not None:
                new_bank, padded, alpha, chosen = addition
                old_train, old_guard = train, guard
                bank = new_bank
                train = DelaySystem(problem, bank, config, config.seed,
                                    normalizers=old_train.normalizers)
                guard = DelaySystem(problem, bank, config, config.seed + 1, True,
                                    old_train.normalizers)
                lift, nullspace, hard = train.boundary_space()
                current = lift + nullspace @ (nullspace.T @ (padded - lift)) if hard else padded
                births += 1
                record = {"step": step, "action": "delay_curvature_closure",
                          "probe": alpha, "features_added": chosen,
                          "guard_before": guard_before, "guard": guard.loss(current),
                          "training": train.loss(current), "control": guard.loss(current)}
                history.append(record)
                if callback:
                    callback(record)
                continue
        status = "inconclusive" if time.perf_counter() < deadline else "budget"
        history.append({"step": step, "action": "no_accepted_delay_correction",
                        "guard_before": guard_before, "guard": guard_before,
                        "training": train_before, "control": guard_before})
        break

    seconds = time.perf_counter() - started
    diagnostics = {
        "training_score": float(train.loss(current)),
        "guard_score": float(guard.loss(current)),
        "features": bank.size,
        "curvature_births": births,
        "delay_operator_count": len(problem["delays"]),
        "delay_kinds": [item["kind"] for item in problem["delays"]],
        "history_field_count": len(problem["history"]),
        "distributed_quadrature_orders": [item["quadrature"] for item in problem["delays"]
                                             if item["kind"] == "distributed"],
        "seconds": seconds,
        "budget_exceeded": bool(config.budget_seconds and seconds > config.budget_seconds),
        "training_uses_reference": False,
        "independent_reference_error_audit": False,
        "interpretation": "Delay residual and history fit diagnostics on sampled points; not a global solution error certificate.",
    }
    return Result(problem, config, bank, current, history, status, seconds, diagnostics)
