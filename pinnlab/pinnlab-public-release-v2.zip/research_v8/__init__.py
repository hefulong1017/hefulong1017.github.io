"""History-aware delay PINN research prototype."""

from .solver import SolverConfig, Result, solve, load

__all__ = ["SolverConfig", "Result", "solve", "load"]
