"""Truncated ordinary Taylor coefficients for physical response expressions.

The series variable is the correction amplitude, not a physical coordinate.
Coefficients already include 1/k!, avoiding finite-difference cancellation.
"""
from __future__ import annotations
import numpy as np


class Series:
    __array_priority__ = 1000
    def __init__(self, coefficients):
        self.c = np.asarray(coefficients, dtype=float)
        self.order = len(self.c)-1

    def coerce(self, value):
        if isinstance(value, Series):
            return value
        c = np.zeros_like(self.c)
        c[0] = value
        return Series(c)

    def __add__(self, other):
        return Series(self.c+self.coerce(other).c)
    __radd__ = __add__

    def __neg__(self):
        return Series(-self.c)

    def __sub__(self, other):
        return self+-self.coerce(other)

    def __rsub__(self, other):
        return self.coerce(other)+-self

    def __mul__(self, other):
        b = self.coerce(other).c
        c = np.zeros_like(self.c)
        for k in range(self.order+1):
            for j in range(k+1):
                c[k] += self.c[j]*b[k-j]
        return Series(c)
    __rmul__ = __mul__

    def inverse(self):
        c = np.zeros_like(self.c)
        c[0] = 1/self.c[0]
        for k in range(1,self.order+1):
            c[k] = -sum(self.c[j]*c[k-j] for j in range(1,k+1))/self.c[0]
        return Series(c)

    def __truediv__(self, other):
        return self*self.coerce(other).inverse()

    def __rtruediv__(self, other):
        return self.coerce(other)*self.inverse()

    def __pow__(self, exponent):
        if isinstance(exponent, Series):
            raise ValueError('Variable exponents are not supported.')
        if float(exponent).is_integer():
            exponent = int(exponent)
            if exponent < 0:
                return (self.inverse())**(-exponent)
            answer = self.coerce(1.)
            for _ in range(exponent):
                answer = answer*self
            return answer
        return (self.log()*exponent).exp()

    def exp(self):
        c=np.zeros_like(self.c); c[0]=np.exp(self.c[0])
        for k in range(1,self.order+1):
            c[k]=sum(j*self.c[j]*c[k-j] for j in range(1,k+1))/k
        return Series(c)

    def log(self):
        c=np.zeros_like(self.c); c[0]=np.log(self.c[0])
        quotient=self.inverse().c
        for k in range(1,self.order+1):
            c[k]=sum(j*self.c[j]*quotient[k-j] for j in range(1,k+1))/k
        return Series(c)

    def sincos(self):
        s=np.zeros_like(self.c); c=np.zeros_like(self.c)
        s[0],c[0]=np.sin(self.c[0]),np.cos(self.c[0])
        for k in range(1,self.order+1):
            s[k]=sum(j*self.c[j]*c[k-j] for j in range(1,k+1))/k
            c[k]=-sum(j*self.c[j]*s[k-j] for j in range(1,k+1))/k
        return Series(s),Series(c)

    def sin(self): return self.sincos()[0]
    def cos(self): return self.sincos()[1]
    def tanh(self):
        c=np.zeros_like(self.c); c[0]=np.tanh(self.c[0])
        for k in range(1,self.order+1):
            value=np.zeros_like(c[0])
            for j in range(1,k+1):
                n=k-j
                one_minus_square=(1. if n==0 else 0.)-sum(c[i]*c[n-i] for i in range(n+1))
                value+=j*self.c[j]*one_minus_square
            c[k]=value/k
        return Series(c)
    def sqrt(self): return self**.5
    def abs(self):
        if np.any(self.c[0]==0):
            raise ValueError('abs at zero has no analytic Taylor response.')
        return self*np.sign(self.c[0])
