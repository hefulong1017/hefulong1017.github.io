"""Self-contained offline Plotly audit report; this module never trains a model.

API: build_report(results_path, output_path) -> pathlib.Path.
Input is a row list, or a JSON object containing a rows list.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import html
import json
import math
from pathlib import Path
from typing import Any


VARIANTS = {
    "full": "完整候选：响应搜索与特征扩展",
    "gn_fixed": "固定小空间 Gauss–Newton",
    "order2_fixed": "固定小空间，最高二阶响应",
    "order6_fixed": "固定小空间，最高六阶响应",
    "gn_large": "较大固定空间 Gauss–Newton",
}


def _clean(value: Any, issues: list[str], path: str = "") -> Any:
    if isinstance(value, float) and not math.isfinite(value):
        issues.append((path or "value") + ": 非有限值显示为缺失")
        return None
    if isinstance(value, dict):
        return {str(k): _clean(v, issues, path + "." + str(k)) for k, v in value.items()}
    if isinstance(value, list):
        return [_clean(v, issues, path + "[" + str(i) + "]") for i, v in enumerate(value)]
    return value


def _number(value: Any) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    try:
        number = float(value)
    except (ValueError, OverflowError):
        return None
    return number if math.isfinite(number) and number >= 0 else None


def _actions(row: dict, diagnostics: dict) -> list[dict]:
    sources = (row.get("history"), diagnostics.get("history"), row.get("actions"),
               diagnostics.get("actions"), diagnostics.get("action_counts"))
    source = next((v for v in sources if isinstance(v, (list, dict)) and v), [])
    if isinstance(source, dict):
        return [{"action": str(k), "count": v, "aggregate_only": True}
                for k, v in source.items()
                if isinstance(v, int) and not isinstance(v, bool) and v > 0]
    answer = []
    for index, item in enumerate(source):
        if isinstance(item, str):
            answer.append({"action": item, "step": index, "count": 1})
        elif isinstance(item, dict):
            event = dict(item)
            event["action"] = str(event.get("action", "未命名动作"))
            count = event.get("count", 1)
            event["count"] = count if type(count) is int and count > 0 else 1
            answer.append(event)
    return answer


def _prepare(payload: Any) -> dict:
    if isinstance(payload, list):
        raw_rows, metadata = payload, {}
    elif isinstance(payload, dict) and isinstance(payload.get("rows"), list):
        raw_rows = payload["rows"]
        metadata = {k: v for k, v in payload.items() if k != "rows"}
    else:
        raise ValueError("Results must be a row list or a JSON object with a rows list.")
    rows, issues = [], []
    for index, value in enumerate(raw_rows):
        if not isinstance(value, dict):
            raise ValueError("Row " + str(index) + " is not an object.")
        row = _clean(value, issues, "rows[" + str(index) + "]")
        for key in ("id", "variant"):
            if not isinstance(row.get(key), str) or not row[key]:
                raise ValueError("Row " + str(index) + " needs a nonempty string " + key)
        d = row.get("diagnostics") if isinstance(row.get("diagnostics"), dict) else {}
        a = row.get("audit") if isinstance(row.get("audit"), dict) else {}
        e = a.get("reference_errors") if isinstance(a.get("reference_errors"), dict) else {}
        equations = a.get("equations") if isinstance(a.get("equations"), list) else []
        maxima = [_number(v.get("max_abs")) for v in equations if isinstance(v, dict)]
        maxima = [v for v in maxima if v is not None]
        rows.append({
            "index": index, "id": row["id"], "variant": row["variant"],
            "label": str(row.get("label") or row.get("case_label") or row["id"]),
            "run": row.get("run"), "status": row.get("status"),
            "reported_status": row.get("reported_status", a.get("reported_status")),
            "expected_outcome": a.get("expected_outcome"),
            "accepted_solution": a.get("accepted_solution") if type(a.get("accepted_solution")) is bool else None,
            "successful_handling": a.get("successful_handling") if type(a.get("successful_handling")) is bool else None,
            "physics_consistent": a.get("physics_consistent") if type(a.get("physics_consistent")) is bool else None,
            "relative_l2": _number(e.get("relative_l2")),
            "normalized_max_abs_error": _number(e.get("normalized_max_abs_error")),
            "seconds": _number(row.get("seconds")), "guard_score": _number(d.get("guard_score")),
            "equation_max_abs": max(maxima) if maxima else None,
            "actions": _actions(row, d), "raw": row,
        })
    return {"rows": rows, "metadata": _clean(metadata, issues, "metadata"),
            "issues": issues, "variants": VARIANTS}


def build_report(results_path: str | Path, output_path: str | Path) -> Path:
    """Write offline HTML from existing results, preserving failed and missing rows.

    Plotly is embedded, with no CDN. Only plotting floors exact zero errors;
    tables and hover text keep their original zero. No success is inferred
    from solver status, physical residual, timing or expected outcome.
    """
    source, destination = Path(results_path), Path(output_path)
    if source.resolve() == destination.resolve():
        raise ValueError("The report cannot overwrite the input results.")
    data = _prepare(json.loads(source.read_text(encoding="utf-8-sig")))
    data.update(generated_at_utc=datetime.now(timezone.utc).isoformat(), source_name=source.name)
    try:
        from plotly.offline import get_plotlyjs
    except ImportError as exc:
        raise RuntimeError("Report generation requires plotly; no training dependencies are imported.") from exc
    encoded = json.dumps(data, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
    for old, new in (("&", "\\u0026"), ("<", "\\u003c"), (">", "\\u003e"),
                     ("\u2028", "\\u2028"), ("\u2029", "\\u2029")):
        encoded = encoded.replace(old, new)
    page = (_PAGE.replace("__PLOTLY_BUNDLE__", get_plotlyjs(), 1)
            .replace("__REPORT_DATA__", encoded, 1)
            .replace("__SOURCE_NAME__", html.escape(source.name), 1))
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(page, encoding="utf-8")
    return destination


_PAGE = r"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>V4 候选算法 · 独立审计报告</title>
<style>
:root{color-scheme:light;--ink:#17283c;--muted:#596d81;--line:#d9e2ec;--bg:#eff3f7;--accent:#146b87}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.65 "Microsoft YaHei",system-ui,sans-serif}
main{max-width:1580px;margin:auto;padding:30px 28px 64px}h1{font-size:29px;line-height:1.3;margin:8px 0 12px}h2{font-size:19px;margin:0 0 12px}p{margin:8px 0}
.eyebrow{font-size:12px;letter-spacing:.12em;font-weight:700;color:var(--accent)}.lead{max-width:1100px;color:var(--muted)}
.meta,.caption{font-size:12px;color:var(--muted);overflow-wrap:anywhere}.notice{background:#fff6e5;border-left:4px solid #d79723;padding:15px 20px;margin:22px 0;border-radius:4px}
.notice strong{color:#754a00}.cards{display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin:20px 0}.card,.panel{background:#fff;border:1px solid var(--line);border-radius:10px}
.card{padding:16px 18px}.card b{display:block;font-size:27px;font-variant-numeric:tabular-nums}.card span{font-size:12px;color:var(--muted)}
.controls{display:flex;align-items:end;gap:18px;flex-wrap:wrap;padding:18px 20px;margin:16px 0}label{font-size:13px;color:var(--muted)}
select{display:block;min-width:240px;padding:8px 10px;border:1px solid #bccbd9;border-radius:5px;background:white;color:var(--ink);font:inherit}.filter-count{color:var(--muted);font-size:13px;padding-bottom:8px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}.panel{padding:18px 20px;margin-bottom:16px;min-width:0}.grid .panel{margin:0}.plot{height:440px;width:100%}
.table-wrap{overflow:auto;max-height:750px;border:1px solid var(--line);border-radius:6px}table{border-collapse:collapse;width:100%;font-size:12px;white-space:nowrap}
th{background:#edf3f8;color:#344e65;text-align:left;position:sticky;top:0;z-index:1}th,td{padding:10px 12px;border-bottom:1px solid var(--line);vertical-align:top}tbody tr:nth-child(even){background:#f8fafc}
td.case{white-space:normal;min-width:230px;max-width:320px;overflow-wrap:anywhere}.mono{font-family:Consolas,monospace;font-variant-numeric:tabular-nums}
.yes{color:#116849;font-weight:700}.no{color:#a13535;font-weight:700}.unknown{color:#6b7280}.small{font-size:11px;color:var(--muted)}
.section{margin-top:24px}.raw{white-space:pre-wrap;overflow-wrap:anywhere;max-height:420px;overflow:auto;background:#f1f5f9;padding:14px;font:12px/1.5 Consolas,monospace}
details summary{cursor:pointer;color:var(--accent)}.variants{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;font-size:12px}.variant{padding:7px 10px;border-left:3px solid var(--accent);background:#f4f8fb;overflow-wrap:anywhere}
@media(max-width:1000px){.cards{grid-template-columns:repeat(3,1fr)}.grid{grid-template-columns:1fr}.variants{grid-template-columns:1fr 1fr}}
@media(max-width:600px){main{padding:20px 12px}.cards{grid-template-columns:1fr 1fr}h1{font-size:24px}.panel{padding:14px 12px}.variants{grid-template-columns:1fr}}
@media print{body{background:white}main{max-width:none;padding:0}.controls{display:none}.panel,.card{break-inside:avoid}.table-wrap{max-height:none;overflow:visible}.grid{display:block}}
</style><script>__PLOTLY_BUNDLE__</script></head><body><main>
<div class="eyebrow">PINNLAB / RESEARCH V4 / EXPERIMENTAL CANDIDATE</div>
<h1>退化响应候选算法：误差、成本与失败审计</h1>
<p class="lead">按案例比较候选与固定空间对照，保留全部运行、未收敛结果和缺失指标。候选贡献仍是研究假设；不声明全球首创或能够可靠求解所有方程。</p>
<div class="meta" id="meta">数据文件：__SOURCE_NAME__。Plotly 与结果数据均已内嵌，可离线打开。</div>
<div class="notice"><strong>physics_tolerance / physics_tol 只是有限点物理门达到阈值，不是解误差认证。</strong>
<p>数值解通过审计、正确识别不唯一/不相容、以及未得出结论，是不同结果。残差小不保证解误差小。开发 guard 被反复用于选方向与停止，最终审计必须使用独立点。</p>
<p>挑战集包含 PDE、一维常微分/高阶边值问题、耦合或代数退化、分支变体及诊断案例；案例数不能写成同等数量的 PDE 类别。机制消融记录也不能增加方程族数量。</p>
<p>时间为 single-run exploratory time（单次探索耗时）。没有重复计时、统计区间或效率胜出结论；重复编号也不自动构成多随机种子证据。</p></div>
<div class="cards" id="cards"></div><div class="panel controls">
<label>案例<select id="case-filter"><option value="">全部案例</option></select></label>
<label>对照<select id="variant-filter"><option value="">全部对照</option></select></label>
<div class="filter-count" id="filter-count"></div></div>
<div class="panel"><h2>对照角色</h2><div class="variants" id="variants"></div>
<p class="caption">实际点数、特征数、迭代和时间预算以原始配置为准；较大固定空间不自动构成同成本对照。页面展示输入中的所有 variant，不补造缺失实验。</p></div>
<div class="grid">
<section class="panel"><h2>各案例的参考解误差</h2><div id="error-plot" class="plot"></div>
<p class="caption">每个点是一条运行，含失败结果，不做均值/中位数聚合。相对 L2 采用对数轴；缺失不按零填充，精确零仅绘图放在 1e−16，原值保留。</p></section>
<section class="panel"><h2>单次探索耗时</h2><div id="time-plot" class="plot"></div>
<p class="caption">每个点是一条运行的秒数，所有状态均显示。单次记录用于了解计算投入，不支持统计稳定性或效率优越性结论；计时范围以原始元数据为准。</p></section>
<section class="panel"><h2>记录的动作</h2><div id="action-plot" class="plot"></div>
<p class="caption">按 action 原始记录计数，包括 no_accepted_direction。没有记录的动作不补造；次数不代表新增 PDE 类别，也不直接证明机制贡献。</p></section>
<section class="panel"><h2>方向响应阶数</h2><div id="order-plot" class="plot"></div>
<p class="caption">分别统计 residual_order 与 energy_order。它们不同，均不等于 PDE 空间微分阶或误差收敛阶；缺失则显示未记录，不从对照名称推断。</p></section></div>
<section class="panel section"><h2>审计分项</h2><div class="table-wrap"><table><thead><tr>
<th>对照</th><th>运行记录</th><th>唯一解记录</th><th>数值解通过 / 唯一解记录</th><th>正确诊断 / 诊断记录</th><th>唯一解缺少参考误差</th>
</tr></thead><tbody id="summary"></tbody></table></div>
<p class="caption">分母是运行记录，不是不同方程族。successful_handling 对唯一解可能为真，但不重复计为诊断成功。17 个挑战含分支变体、ODE 及不适定诊断，不能称为 17 类 PDE。</p></section>
<section class="panel"><h2>全部运行明细</h2><p class="caption">默认显示所有状态。原始状态与报告结论并列，展开可核查 diagnostics、history、analysis、审计与运行参数。</p>
<div class="table-wrap"><table><thead><tr><th>案例 / 预期</th><th>对照 / run</th><th>状态 / 报告结论</th><th>数值解通过</th><th>处理正确</th><th>物理一致</th>
<th>参考相对 L2</th><th>归一化最大解误差</th><th>秒数</th><th>审计 max|方程残差|</th><th>开发 guard</th><th>动作 / 原始记录</th>
</tr></thead><tbody id="runs"></tbody></table></div></section>
<section class="panel"><h2>复核说明</h2>
<p>本报告只展示 audit 的明确结论，不根据 physics_tolerance 或低残差重分类。正确诊断不唯一或有证据的不相容，不等于得到高精度数值解；算法停滞不能作为无解证明。困难失败和缺失误差全部保留。</p>
<p>参考误差、原始方程残差、初边值和分支违约须共同检查；尖层还需局部审计。输入未包含最终独立审计的记录时，本页不能代替最终验证。原始元数据保留下方。</p>
<details><summary>实验元数据与数据完整性提示</summary><pre class="raw" id="metadata"></pre></details></section>
</main><script type="application/json" id="report-data">__REPORT_DATA__</script>
<script>
"use strict";
(function(){
const data=JSON.parse(document.getElementById("report-data").textContent),rows=data.rows;
const preferred=["full","gn_fixed","order2_fixed","order6_fixed","gn_large"],palette=["#146b87","#6260af","#d3842f","#ab4d6d","#38866b","#687d91"];
const variants=Array.from(new Set(rows.map(r=>r.variant))).sort((a,b)=>{const ai=preferred.indexOf(a),bi=preferred.indexOf(b);return(ai<0?999:ai)-(bi<0?999:bi)||a.localeCompare(b);});
const cases=Array.from(new Set(rows.map(r=>r.id))).sort(),byId=id=>document.getElementById(id),color=v=>palette[Math.max(0,variants.indexOf(v))%palette.length];
const finite=v=>typeof v==="number"&&Number.isFinite(v),shown=v=>v===null||v===undefined?"缺失":String(v);
const fmt=v=>!finite(v)?"缺失":v===0?"0":Math.abs(v)<.001||Math.abs(v)>=1e4?v.toExponential(4):v.toPrecision(5);
const safe=s=>String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
const config={responsive:true,displaylogo:false,modeBarButtonsToRemove:["lasso2d","select2d"]},outcome={unique:"唯一解",nonunique:"不唯一",incompatible:"不相容"};
function option(select,value,label){const e=document.createElement("option");e.value=value;e.textContent=label;select.appendChild(e);}
cases.forEach(c=>option(byId("case-filter"),c,c));variants.forEach(v=>option(byId("variant-filter"),v,v));
variants.forEach(v=>{const e=document.createElement("div");e.className="variant";e.style.borderColor=color(v);e.textContent=v+" · "+(data.variants[v]||"未提供设计说明");byId("variants").appendChild(e);});
byId("meta").textContent="数据文件："+data.source_name+" · 生成 UTC："+data.generated_at_utc+" · Plotly 与数据均内嵌，可离线打开。";
byId("metadata").textContent=JSON.stringify({metadata:data.metadata,data_issues:data.issues,variant_roles:data.variants},null,2);
function cell(tr,value,cls){const e=document.createElement("td");e.textContent=shown(value);if(cls)e.className=cls;tr.appendChild(e);return e;}
function flag(tr,value){cell(tr,value===true?"是":value===false?"否":"未记录",value===true?"yes":value===false?"no":"unknown");}
function layout(yTitle,log){return{font:{family:'"Microsoft YaHei",system-ui,sans-serif',size:11,color:"#344e65"},paper_bgcolor:"#fff",plot_bgcolor:"#fff",margin:{l:70,r:22,t:25,b:155},barmode:"group",legend:{orientation:"h",x:0,y:1.17,font:{size:10}},xaxis:{type:"category",tickangle:-35,automargin:true},yaxis:{title:yTitle,type:log?"log":"linear",gridcolor:"#e6edf3",rangemode:log?undefined:"tozero"},hoverlabel:{align:"left"},uirevision:"v4-audit"};}
function empty(id,text){const l=layout("",false);l.annotations=[{text:text,x:.5,y:.5,xref:"paper",yref:"paper",showarrow:false,font:{size:13,color:"#65758a"}}];l.xaxis.visible=false;l.yaxis.visible=false;Plotly.react(id,[],l,config);}
function metric(id,selected,key,title,log){
 const traces=[];
 variants.forEach(v=>{const group=selected.filter(r=>r.variant===v&&finite(r[key]));if(!group.length)return;
 traces.push({type:"scatter",mode:"markers",name:safe(v),x:group.map(r=>safe(r.id)),y:group.map(r=>log?Math.max(r[key],1e-16):r[key]),
 marker:{color:color(v),size:9,line:{width:1,color:"#fff"},symbol:group.map(r=>r.accepted_solution===true?"circle":r.successful_handling===true?"diamond":"x")},
 customdata:group.map(r=>[safe(r.id),safe(shown(r.run)),fmt(r[key]),safe(shown(r.status)),safe(shown(r.accepted_solution)),r[key]===0&&log?"原值 0；仅绘图采用 1e−16":""]),
 hovertemplate:"案例：%{customdata[0]}<br>run：%{customdata[1]}<br>原值：%{customdata[2]}<br>状态：%{customdata[3]}<br>数值解通过：%{customdata[4]}<br>%{customdata[5]}<extra>"+safe(v)+"</extra>"});});
 if(!traces.length){empty(id,"当前筛选没有该指标（未按零补齐）");return;}const l=layout(title,log);l.xaxis.categoryorder="array";l.xaxis.categoryarray=cases.filter(c=>selected.some(r=>r.id===c)).map(safe);Plotly.react(id,traces,l,config);
}
function actionPlot(selected){
 const names=Array.from(new Set(selected.flatMap(r=>r.actions.map(e=>e.action)))).sort();if(!names.length){empty("action-plot","未记录动作");return;}
 const traces=variants.filter(v=>selected.some(r=>r.variant===v)).map(v=>({type:"bar",name:safe(v),marker:{color:color(v)},x:names.map(safe),
 y:names.map(a=>selected.filter(r=>r.variant===v).reduce((n,r)=>n+r.actions.filter(e=>e.action===a).reduce((s,e)=>s+e.count,0),0)),
 hovertemplate:"%{x}<br>次数：%{y}<extra>"+safe(v)+"</extra>"}));Plotly.react("action-plot",traces,layout("动作记录次数",false),config);
}
function orderPlot(selected){
 const items=[];selected.forEach(r=>r.actions.forEach(e=>["residual_order","energy_order"].forEach(kind=>{const k=e[kind];if(Number.isInteger(k)&&k>0)items.push({variant:r.variant,kind:kind,order:k,count:e.count});})));
 if(!items.length){empty("order-plot","未记录 residual_order / energy_order");return;}
 const keys=Array.from(new Set(items.map(e=>e.kind+":"+e.order))).sort((a,b)=>{const x=a.split(":"),y=b.split(":");return x[0]===y[0]?Number(x[1])-Number(y[1]):x[0]==="residual_order"?-1:1;});
 const label=k=>(k.startsWith("residual")?"残差阶 ":"能量阶 ")+k.split(":")[1];
 const traces=variants.filter(v=>items.some(e=>e.variant===v)).map(v=>({type:"bar",name:safe(v),marker:{color:color(v)},x:keys.map(label),
 y:keys.map(k=>items.filter(e=>e.variant===v&&e.kind+":"+e.order===k).reduce((n,e)=>n+e.count,0)),hovertemplate:"%{x}<br>次数：%{y}<extra>"+safe(v)+"</extra>"}));
 Plotly.react("order-plot",traces,layout("记录次数",false),config);
}
function table(selected){
 const body=byId("runs");body.replaceChildren();selected.slice().sort((a,b)=>a.id.localeCompare(b.id)||variants.indexOf(a.variant)-variants.indexOf(b.variant)||String(a.run).localeCompare(String(b.run))||a.index-b.index).forEach(r=>{
 const tr=document.createElement("tr"),td=cell(tr,r.label,"case"),sub=document.createElement("div");sub.className="small";sub.textContent=r.id+" · "+(outcome[r.expected_outcome]||shown(r.expected_outcome));td.appendChild(sub);
 cell(tr,r.variant+" / "+shown(r.run),"mono");cell(tr,shown(r.status)+" / "+shown(r.reported_status));flag(tr,r.accepted_solution);flag(tr,r.successful_handling);flag(tr,r.physics_consistent);
 ["relative_l2","normalized_max_abs_error","seconds","equation_max_abs","guard_score"].forEach(k=>cell(tr,fmt(r[k]),"mono"));
 const more=document.createElement("td"),detail=document.createElement("details"),summary=document.createElement("summary"),pre=document.createElement("pre");summary.textContent=r.actions.length?"动作 "+r.actions.reduce((n,e)=>n+e.count,0)+" · 原始记录":"未记录动作 · 原始记录";
 pre.className="raw";pre.textContent=JSON.stringify(r.raw,null,2);detail.append(summary,pre);more.appendChild(detail);tr.appendChild(more);body.appendChild(tr);});
 if(!selected.length){const tr=document.createElement("tr"),td=cell(tr,"没有可显示记录");td.colSpan=12;body.appendChild(tr);}
}
function summary(selected){
 const unique=selected.filter(r=>r.expected_outcome==="unique"),diag=selected.filter(r=>["nonunique","incompatible"].includes(r.expected_outcome));
 const entries=[["案例 id",new Set(selected.map(r=>r.id)).size,"不是 PDE 类别数"],["运行记录",selected.length,"含全部状态与机制对照"],["唯一解记录",unique.length,"由审计预期结果确定"],["数值解通过",unique.filter(r=>r.accepted_solution===true).length,"分母 "+unique.length+" 条唯一解记录"],["正确诊断",diag.filter(r=>r.successful_handling===true).length,"分母 "+diag.length+" 条诊断记录"]];
 byId("cards").replaceChildren();entries.forEach(x=>{const e=document.createElement("div");e.className="card";const label=document.createElement("span"),n=document.createElement("b"),note=document.createElement("span");label.textContent=x[0];n.textContent=x[1];note.textContent=x[2];e.append(label,n,note);byId("cards").appendChild(e);});
 byId("summary").replaceChildren();variants.forEach(v=>{const g=selected.filter(r=>r.variant===v);if(!g.length)return;const u=g.filter(r=>r.expected_outcome==="unique"),d=g.filter(r=>["nonunique","incompatible"].includes(r.expected_outcome)),tr=document.createElement("tr");
 [v,g.length,u.length,u.filter(r=>r.accepted_solution===true).length+" / "+u.length,d.filter(r=>r.successful_handling===true).length+" / "+d.length,u.filter(r=>!finite(r.relative_l2)).length].forEach(x=>cell(tr,x));byId("summary").appendChild(tr);});
}
function render(){const c=byId("case-filter").value,v=byId("variant-filter").value,selected=rows.filter(r=>(!c||r.id===c)&&(!v||r.variant===v));
 byId("filter-count").textContent="显示 "+selected.length+" / "+rows.length+" 条运行；含失败和未决。";summary(selected);metric("error-plot",selected,"relative_l2","参考相对 L2（对数）",true);metric("time-plot",selected,"seconds","单次探索耗时 / 秒",false);actionPlot(selected);orderPlot(selected);table(selected);}
byId("case-filter").addEventListener("change",render);byId("variant-filter").addEventListener("change",render);render();
}());
</script></body></html>"""


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate a V4 offline Plotly report from completed result rows.")
    parser.add_argument("results_path", type=Path)
    parser.add_argument("output_path", type=Path)
    args = parser.parse_args()
    print(build_report(args.results_path, args.output_path))


if __name__ == "__main__":
    main()
