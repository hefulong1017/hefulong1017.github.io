"""Standalone V4 research command line; see README for scope and evidence."""
from __future__ import annotations
import argparse
from dataclasses import asdict
from datetime import datetime
import json
import re
from pathlib import Path


def main():
    parser=argparse.ArgumentParser(description='PINNLab V4 · response-order research prototype')
    commands=parser.add_subparsers(dest='command',required=True)
    commands.add_parser('list')
    s=commands.add_parser('solve')
    group=s.add_mutually_exclusive_group(required=True)
    group.add_argument('--case'); group.add_argument('--problem')
    s.add_argument('--output',default='research_v4/runs/manual')
    s.add_argument('--config'); s.add_argument('--budget',type=float)
    q=commands.add_parser('query'); q.add_argument('--run',required=True); q.add_argument('--points',required=True)
    q.add_argument('--derivatives',default=''); q.add_argument('--output')
    e=commands.add_parser('experiment'); e.add_argument('--stage',choices=['development','final'],default='development')
    e.add_argument('--directory',default='research_v4/validation'); e.add_argument('--cases'); e.add_argument('--no-ablations',action='store_true')
    r=commands.add_parser('report'); r.add_argument('--results',default='research_v4/validation/results_final.json')
    r.add_argument('--output',default='../PINNLabV4困难问题与机制实测.html')
    args=parser.parse_args()
    if args.command=='list':
        from .challenges import list_challenges
        print(json.dumps(list_challenges(),ensure_ascii=False,indent=2)); return
    if args.command=='solve':
        from .solver import SolverConfig,solve
        from .admission import analyze
        import yaml
        if args.case:
            from .challenges import make_problem
            problem=make_problem(args.case)
        else: problem=yaml.safe_load(Path(args.problem).read_text(encoding='utf-8'))
        analysis=analyze(problem)
        if analysis['incompatible']:
            print(json.dumps({'status':'incompatible_with_certificate','analysis':analysis},ensure_ascii=False,indent=2)); return
        cfg=yaml.safe_load(Path(args.config).read_text(encoding='utf-8')) if args.config else {}
        if args.budget is not None: cfg['budget_seconds']=args.budget
        result=solve(problem,SolverConfig(**cfg),callback=lambda record:print(json.dumps(record,ensure_ascii=False),flush=True))
        label=re.sub(r'[^\w-]+','_',str(problem['name']),flags=re.UNICODE).strip('_')[:80] or 'problem'
        run=Path(args.output)/f'{datetime.now():%Y%m%d_%H%M%S}_{label}'
        result.save(run)
        print(json.dumps({'run':str(run),'status':result.status,'seconds':result.seconds,'diagnostics':result.diagnostics,'analysis':analysis},ensure_ascii=False,indent=2))
    elif args.command=='query':
        from .solver import load
        import numpy as np
        result=load(args.run); p=np.array(json.loads(args.points),float)
        values=result.predict(p,[n.strip() for n in args.derivatives.split(',') if n.strip()])
        columns={v:p[:,i].tolist() for i,v in enumerate(result.problem['variables'])}
        columns.update({k:v.tolist() for k,v in values.items()})
        if args.output:
            import csv
            with Path(args.output).open('w',encoding='utf-8-sig',newline='') as file:
                writer=csv.writer(file); writer.writerow(columns); writer.writerows(zip(*columns.values()))
        print(json.dumps(columns,ensure_ascii=False,indent=2))
    elif args.command=='experiment':
        from .experiment import run_development,run_final
        if args.stage=='development': result=run_development(args.directory,args.cases.split(',') if args.cases else None,not args.no_ablations)
        else: result=run_final(args.directory)
        print(json.dumps(result['summary'],ensure_ascii=False,indent=2))
    else:
        from .report import build_report
        print(build_report(args.results,args.output))


if __name__=='__main__': main()
