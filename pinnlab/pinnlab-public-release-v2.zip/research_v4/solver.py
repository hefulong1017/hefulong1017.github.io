"""Integrable, coupled neural directions selected by residual response order.

Experimental method. It does not decide arbitrary PDE existence/uniqueness,
certify solution error, or guarantee descent in a finite feature/search budget.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import itertools
import json
from pathlib import Path
import time

import numpy as np
import torch
from scipy import linalg, optimize
from scipy.stats import qmc
from threadpoolctl import threadpool_limits

from .basis import NeuralBank, candidate_pool
from .series import Series
from .spec import Formula, validate_problem


@dataclass
class SolverConfig:
    interior: int = 128
    condition_points: int = 24
    guard: int = 256
    iterations: int = 20
    poly_degree: int = 2
    neural_frequencies: int = 1
    max_features: int = 48
    max_births: int = 8
    candidate_limit: int = 96
    max_frequency: int = 24
    response_order: int = 6
    boundary_weight: float = 10.
    branch_weight: float = 10.
    ridge: float = 1e-12
    tolerance: float = 1e-6
    branch_tolerance: float = 1e-9
    budget_seconds: float = 30.
    seed: int = 42
    threads: int = 1
    allow_birth: bool = True
    response_search: bool = True

    def validate(self):
        for key,low,high in [('interior',32,16384),('condition_points',4,1024),('guard',32,32768),
                             ('iterations',1,200),('poly_degree',0,6),('neural_frequencies',0,8),
                             ('max_features',4,256),('max_births',0,64),('candidate_limit',1,2048),
                             ('max_frequency',1,128),('response_order',1,8),('threads',1,16),('seed',0,2**31-1)]:
            v=getattr(self,key)
            if type(v) is not int or not low<=v<=high: raise ValueError('Invalid '+key)
        for key in ('boundary_weight','branch_weight','tolerance','branch_tolerance','budget_seconds','ridge'):
            if not np.isfinite(getattr(self,key)) or getattr(self,key)<0: raise ValueError('Invalid '+key)
        if self.tolerance==0 or self.boundary_weight==0: raise ValueError('Positive tolerance/condition weight required.')


def points(problem,count,seed,where=None):
    bounds=np.array([problem['domain'][v] for v in problem['variables']],float)
    u=qmc.Sobol(len(bounds),scramble=True,seed=seed).random_base2(int(np.ceil(np.log2(count))))[:count]
    p=bounds[:,0]+u*(bounds[:,1]-bounds[:,0])
    for v,value in (where or {}).items(): p[:,problem['variables'].index(v)]=value
    return p


class Block:
    def __init__(self,problem,bank,p,operator,target='0',weight=1.,branch=None,scale=None):
        self.problem,self.bank,self.points=problem,bank,p
        self.formula=Formula(operator,problem['variables'],problem['fields'],problem.get('parameters'))
        self.target=Formula(str(target),problem['variables'],problem['fields'],problem.get('parameters'),False)(p,{})
        self.target=np.broadcast_to(self.target,(len(p),)).copy()
        self.branch=branch
        self.names=sorted(self.formula.jets)
        suffixes={'u'+('_'+n.split('_',1)[1] if '_' in n else '') for n in self.names}
        values=bank.values(p,suffixes)
        self.phi={n:values['u'+('_'+n.split('_',1)[1] if '_' in n else '')] for n in self.names}
        self.indices={n:problem['fields'].index(n.split('_',1)[0]) for n in self.names}
        self.size=bank.size*len(problem['fields'])
        r=self.raw(np.zeros(self.size))
        self.normalizer=max(1.,float(np.sqrt(np.mean(r*r)))) if scale is None else scale
        self.scale=np.sqrt(weight/len(p))/self.normalizer

    def raw(self,c,jacobian=False):
        c=np.asarray(c).reshape(len(self.problem['fields']),self.bank.size)
        latent={n:torch.tensor(self.phi[n]@c[self.indices[n]],dtype=torch.float64,requires_grad=jacobian) for n in self.names}
        coordinates=torch.tensor(self.points,dtype=torch.float64)
        value=self.formula(coordinates,latent)
        if not isinstance(value,torch.Tensor): value=torch.full((len(self.points),),float(value),dtype=torch.float64)
        value=value-torch.tensor(self.target,dtype=torch.float64)
        if self.branch=='min': value=torch.clamp(-value,min=0)
        elif self.branch=='max': value=torch.clamp(value,min=0)
        r=value.detach().numpy()
        if not np.isfinite(r).all(): raise FloatingPointError('Non-finite physical residual.')
        if not jacobian: return r
        j=np.zeros((len(r),self.size))
        partial=torch.autograd.grad(value,list(latent.values()),torch.ones_like(value),allow_unused=True) if value.requires_grad and latent else [None]*len(latent)
        for n,a in zip(self.names,partial):
            if a is not None:
                f=self.indices[n]; j[:,f*self.bank.size:(f+1)*self.bank.size]+=a.detach().numpy()[:,None]*self.phi[n]
        if not np.isfinite(j).all(): raise FloatingPointError('Non-finite physical Jacobian.')
        return r,j

    def series(self,c,d,order):
        c=np.asarray(c).reshape(len(self.problem['fields']),self.bank.size)
        d=np.asarray(d).reshape(c.shape)
        latent={}
        for n in self.names:
            a=np.zeros((order+1,len(self.points)))
            a[0],a[1]=self.phi[n]@c[self.indices[n]],self.phi[n]@d[self.indices[n]]
            latent[n]=Series(a)
        value=self.formula(self.points,latent)
        if not isinstance(value,Series):
            a=np.zeros((order+1,len(self.points))); a[0]=value; value=Series(a)
        value=value-self.target
        return value.c*self.scale


class System:
    def __init__(self,problem,bank,config,seed,guard=False,normalizers=None):
        self.bank,self.problem=bank,problem
        self.blocks=[]; self.condition_blocks=[]; self.branch_blocks=[]
        params=problem.get('parameters',{})
        count=config.guard if guard else config.interior
        p=points(problem,count,seed)
        scales=iter(normalizers) if normalizers else None
        def add(operator,target,weight,p,branch=None):
            scale=next(scales) if scales is not None else None
            b=Block(problem,bank,p,operator,target,weight,branch,scale)
            self.blocks.append(b); return b
        for eq in problem['equations']: add(eq,'0',1.,p)
        self.equation_count=len(self.blocks)
        for i,c in enumerate(problem['conditions']):
            q=points(problem,config.condition_points,seed+100+i,c['where'])
            self.condition_blocks.append(add(c['operator'],c['target'],config.boundary_weight*c.get('weight',1.),q))
        for b in problem.get('branches',[]):
            kind='min' if 'min' in b else 'max'
            self.branch_blocks.append(add(b['operator'],str(b[kind]),config.branch_weight,p,kind))
        self.normalizers=[b.normalizer for b in self.blocks]

    def evaluate(self,c,jacobian=False):
        residuals=[]; matrices=[]
        for b in self.blocks:
            r=b.raw(c,jacobian)
            if jacobian: r,j=r; matrices.append(j*b.scale)
            residuals.append(r*b.scale)
        r=np.concatenate(residuals)
        return (r,np.vstack(matrices)) if jacobian else r

    def loss(self,c): return float(np.linalg.norm(self.evaluate(c)))

    def branch_violation(self,c):
        return max((float(np.max(b.raw(c))) for b in self.branch_blocks),default=0.)

    def response(self,c,d,order):
        # Inequalities may be nonsmooth; the response germ is for the physical
        # equality system. Branch feasibility is checked with the full model.
        return np.concatenate([b.series(c,d,order) for b in self.blocks if b.branch is None],axis=1)

    def boundary_space(self):
        size=self.bank.size*len(self.problem['fields'])
        if not self.condition_blocks or not all(b.formula.affine() for b in self.condition_blocks):
            return np.zeros(size),np.eye(size),False
        values=[b.raw(np.zeros(size),True) for b in self.condition_blocks]
        b=np.vstack([j*block.scale for block,(_,j) in zip(self.condition_blocks,values)])
        r=np.concatenate([v*block.scale for block,(v,_) in zip(self.condition_blocks,values)])
        c,*_=linalg.lstsq(b,-r,cond=1e-11,lapack_driver='gelsy')
        if np.linalg.norm(b@c+r)>1e-8*max(1.,np.linalg.norm(r)):
            return np.zeros(size),np.eye(size),False
        z=linalg.null_space(b,rcond=1e-10)
        return c,z,True


@dataclass
class Result:
    problem: dict
    config: SolverConfig
    bank: NeuralBank
    coefficients: np.ndarray
    history: list
    status: str
    seconds: float
    diagnostics: dict

    def predict(self,p,derivatives=()):
        p=np.asarray(p,float)
        bounds=np.array([self.problem['domain'][v] for v in self.problem['variables']])
        if p.ndim!=2 or p.shape[1]!=len(bounds) or not np.isfinite(p).all() or np.any(p<bounds[:,0]) or np.any(p>bounds[:,1]): raise ValueError('Coordinates outside domain or invalid shape.')
        names=list(dict.fromkeys(self.problem['fields']+list(derivatives)))
        for name in names: Formula(name,self.problem['variables'],self.problem['fields'])
        suffixes={'u'+('_'+n.split('_',1)[1] if '_' in n else '') for n in names}
        phi=self.bank.values(p,suffixes)
        c=self.coefficients.reshape(len(self.problem['fields']),self.bank.size)
        return {n:phi['u'+('_'+n.split('_',1)[1] if '_' in n else '')]@c[self.problem['fields'].index(n.split('_',1)[0])] for n in names}

    def save(self,path):
        path=Path(path); path.mkdir(parents=True,exist_ok=True)
        state={'problem':self.problem,'config':asdict(self.config),'features':self.bank.features,
               'coefficients':self.coefficients.tolist(),'history':self.history,'status':self.status,
               'seconds':self.seconds,'diagnostics':self.diagnostics,'training_uses_reference':False,
               'claim':'experimental_response_order_aware_direction_birth_not_proven_original_or_universal'}
        (path/'model.json').write_text(json.dumps(state,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
        return path


def load(path):
    s=json.loads((Path(path)/'model.json').read_text(encoding='utf-8'))
    p=validate_problem(s['problem'])
    bank=NeuralBank(p['variables'],[p['domain'][v] for v in p['variables']],features=s['features'])
    return Result(p,SolverConfig(**s['config']),bank,np.array(s['coefficients']),s['history'],s['status'],s['seconds'],s['diagnostics'])


def _accepted(a,g,c,candidate,cfg):
    try:
        la,lg=a.loss(candidate),g.loss(candidate)
        olda,oldg=a.loss(c),g.loss(c)
        branch0=max(a.branch_violation(c),g.branch_violation(c))
        branch=max(a.branch_violation(candidate),g.branch_violation(candidate))
        feasible=branch<=cfg.branch_tolerance if branch0<=cfg.branch_tolerance else branch<branch0 or branch<=cfg.branch_tolerance
        return feasible and la<olda-1e-13*max(1.,olda) and lg<oldg-1e-13*max(1.,oldg),la,lg,branch
    except (FloatingPointError,ValueError,OverflowError): return False,float('inf'),float('inf'),float('inf')


def _direction_candidates(z,bank,fields,seed,limit=24):
    if not z.shape[1]: return []
    directions=[]
    # Preserve low-degree directions inside the admissible space. Projecting
    # a single coordinate through the full condition nullspace can mix it with
    # oscillatory features and destroy a feasible monotone direction. Compute
    # exact intersections with nested polynomial spans before full-space probes.
    projector=z@z.T
    complement=np.eye(len(projector))-projector
    previous=None
    for degree in range(1,7):
        features=[j for j,f in enumerate(bank.features) if f['kind']=='poly' and sum(f['powers'])<=degree]
        indices=[a*bank.size+j for a in range(len(fields)) for j in features]
        if not indices or indices==previous: continue
        previous=indices
        _,singular,vh=linalg.svd(complement[:,indices],full_matrices=True)
        rank=int(np.sum(singular>1e-8))
        for v in vh[rank:rank+limit]:
            d=np.zeros(len(projector)); d[indices]=v; directions.append(d)
    directions.extend(z[:,i] for i in range(min(limit,z.shape[1])))
    # Shared vector directions are essential: u*v at (0,0) has no scalar-
    # output response at any amplitude when only one field changes.
    for j in range(min(bank.size,12)):
        for signs in ([1.]*len(fields),[(-1.)**i for i in range(len(fields))]):
            d=np.zeros(z.shape[0])
            for i,sign in enumerate(signs): d[i*bank.size+j]=sign
            directions.append(z@(z.T@d))
    rng=np.random.default_rng(seed)
    directions.extend(z@rng.normal(size=z.shape[1]) for _ in range(4))
    return [v/np.linalg.norm(v) for v in directions if np.linalg.norm(v)>1e-9]


def _birth_pool(bank,limit,max_frequency):
    pool=list(candidate_pool(bank,max_frequency=max_frequency))
    if len(pool)<=limit: return pool
    lifts=[d for d in pool if d['kind']=='poly'][:limit//2]
    neural=[d for d in pool if d['kind']!='poly']
    remaining=limit-len(lifts)
    # Retain the low-complexity head before dispersed scales. Evenly spaced
    # indices alone can systematically omit BOTH sin(2x) and cos(2x).
    prefix=min(12,remaining//3,len(neural))
    tail=neural[prefix:]
    indices=np.linspace(0,len(tail)-1,min(remaining-prefix,len(tail)),dtype=int) if tail else []
    return lifts+neural[:prefix]+[tail[i] for i in indices]


def _response_step(a,g,c,d,cfg,deadline=None):
    def expired(): return deadline is not None and time.perf_counter()>=deadline
    try:
        if expired(): return None
        series=a.response(c,d,cfg.response_order)
        if not np.isfinite(series).all(): return None
        energy=[]
        for k in range(1,cfg.response_order+1):
            energy.append(.5*sum(float(np.dot(series[j],series[k-j])) for j in range(k+1)))
        threshold=1e-10*max(1.,float(np.dot(series[0],series[0])))
        leading=next((k for k,e in enumerate(energy,1) if abs(e)>threshold),None)
        if leading is None or leading%2==0 and energy[leading-1]>=0: return None
        response_order=next((k for k in range(1,len(series)) if np.linalg.norm(series[k])>1e-12),leading)
        scale=(max(np.linalg.norm(series[0]),1e-8)/max(np.linalg.norm(series[response_order]),1e-12))**(1/response_order)
        scale=float(np.clip(scale,1e-6,1e4))
        signs=[1.,-1.] if leading%2==0 else [-float(np.sign(energy[leading-1]))]
        best=None
        for sign in signs:
            for factor in (.125,.25,.5,1.,2.):
                if expired(): return best
                alpha=sign*scale*factor
                candidate=c+alpha*d
                accepted,la,lg,branch=_accepted(a,g,c,candidate,cfg)
                if accepted and (best is None or lg<best['guard']):
                    best={'coefficients':candidate,'alpha':alpha,'guard':lg,'training':la,'branch':branch,
                          'energy_order':leading,'residual_order':response_order,'energy_coefficient':energy[leading-1]}
        if best is not None and not expired():
            center=best['alpha']
            def value(alpha):
                if expired(): raise TimeoutError('Soft solver budget reached.')
                okay,_,lg,_=_accepted(a,g,c,c+alpha*d,cfg)
                return lg if okay else g.loss(c)+abs(alpha)*1e-9
            try:
                fit=optimize.minimize_scalar(value,bounds=sorted([center*.25,center*1.75]),method='bounded',options={'xatol':1e-12,'maxiter':35})
            except TimeoutError: return best
            if fit.success:
                candidate=c+fit.x*d; okay,la,lg,branch=_accepted(a,g,c,candidate,cfg)
                if okay and lg<best['guard']: best.update(coefficients=candidate,alpha=float(fit.x),guard=lg,training=la,branch=branch)
        return best
    except (ValueError,FloatingPointError,OverflowError,ZeroDivisionError):
        return None


def solve(problem,config=None,callback=None):
    cfg=config or SolverConfig(); cfg.validate(); p=validate_problem(problem)
    started=time.perf_counter(); torch.set_num_threads(cfg.threads)
    deadline=started+cfg.budget_seconds if cfg.budget_seconds else None
    def expired(): return deadline is not None and time.perf_counter()>=deadline
    bank=NeuralBank(p['variables'],[p['domain'][v] for v in p['variables']],poly_degree=cfg.poly_degree,neural_frequencies=cfg.neural_frequencies)
    if bank.size>cfg.max_features:
        raise ValueError('Initial feature count exceeds max_features; reduce poly_degree/neural_frequencies or increase max_features.')
    a=System(p,bank,cfg,cfg.seed)
    normalizers=a.normalizers
    g=System(p,bank,cfg,cfg.seed+1,True,normalizers)
    c,z,hard=a.boundary_space()
    history=[]; births=0; status='iteration_limit'; rng=np.random.default_rng(cfg.seed)
    with threadpool_limits(limits=cfg.threads):
        for step in range(cfg.iterations):
            if expired(): status='budget'; break
            loss=g.loss(c); branch=g.branch_violation(c)
            if max(loss,a.loss(c))<=cfg.tolerance and max(branch,a.branch_violation(c))<=cfg.branch_tolerance: status='physics_tolerance'; break
            r,j=a.evaluate(c,True)
            effective=j@z
            record={'step':step,'features':bank.size,'guard':loss,'branch_violation':branch,
                    'gradient_norm':float(np.linalg.norm(effective.T@r)),'births':births,
                    'seconds':time.perf_counter()-started,'boundary_eliminated':hard,'guard_before':loss}
            history.append(record)
            accepted=False
            if effective.shape[1] and record['gradient_norm']>1e-12*max(1.,float(np.linalg.norm(r))):
                norms=np.linalg.norm(effective,axis=0)
                norms=np.maximum(norms,1e-8*max(1.,float(np.max(norms))))
                matrix=effective/norms
                if cfg.ridge: matrix=np.vstack([matrix,np.sqrt(cfg.ridge)*np.eye(matrix.shape[1])]); rhs=np.r_[-r,np.zeros(matrix.shape[1])]
                else: rhs=-r
                d,*_=linalg.lstsq(matrix,rhs,cond=1e-10,lapack_driver='gelsy'); d=z@(d/norms)
                for k in range(14):
                    if expired(): break
                    okay,la,lg,bv=_accepted(a,g,c,c+2.**(-k)*d,cfg)
                    if okay:
                        c=c+2.**(-k)*d; record.update(action='gauss_newton',guard_after=lg,damping=2.**(-k)); accepted=True; break
            if not accepted and cfg.response_search:
                best=None
                for d in _direction_candidates(z,bank,p['fields'],cfg.seed+step):
                    if expired(): break
                    trial=_response_step(a,g,c,d,cfg,deadline)
                    if trial is not None and (best is None or trial['guard']<best['guard']): best=trial
                    if best is not None and best['guard']<=cfg.tolerance: break
                if best is not None:
                    c=best.pop('coefficients'); record.update(action='response_in_current_space',**best); accepted=True
            if not accepted and not expired() and cfg.allow_birth and births<cfg.max_births and bank.size<cfg.max_features:
                pool=_birth_pool(bank,cfg.candidate_limit,cfg.max_frequency)
                best=None
                for pool_index,descriptor in enumerate(pool):
                    if expired(): break
                    newbank=bank.append(descriptor)
                    newa=System(p,newbank,cfg,cfg.seed,normalizers=normalizers)
                    newg=System(p,newbank,cfg,cfg.seed+1,True,normalizers)
                    newlift,newz,newhard=newa.boundary_space()
                    born=[descriptor]
                    # Several new functions may be needed before high-order
                    # endpoint constraints leave any admissible direction.
                    if newhard and not newz.shape[1]:
                        for extra in pool[pool_index+1:pool_index+5]:
                            if newbank.size>=cfg.max_features or expired(): break
                            newbank=newbank.append(extra); born.append(extra)
                            newa=System(p,newbank,cfg,cfg.seed,normalizers=normalizers)
                            newlift,newz,newhard=newa.boundary_space()
                            if newz.shape[1]: break
                        newg=System(p,newbank,cfg,cfg.seed+1,True,normalizers)
                    newc=np.c_[c.reshape(len(p['fields']),bank.size),np.zeros((len(p['fields']),newbank.size-bank.size))].ravel()
                    # Judge a new space after refitting existing readout weights,
                    # rather than confuse a poor coordinate direction with a
                    # useless feature. This is ordinary variable projection;
                    # high-order response remains necessary when J is flat.
                    base=newlift+newz@(newz.T@(newc-newlift)) if newhard else newc
                    candidates=[(base,'sampled_condition_projection')]
                    rr,jj=newa.evaluate(base,True)
                    reduced=jj@newz
                    if reduced.shape[1] and np.linalg.norm(reduced.T@rr)>1e-12*max(1.,np.linalg.norm(rr)):
                        scale=np.maximum(np.linalg.norm(reduced,axis=0),1e-8*max(1.,float(np.max(np.linalg.norm(reduced,axis=0)))))
                        matrix=np.vstack([reduced/scale,np.sqrt(cfg.ridge)*np.eye(reduced.shape[1])])
                        rhs=np.r_[-rr,np.zeros(reduced.shape[1])]
                        direction,*_=linalg.lstsq(matrix,rhs,cond=1e-10,lapack_driver='gelsy')
                        direction=newz@(direction/scale)
                        candidates.extend((base+2.**(-k)*direction,'linearized_feature_refit') for k in range(6))
                    for fitted,kind in candidates:
                        if expired(): break
                        okay,la,lg,bv=_accepted(newa,newg,newc,fitted,cfg)
                        if okay and (best is None or lg<best[0]['guard']):
                            trial={'coefficients':fitted,'guard':lg,'training':la,'branch':bv,
                                   'energy_order':None,'residual_order':None,'proposal':kind}
                            best=(trial,newbank,newa,newg,newz,newhard,born)
                    if best is not None and best[0]['guard']<=cfg.tolerance: break
                    for signs in (([1.]*len(p['fields']),[(-1.)**i for i in range(len(p['fields']))]) if cfg.response_search else ()):
                        if expired(): break
                        d=np.zeros(len(newc))
                        for f,sign in enumerate(signs): d[f*newbank.size+newbank.size-1]=sign
                        d=newz@(newz.T@d)
                        if np.linalg.norm(d)<1e-8: continue
                        trial=_response_step(newa,newg,newc,d/np.linalg.norm(d),cfg,deadline)
                        if trial is not None and (best is None or trial['guard']<best[0]['guard']): best=(trial,newbank,newa,newg,newz,newhard,born)
                    if best is not None and best[0]['guard']<=cfg.tolerance: break
                if best is not None:
                    trial,bank,a,g,z,hard,descriptor=best; c=trial.pop('coefficients'); births+=1
                    if hard and max((np.max(np.abs(b.raw(c))) for b in a.condition_blocks),default=0)>1e-8:
                        hard=False; z=np.eye(len(c))
                    record.update(action='feature_birth',feature=descriptor,**trial); accepted=True
            if not accepted:
                record['action']='budget' if expired() else 'no_accepted_direction'
                status='budget' if expired() else 'inconclusive'; break
            if callback: callback(record)
        if max(a.loss(c),g.loss(c))<=cfg.tolerance and max(a.branch_violation(c),g.branch_violation(c))<=cfg.branch_tolerance: status='physics_tolerance'
        elif expired(): status='budget'
    diagnostics={'training_score':a.loss(c),'guard_score':g.loss(c),'guard_branch_violation':g.branch_violation(c),
                 'training_branch_violation':a.branch_violation(c),
                 'field_count':len(p['fields']),'equation_count':len(p['equations']),'features':bank.size,'births':births,
                 'boundary_eliminated':hard,'interpretation':'Physics checks are empirical, not a solution error certificate or existence/uniqueness decision.'}
    seconds=time.perf_counter()-started
    diagnostics.update(budget_seconds=cfg.budget_seconds,budget_exceeded=bool(cfg.budget_seconds and seconds>cfg.budget_seconds),
                       budget_overrun_seconds=max(0.,seconds-cfg.budget_seconds) if cfg.budget_seconds else 0.,
                       budget_interpretation='Soft deadline checked between evaluations; an individual linear solve or residual evaluation is not preempted.')
    return Result(p,cfg,bank,c,history,status,seconds,diagnostics)
