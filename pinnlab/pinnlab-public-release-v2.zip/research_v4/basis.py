"""Expandable neural functions with mutually consistent physical jets to order six.

Each descriptor defines one scalar function, rather than independently fitted
derivatives. Descriptors are JSON-compatible and use ``kind`` plus:
``poly/powers``, ``sin|cos/frequency``, ``tanh/direction,bias``, or
``product/factors``. Chebyshev and tanh coordinates lie in [-1, 1]; Fourier
angles use pi * (x-a)/(b-a). Derivatives always use physical coordinates.
"""
from __future__ import annotations

from functools import lru_cache
import itertools
import json
import math

import numpy as np
from numpy.polynomial import chebyshev, polynomial

MAX_ORDER = 6


def _descriptor_key(descriptor):
    return json.dumps(descriptor, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _multiindices(dimension, total):
    if dimension == 1:
        yield (total,)
        return
    for first in range(total + 1):
        for tail in _multiindices(dimension - 1, total - first):
            yield (first,) + tail


def _vector(value, dimension, name, integer=False):
    if not isinstance(value, (tuple, list, np.ndarray)) or len(value) != dimension:
        raise ValueError(f"{name} must contain one entry per coordinate")
    answer = []
    for item in value:
        if isinstance(item, (bool, np.bool_)) or not isinstance(item, (int, float, np.integer, np.floating)):
            raise ValueError(f"{name} entries must be finite numbers")
        number = float(item)
        if not math.isfinite(number):
            raise ValueError(f"{name} entries must be finite numbers")
        if integer:
            if number != int(number) or not 0 <= number <= 32:
                raise ValueError("Chebyshev powers must be integers in 0..32")
            answer.append(int(number))
        else:
            answer.append(0.0 if number == 0 else number)
    return answer


def _canonical(descriptor, dimension, depth=0):
    if not isinstance(descriptor, dict) or depth > 4:
        raise ValueError("A feature must be a descriptor mapping with limited nesting")
    kind = descriptor.get("kind")
    if kind == "poly":
        if set(descriptor) != {"kind", "powers"}:
            raise ValueError("A poly feature requires only kind and powers")
        return {"kind": kind, "powers": _vector(descriptor["powers"], dimension, "powers", True)}
    if kind in ("sin", "cos"):
        if set(descriptor) != {"kind", "frequency"}:
            raise ValueError("A Fourier feature requires only kind and frequency")
        return {"kind": kind, "frequency": _vector(descriptor["frequency"], dimension, "frequency")}
    if kind == "tanh":
        if set(descriptor) - {"kind", "direction", "bias"} or "direction" not in descriptor:
            raise ValueError("A tanh feature requires direction and optional bias")
        bias = descriptor.get("bias", 0.)
        if isinstance(bias, (bool, np.bool_)) or not isinstance(bias, (int, float, np.integer, np.floating)) or not math.isfinite(float(bias)):
            raise ValueError("tanh bias must be finite")
        return {"kind": kind, "direction": _vector(descriptor["direction"], dimension, "direction"),
                "bias": 0.0 if float(bias) == 0 else float(bias)}
    if kind == "product":
        factors = descriptor.get("factors")
        if set(descriptor) != {"kind", "factors"} or not isinstance(factors, (tuple, list)) or not 1 <= len(factors) <= 4:
            raise ValueError("A product requires one to four factors")
        flattened = []
        for raw in factors:
            factor = _canonical(raw, dimension, depth + 1)
            if factor["kind"] == "product":
                flattened.extend(factor["factors"])
            elif factor["kind"] != "poly" or any(factor["powers"]):
                flattened.append(factor)
        if len(flattened) > 4:
            raise ValueError("A product may contain at most four primitive factors")
        if not flattened:
            return {"kind": "poly", "powers": [0] * dimension}
        if len(flattened) == 1:
            return flattened[0]
        return {"kind": "product", "factors": sorted(flattened, key=_descriptor_key)}
    raise ValueError(f"Unknown feature kind: {kind}")


@lru_cache(maxsize=256)
def _cheb_coefficients(degree, order):
    coefficients = np.zeros(degree + 1)
    coefficients[degree] = 1.
    if order > degree:
        return np.zeros(1)
    return chebyshev.chebder(coefficients, m=order)


def _tanh_polynomials():
    answer = [np.array([0., 1.])]
    for _ in range(MAX_ORDER):
        answer.append(polynomial.polymul(polynomial.polyder(answer[-1]), [1., 0., -1.]))
    return answer


_TANH_POLYNOMIALS = _tanh_polynomials()
# Every positive-order P_n contains 1-t^2. Factoring it avoids subtracting
# nearly equal O(1) terms and then magnifying that error by a slope^6 chain.
_TANH_FACTORS = [None] + [polynomial.polydiv(p, [1., 0., -1.])[0]
                          for p in _TANH_POLYNOMIALS[1:]]


class NeuralBank:
    """Nested JSON-described functions and exact physical-coordinate jets.

    Explicit ``features=[]`` creates an empty bank. ``append`` never mutates
    its receiver, and duplicate canonical descriptors are retained only once.
    A descriptor can be round-tripped through JSON without changing values.
    """

    def __init__(self, variables, bounds, features=None, poly_degree=2, neural_frequencies=1):
        self.variables = list(variables)
        if not 1 <= len(self.variables) <= 4 or len(set(self.variables)) != len(self.variables) or any(
                not isinstance(v, str) or len(v) != 1 or v not in "xyzt" for v in self.variables):
            raise ValueError("Use one to four distinct x/y/z/t coordinates")
        raw_bounds = [bounds[v] for v in self.variables] if isinstance(bounds, dict) else bounds
        self.bounds = np.array(raw_bounds, dtype=np.float64, copy=True)
        dimension = len(self.variables)
        if self.bounds.shape != (dimension, 2) or not np.isfinite(self.bounds).all() or np.any(self.bounds[:, 1] <= self.bounds[:, 0]):
            raise ValueError("Bounds must contain finite increasing intervals")
        if type(poly_degree) is not int or not 0 <= poly_degree <= 12:
            raise ValueError("poly_degree must be an integer in 0..12")
        if type(neural_frequencies) is not int or not 0 <= neural_frequencies <= 64:
            raise ValueError("neural_frequencies must be an integer in 0..64")
        self.poly_degree, self.neural_frequencies = poly_degree, neural_frequencies
        if features is None:
            features = [{"kind": "poly", "powers": list(powers)}
                        for total in range(poly_degree + 1) for powers in _multiindices(dimension, total)]
            for frequency in range(1, neural_frequencies + 1):
                for axis in range(dimension):
                    vector = [0] * dimension
                    vector[axis] = frequency
                    for kind in ("sin", "cos"):
                        features.append({"kind": kind, "frequency": vector.copy()})
        if not isinstance(features, (list, tuple)):
            raise ValueError("features must be a JSON sequence of descriptors")
        unique = {}
        for feature in features:
            feature = _canonical(feature, dimension)
            unique.setdefault(_descriptor_key(feature), feature)
        self.features = list(unique.values())
        self.size = len(self.features)
        self._keys = frozenset(unique)

    def append(self, descriptor):
        """Return a new bank with one canonical feature added, if absent."""
        feature = _canonical(descriptor, len(self.variables))
        features = [*self.features]
        if _descriptor_key(feature) not in self._keys:
            features.append(feature)
        return NeuralBank(self.variables, self.bounds, features=features,
                          poly_degree=self.poly_degree, neural_frequencies=self.neural_frequencies)

    def _orders(self, names):
        if isinstance(names, str):
            names = [names]
        orders = {}
        for name in names:
            if name == "u":
                orders[name] = (0,) * len(self.variables)
                continue
            suffix = name[2:] if isinstance(name, str) and name.startswith("u_") else ""
            if not 1 <= len(suffix) <= MAX_ORDER or any(v not in self.variables for v in suffix):
                raise ValueError("Use u or u_<coordinate suffix>, with total derivative order 1..6")
            orders[name] = tuple(suffix.count(v) for v in self.variables)
        return orders

    def values(self, points, names):
        """Return ``name -> (points, features)`` arrays, including mixed jets."""
        points = np.asarray(points, dtype=np.float64)
        if points.ndim != 2 or points.shape[1] != len(self.variables) or not np.isfinite(points).all():
            raise ValueError("points must be a finite (n, dimensions) array")
        orders = self._orders(names)
        lengths = self.bounds[:, 1] - self.bounds[:, 0]
        unit = (points - self.bounds[:, 0]) / lengths
        normalized = 2. * unit - 1.
        coordinate_cache, cache = {}, {}

        def cheb_axis(axis, degree, order):
            key = (axis, degree, order)
            if key not in coordinate_cache:
                coordinate_cache[key] = chebyshev.chebval(normalized[:, axis], _cheb_coefficients(degree, order)) * (2. / lengths[axis]) ** order
            return coordinate_cache[key]

        def product_value(factors, alpha):
            if len(factors) == 1:
                return evaluate(factors[0], alpha)
            key = ("product_tail", tuple(_descriptor_key(f) for f in factors), alpha)
            if key in cache:
                return cache[key]
            answer = np.zeros(len(points))
            for beta in itertools.product(*(range(a + 1) for a in alpha)):
                remainder = tuple(a - b for a, b in zip(alpha, beta))
                coefficient = math.prod(math.comb(a, b) for a, b in zip(alpha, beta))
                answer += coefficient * evaluate(factors[0], beta) * product_value(factors[1:], remainder)
            cache[key] = answer
            return answer

        def evaluate(feature, alpha):
            key = (_descriptor_key(feature), alpha)
            if key in cache:
                return cache[key]
            kind, order = feature["kind"], sum(alpha)
            if kind == "poly":
                answer = np.ones(len(points))
                for axis, (degree, derivative) in enumerate(zip(feature["powers"], alpha)):
                    answer *= cheb_axis(axis, degree, derivative)
            elif kind in ("sin", "cos"):
                frequency = np.asarray(feature["frequency"])
                angle = np.pi * (unit @ frequency)
                chain = np.pi * frequency / lengths
                multiplier = math.prod(float(chain[j]) ** a for j, a in enumerate(alpha))
                # Reduce the phase cycle exactly: sin(z + k*pi/2) incurs
                # avoidable cancellation at high derivatives and special z.
                cycle = order % 4
                if kind == "cos":
                    cycle = (cycle + 1) % 4
                answer = (np.sin(angle), np.cos(angle), -np.sin(angle), -np.cos(angle))[cycle] * multiplier
            elif kind == "tanh":
                direction = np.asarray(feature["direction"])
                t = np.tanh(normalized @ direction + feature["bias"])
                chain = 2. * direction / lengths
                multiplier = math.prod(float(chain[j]) ** a for j, a in enumerate(alpha))
                derivative = t if order == 0 else (1. - t * t) * polynomial.polyval(t, _TANH_FACTORS[order])
                answer = derivative * multiplier
            else:
                answer = product_value(feature["factors"], alpha)
            cache[key] = answer
            return answer

        answer = {}
        with np.errstate(over="raise", invalid="raise", divide="raise"):
            for name, alpha in orders.items():
                result = np.column_stack([evaluate(feature, alpha) for feature in self.features]) if self.features else np.empty((len(points), 0), dtype=float)
                if not np.isfinite(result).all():
                    raise FloatingPointError(f"Non-finite physical derivative: {name}")
                # Equal mixed derivative requests remain independent arrays.
                answer[name] = result
        return answer


def candidate_pool(bank, max_frequency=24):
    """Return absent JSON descriptors, interleaving feature families.

    Includes Chebyshev total degrees 3..6, axis Fourier modes, pairwise oblique
    modes through frequency 4, translated tanh ridges, and Fourier times a
    different coordinate's degree-1..3 Chebyshev factor. Zero-degree products
    are the primitive Fourier descriptors and are deduplicated automatically.
    """
    if not isinstance(bank, NeuralBank):
        raise TypeError("bank must be a NeuralBank")
    if type(max_frequency) is not int or not 1 <= max_frequency <= 256:
        raise ValueError("max_frequency must be an integer in 1..256")
    dimension = len(bank.variables)
    groups = [[] for _ in range(5)]
    for total in range(3, 7):
        for powers in _multiindices(dimension, total):
            groups[0].append({"kind": "poly", "powers": list(powers)})
    for frequency in range(1, max_frequency + 1):
        for axis in range(dimension):
            vector = [0] * dimension
            vector[axis] = frequency
            for kind in ("sin", "cos"):
                groups[1].append({"kind": kind, "frequency": vector.copy()})
                for other in range(dimension):
                    if other == axis:
                        continue
                    for degree in range(1, 4):
                        powers = [0] * dimension
                        powers[other] = degree
                        groups[4].append({"kind": "product", "factors": [
                            {"kind": kind, "frequency": vector.copy()},
                            {"kind": "poly", "powers": powers}]})
    for first, second in itertools.combinations(range(dimension), 2):
        for fa in range(1, min(4, max_frequency) + 1):
            for fb in range(1, min(4, max_frequency) + 1):
                for sign in (1, -1):
                    vector = [0] * dimension
                    vector[first], vector[second] = fa, sign * fb
                    for kind in ("sin", "cos"):
                        groups[2].append({"kind": kind, "frequency": vector.copy()})
    for slope in (2., 8., 32.):
        for center in (-.75, -.25, .25, .75):
            for axis in range(dimension):
                direction = [0.] * dimension
                direction[axis] = slope
                groups[3].append({"kind": "tanh", "direction": direction,
                                  "bias": -slope * center})
    seen = set(bank._keys)
    answer = []
    for row in itertools.zip_longest(*groups):
        for feature in row:
            if feature is None:
                continue
            feature = _canonical(feature, dimension)
            key = _descriptor_key(feature)
            if key not in seen:
                seen.add(key)
                answer.append(feature)
    return answer
