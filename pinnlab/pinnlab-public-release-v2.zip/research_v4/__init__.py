"""V4 research prototype, separate from the frozen V3 implementation."""
__version__ = '4.0.0-research'
