"""Fixed-input development, then frozen-model evaluation on fresh points."""
from __future__ import annotations
from dataclasses import asdict,replace
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import statistics

import numpy as np
from .challenges import list_challenges,make_problem,audit_candidate
from .solver import SolverConfig,solve,load,points
from .admission import analyze

ROOT=Path(__file__).resolve().parent
FINAL_SEED=20261110


def read(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def write(path,data):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sources(): return {p.relative_to(ROOT).as_posix():sha(p) for p in sorted(ROOT.rglob('*.py')) if 'runs' not in p.parts and 'validation' not in p.parts}


def outcome(result,analysis):
    if analysis['incompatible']: return 'incompatible'
    if result is None or result.status!='physics_tolerance': return 'undetermined'
    for symmetry in analysis.get('symmetries',[]):
        # A zero solution is its own reflection; parity alone cannot establish
        # distinctness. These remain numerical candidates, not existence proofs.
        if symmetry['type']=='constant_shift': return 'nonunique'
        if symmetry['type']=='sign_reflection':
            values=result.predict(points(result.problem,32,184105))
            if any(np.max(np.abs(values[f]))>1e-8 for f in symmetry['fields']):
                return 'nonunique'
    return 'solution'


def summary(rows):
    full=[r for r in rows if r['variant']=='full']
    return {'challenge_cases':len(full),'accepted_numerical_solutions':sum(bool(r['audit']['accepted_solution']) for r in full),
            'successful_handling':sum(bool(r['audit']['successful_handling']) for r in full),
            'unresolved_case_ids':[r['id'] for r in full if not r['audit']['successful_handling']],
            'note':'Challenge count includes ODE/interface, impossible and nonunique cases; it is not a count of PDE classes solved.'}


def run_development(directory='research_v4/validation',case_ids=None,ablations=True):
    directory=Path(directory).resolve(); directory.mkdir(parents=True,exist_ok=True)
    selected=case_ids or [c['id'] for c in list_challenges()]
    # A common configuration; no per-case fit to private reference values.
    base=SolverConfig(iterations=25,budget_seconds=20.,candidate_limit=64,max_frequency=48)
    source=sources(); output=directory/'results_development.json'
    request={'cases':selected,'config':asdict(base),'ablations':ablations,'audit_count':1024,'audit_seed':84105}
    if output.exists():
        report=read(output)
        if report['source_sha256']!=source or report['request']!=request: raise RuntimeError('Sources or configuration changed; use a new experiment directory.')
    else:
        report={'stage':'development','created_at_utc':datetime.now(timezone.utc).isoformat(),'request':request,
                'source_sha256':source,'rows':[],'timing_definition':'Single exploratory run per row: solver setup and optimization, excluding symbolic admission, independent audit and export. No repeated-timing confidence interval or FD/FEM speedup claim.'}
    completed={(r['id'],r['variant']) for r in report['rows']}
    mechanism={'degenerate_curvature_power2','degenerate_curvature_power4','coupled_product_degenerate','beam_fourth_order','sixth_order_clamped','monge_original'}
    for case in selected:
        variants={'full':base}
        if ablations and case in mechanism:
            variants.update(gn_fixed=replace(base,response_search=False,allow_birth=False),
                            order2_fixed=replace(base,response_order=2,allow_birth=False),
                            order6_fixed=replace(base,allow_birth=False),
                            gn_large=replace(base,poly_degree=6,response_search=False,allow_birth=False))
        for variant,cfg in variants.items():
            if (case,variant) in completed: continue
            print('RUN',case,variant,flush=True)
            problem=make_problem(case); analysis=analyze(problem)
            row={'id':case,'variant':variant,'config':asdict(cfg),'analysis':analysis,'run':None,'history':[]}
            try:
                if analysis['incompatible']:
                    result=None; row.update(status='incompatible_with_certificate',seconds=0.,diagnostics={})
                else:
                    result=solve(problem,cfg)
                    run=directory/'runs'/case/variant; result.save(run)
                    row.update(run=str(run.relative_to(directory)),status=result.status,seconds=result.seconds,
                               diagnostics=result.diagnostics,history=result.history,model_sha256=sha(run/'model.json'))
                row['reported_status']=outcome(result,analysis)
                row['audit']=audit_candidate(case,result.predict if result else None,row['reported_status'],count=1024,seed=84105)
            except Exception as exc:
                row.update(status='failed',reported_status='failed',seconds=None,diagnostics={},error=f'{type(exc).__name__}: {exc}')
                row['audit']={'accepted_solution':False,'successful_handling':False,'audit_error':row['error']}
            report['rows'].append(row); report['summary']=summary(report['rows']); write(output,report)
            print('DONE',case,variant,row['status'],row['audit']['accepted_solution'],flush=True)
    # Freeze every attempted variant, including failures, before fresh E points.
    models={r['id']+'/'+r['variant']:{'path':r['run'],'sha256':r['model_sha256']} for r in report['rows'] if r.get('run')}
    frozen={'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':source,'models':models,
            'development_sha256':sha(output),'final_seed':FINAL_SEED,'final_count':8192,'training_uses_reference':False}
    manifest=directory/'frozen_v4.json'
    if manifest.exists() and read(manifest)!=frozen:
        # Do not silently refreeze after an audit or substitute checkpoints.
        old=read(manifest)
        for key in ('source_sha256','models','development_sha256'):
            if old[key]!=frozen[key]: raise RuntimeError('Existing freeze differs; preserve it.')
    else: write(manifest,frozen)
    return report


def run_final(directory='research_v4/validation'):
    directory=Path(directory).resolve(); frozen=read(directory/'frozen_v4.json')
    if sources()!=frozen['source_sha256']: raise RuntimeError('V4 frozen source changed.')
    devpath=directory/'results_development.json'
    if sha(devpath)!=frozen['development_sha256']: raise RuntimeError('Development report changed.')
    dev=read(devpath)
    expected={r['id']+'/'+r['variant']:{'path':r['run'],'sha256':r['model_sha256']} for r in dev['rows'] if r.get('run')}
    if expected!=frozen['models']: raise RuntimeError('Frozen model set differs from development runs.')
    if frozen['final_seed']!=FINAL_SEED or frozen['final_count']!=8192: raise RuntimeError('Unexpected frozen audit parameters.')
    for spec in frozen['models'].values():
        if sha(directory/spec['path']/'model.json')!=spec['sha256']: raise RuntimeError('Frozen model changed.')
    report={'stage':'final','seed':frozen['final_seed'],'count':frozen['final_count'],'source_sha256':frozen['source_sha256'],
            'freeze_sha256':sha(directory/'frozen_v4.json'),'rows':[],
            'timing_definition':'Original development training time reused. No retraining or configuration selection on final coordinates.'}
    for old in dev['rows']:
        row={k:v for k,v in old.items() if k!='audit'}
        model=load(directory/row['run']) if row.get('run') else None
        row['audit']=audit_candidate(row['id'],model.predict if model else None,row['reported_status'],count=frozen['final_count'],seed=frozen['final_seed'])
        row['timing_reused']=True
        report['rows'].append(row); report['summary']=summary(report['rows']); write(directory/'results_final.json',report)
        print('FINAL',row['id'],row['variant'],row['audit']['accepted_solution'],flush=True)
    return report
