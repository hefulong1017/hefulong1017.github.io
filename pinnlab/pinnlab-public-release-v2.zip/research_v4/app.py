"""Independent Chinese V4 research interface; run with Streamlit, port 8502.

The app passes physical input only to admission/solve. It deliberately does not
import private audit references or infer solution error from sampled residuals.
"""
from __future__ import annotations

from dataclasses import asdict
import io
import json
from pathlib import Path
import sys

# Streamlit executes this file as a script and may put only research_v4 on
# sys.path. Resolve the package from this file instead of the caller's cwd.
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
import yaml

from research_v4.admission import analyze
from research_v4.challenges import list_challenges, make_problem
from research_v4.solver import SolverConfig, solve
from research_v4.spec import Formula, validate_problem


PHYSICAL_KEYS = ("name", "variables", "domain", "fields", "equations", "conditions", "branches", "parameters")
CASE_CHOICES = list_challenges()
CASE_LABELS = {item["id"]: item["label"] for item in CASE_CHOICES}
STATUS_TEXT = {
    "physics_tolerance": "采样残差达到设定值",
    "inconclusive": "当前搜索未找到可接受方向",
    "budget": "达到计算时间预算",
    "iteration_limit": "达到迭代上限",
}
ACTION_TEXT = {"gauss_newton": "线性化修正", "response_in_current_space": "高阶响应方向",
               "feature_birth": "增加函数并修正", "no_accepted_direction": "暂无可接受方向"}


def parse_problem(text):
    """Parse JSON/YAML safely and retain physical keys only."""
    if not isinstance(text, str) or not 0 < len(text) <= 64000:
        raise ValueError("请输入不超过 64,000 个字符的方程配置。")
    raw = yaml.safe_load(text)
    if not isinstance(raw, dict):
        raise ValueError("配置最外层需要是一个对象。")
    payload = {key: raw[key] for key in PHYSICAL_KEYS if key in raw}
    payload.setdefault("name", "custom_problem")
    payload.setdefault("branches", [])
    return validate_problem(payload)


def run_problem(problem, config, callback=None):
    """Keep admission and solve separate; a proven contradiction blocks fitting."""
    physical = validate_problem({key: problem[key] for key in PHYSICAL_KEYS if key in problem})
    analysis = analyze(physical)
    result = None if analysis["incompatible"] else solve(physical, config, callback)
    return {"analysis": analysis, "result": result, "problem": physical}


def model_json(result):
    """Same reloadable schema as Result.save, generated without disk writes."""
    state = {"problem": result.problem, "config": asdict(result.config),
             "features": result.bank.features, "coefficients": result.coefficients.tolist(),
             "history": result.history, "status": result.status, "seconds": result.seconds,
             "diagnostics": result.diagnostics, "training_uses_reference": False,
             "claim": "experimental_response_order_aware_direction_birth_not_proven_original_or_universal"}
    return json.dumps(state, ensure_ascii=False, indent=2, allow_nan=False)


def csv_bytes(frame):
    return frame.to_csv(index=False).encode("utf-8-sig")


def prediction_frame(result, points, derivatives=(), sign=1.):
    values = result.predict(np.asarray(points, dtype=float), derivatives)
    frame = pd.DataFrame(np.asarray(points, dtype=float), columns=result.problem["variables"])
    for name, value in values.items():
        frame[name] = sign * np.asarray(value)
    return frame


def slice_points(problem, horizontal, vertical=None, fixed=None, resolution=60):
    """A line or rectangular slice in physical coordinates, including 3/4-D."""
    variables = problem["variables"]
    if horizontal not in variables or vertical is not None and vertical not in variables:
        raise ValueError("绘图坐标不在求解域中。")
    if horizontal == vertical:
        raise ValueError("两个绘图坐标需要不同。")
    if not 2 <= int(resolution) <= 200:
        raise ValueError("绘图分辨率应为 2 至 200。")
    fixed = fixed or {}
    axes = {variable: np.linspace(*problem["domain"][variable], int(resolution))
            for variable in (horizontal, vertical) if variable is not None}
    if vertical is None:
        x, y = axes[horizontal], None
        points = np.empty((len(x), len(variables)))
    else:
        x, y = np.meshgrid(axes[horizontal], axes[vertical], indexing="xy")
        points = np.empty((x.size, len(variables)))
    for index, variable in enumerate(variables):
        if variable == horizontal: points[:, index] = x.ravel()
        elif variable == vertical: points[:, index] = y.ravel()
        else:
            lower, upper = problem["domain"][variable]
            value = float(fixed.get(variable, (lower + upper) / 2))
            if not lower <= value <= upper:
                raise ValueError("切片固定坐标超出求解域。")
            points[:, index] = value
    return points, x, y


def _show_analysis(analysis):
    if analysis["incompatible"]:
        st.error("已证明输入条件不相容：在证书所列假设下不存在满足全部条件的经典解，本次不进行数值拟合。")
        for certificate in analysis["certificates"]:
            names = {"neumann_integral_incompatibility": "通量与总源项矛盾",
                     "first_order_integral_incompatibility": "端点值与导数积分矛盾",
                     "fredholm_incompatibility": "共振源项不满足正交条件"}
            st.write(f"**{names.get(certificate['type'], '必要条件矛盾')}**")
            st.write(f"必要条件要求该量为 0，精确计算为 `{certificate['violation']}`。")
    elif not analysis["certificates"]:
        st.info("当前检查未证明条件矛盾。它只覆盖部分可精确分析的一维问题，并不证明任意输入存在唯一解。")
    for warning in analysis["stability_warnings"]:
        if warning["type"] == "near_dirichlet_resonance":
            st.warning("接近共振：即使残差很小，也可能混入误差很大的近零模态。当前没有可靠的解误差上界。")
        else:
            st.warning("存在精确共振模态；当前未证明相容性或唯一性，需要进一步数学检查。")
    for symmetry in analysis["symmetries"]:
        if symmetry["type"] == "constant_shift":
            st.warning(f"常数平移对称：若存在解，{symmetry['field']} 加任意常数仍满足输入条件。需要附加物理锚定才能选定单个解。")
        elif symmetry["type"] == "sign_reflection":
            st.info("正负反射对称：若存在非零解，将所有未知函数同时取负还能得到另一支。对称性本身不证明解存在。")
    with st.expander("查看精确检查依据与适用假设"):
        st.json(analysis)
        st.download_button("下载检查依据", json.dumps(analysis, ensure_ascii=False, indent=2),
                           file_name="analysis.json", mime="application/json", key="download_analysis")


def _input_panel():
    st.subheader("1 · 输入方程与条件")
    mode = st.radio("选择输入方式", ["研究挑战", "自定义 JSON / YAML"], horizontal=True, key="input_mode")
    if mode == "研究挑战":
        case_id = st.selectbox("研究案例", list(CASE_LABELS), format_func=lambda item: CASE_LABELS[item],
                               index=list(CASE_LABELS).index("monge_original"), key="case_id")
        problem = make_problem(case_id)
        st.caption("研究案例也只把方程、求解域、边界／初始条件与显式分支交给求解器。")
        with st.expander("查看当前物理输入"):
            st.json(problem)
        return problem
    st.caption("最多 4 个坐标、4 个未知函数，导数最高 6 阶；例如 u_xx、u_xxxxxx、v_xt。请输入残差表达式，使其等于 0。")
    text = st.text_area("方程配置", value=json.dumps(make_problem("monge_original"), ensure_ascii=False, indent=2),
                        height=340, key="custom_input")
    st.caption("支持 sin、cos、exp、tanh、sqrt、log、abs 与常数 pi、e。reference 等评价字段会被移除；不执行 Python 代码。")
    try:
        problem = parse_problem(text)
        st.success("配置格式与表达式检查通过。")
        return problem
    except (ValueError, TypeError, KeyError, SyntaxError, yaml.YAMLError) as exc:
        st.error(f"配置需要修改：{exc}")
        return None


def _settings():
    with st.sidebar:
        st.header("求解设置")
        budget = st.number_input("计算预算（秒）", min_value=1, max_value=20, value=20, key="budget_seconds")
        iterations = st.number_input("最多迭代次数", min_value=1, max_value=60, value=20, key="iterations")
        tolerance = st.selectbox("采样残差目标", [1e-4, 1e-6, 1e-8], index=1,
                                 format_func=lambda value: f"{value:.0e}", key="tolerance")
        with st.expander("研究设置"):
            interior = st.select_slider("内部训练点", [32, 64, 128, 256, 512], value=128, key="interior")
            guard = st.select_slider("独立接纳点", [32, 64, 128, 256, 512, 1024], value=256, key="guard")
            order = st.select_slider("方向响应阶数", [2, 4, 6], value=6, key="response_order")
            degree = st.slider("初始多项式阶数", 0, 6, 2, key="poly_degree")
            neural = st.slider("初始神经频率数", 0, 4, 1, key="neural_frequencies")
            birth = st.checkbox("允许增加函数", value=True, key="allow_birth")
            response = st.checkbox("启用高阶响应搜索", value=True, key="response_search")
            seed = st.number_input("随机种子", min_value=0, max_value=2147483647, value=42, key="seed")
        st.caption("时间预算在计算步骤之间检查；单步计算可能使总时长略超预算。")
        st.caption("这是实验性求解方法。有限的函数、采样与搜索预算不保证任意偏微分方程都能求解。")
    return SolverConfig(budget_seconds=float(budget), iterations=int(iterations), tolerance=tolerance,
                        interior=interior, guard=guard, response_order=order, poly_degree=degree,
                        neural_frequencies=neural, allow_birth=birth, response_search=response,
                        candidate_limit=64, max_frequency=48, seed=int(seed))


def _run_controls(problem, config):
    left, right = st.columns(2)
    check = left.button("检查输入条件", disabled=problem is None, width="stretch", key="check_input")
    run = right.button("开始数值求解", disabled=problem is None, type="primary", width="stretch", key="run_solver")
    if check:
        try:
            st.session_state["v4_check"] = analyze(problem)
        except Exception as exc:
            st.error(f"数学检查未完成：{type(exc).__name__}: {exc}")
    if run:
        status = st.empty()
        def callback(record):
            status.caption(f"已完成第 {record['step'] + 1} 次修正 · 独立点分数 {record.get('guard_after', record.get('guard', 0)):.3e}")
        try:
            with st.spinner("正在检查并计算…"):
                bundle = run_problem(problem, config, callback)
            st.session_state["v4_bundle"] = bundle
            st.session_state.pop("v4_check", None)
            st.session_state.pop("v4_point_table", None)
            st.session_state.pop("v4_bulk_table", None)
            status.empty()
        except Exception as exc:
            status.empty()
            st.error(f"本次计算未完成：{type(exc).__name__}: {exc}。这不代表方程无解。")


def _result_header(bundle):
    result = bundle["result"]
    st.subheader("2 · 求解前检查")
    _show_analysis(bundle["analysis"])
    if result is None:
        return
    st.subheader("3 · 数值结果")
    st.caption(f"当前展示的是已计算输入：{result.problem['name']}。修改输入后需再次点击“开始数值求解”。")
    columns = st.columns(4)
    columns[0].metric("计算状态", STATUS_TEXT.get(result.status, result.status))
    columns[1].metric("独立点分数", f"{result.diagnostics['guard_score']:.3e}")
    columns[2].metric("函数数量", str(result.bank.size))
    columns[3].metric("求解耗时", f"{result.seconds:.2f} 秒")
    if result.status == "physics_tolerance":
        st.success("采样残差达到设定值。可以查看、查询和导出当前数值候选。")
    else:
        st.warning("本次尚未达到采样残差目标，下面展示当前候选；请勿将其视为已验证的方程解。搜索停滞或时间用尽都不等于证明无解。")
    st.warning("“采样残差达到设定值”（physics_tolerance）只说明有限采样点上的归一化物理残差与分支检查达标；它不是逐点解误差、存在性或唯一性证明。边界消元也只针对所用函数与采样条件。")
    st.caption("参考解不参与训练；本界面没有用私有精确解评价来挑选模型。")


def _branch_choice(result, analysis):
    sign_symmetry = any(item["type"] == "sign_reflection" for item in analysis["symmetries"])
    if not sign_symmetry:
        return 1.
    probe = np.array([[np.mean(result.problem["domain"][variable]) for variable in result.problem["variables"]]])
    # Coefficients can be nonzero while the midpoint lies at a nodal zero.
    # A second deterministic slice provides an explicit nonzero witness.
    lower = np.array([result.problem["domain"][variable][0] for variable in result.problem["variables"]])
    width = np.array([np.ptp(result.problem["domain"][variable]) for variable in result.problem["variables"]])
    probe = np.vstack([probe, lower + np.linspace(.07, .93, 23)[:, None] * width])
    values = result.predict(probe)
    nonzero = max(float(np.max(np.abs(value))) for value in values.values()) > 1e-10
    if not nonzero:
        st.caption("当前候选未展示非零见证，暂不将正负反射列为两个不同候选。")
        return 1.
    st.info("方程与条件具有精确正负反射对称，当前数值候选非零。下面可查看候选及其反射；二者是数值分支，不构成存在性证明。")
    return 1. if st.radio("查看数值分支", ["当前候选", "正负反射候选"], horizontal=True, key="branch_view") == "当前候选" else -1.


def _plot_panel(result, sign):
    problem = result.problem
    variables = problem["variables"]
    st.write("**解曲线与曲面**")
    field = st.selectbox("显示的未知函数", problem["fields"], key="display_field")
    kind = st.radio("图形", ["曲线"] if len(variables) == 1 else ["曲面", "热力图", "曲线"],
                    horizontal=True, key="plot_kind")
    horizontal = st.selectbox("横坐标", variables, key="horizontal_axis")
    vertical = None
    if kind != "曲线":
        vertical = st.selectbox("第二坐标", [name for name in variables if name != horizontal], key="vertical_axis")
    fixed = {}
    for variable in variables:
        if variable not in (horizontal, vertical):
            low, high = map(float, problem["domain"][variable])
            fixed[variable] = st.number_input(f"固定 {variable}", min_value=low, max_value=high,
                                               value=(low + high) / 2, format="%.8f", key=f"fixed_{variable}")
    resolution = st.slider("每个绘图坐标的点数", 20, 100, 60, key="plot_resolution")
    points, x, y = slice_points(problem, horizontal, vertical, fixed, resolution)
    frame = prediction_frame(result, points, sign=sign)
    values = frame[field].to_numpy()
    figure = go.Figure()
    if vertical is None:
        figure.add_trace(go.Scatter(x=x, y=values, mode="lines", name=field))
        figure.update_layout(xaxis_title=horizontal, yaxis_title=field)
    elif kind == "热力图":
        figure.add_trace(go.Heatmap(x=x[0], y=y[:, 0], z=values.reshape(x.shape),
                                   colorbar={"title": field}, colorscale="Viridis"))
        figure.update_layout(xaxis_title=horizontal, yaxis_title=vertical)
    else:
        figure.add_trace(go.Surface(x=x, y=y, z=values.reshape(x.shape), colorscale="Viridis", colorbar={"title": field}))
        figure.update_layout(scene={"xaxis_title": horizontal, "yaxis_title": vertical, "zaxis_title": field})
    figure.update_layout(height=520, margin={"l": 10, "r": 10, "t": 25, "b": 10})
    st.plotly_chart(figure, width="stretch", key="solution_plot")
    if len(variables) > 2:
        st.caption("这是高维结果在固定其余坐标后的切片。")
    st.download_button("下载当前图形的全部场数值 CSV", csv_bytes(frame), file_name="solution_slice.csv",
                       mime="text/csv", key="download_slice")


def _query_panel(result, sign):
    st.write("**逐点查询**")
    variables, fields = result.problem["variables"], result.problem["fields"]
    columns = st.columns(len(variables))
    point = []
    for column, variable in zip(columns, variables):
        low, high = map(float, result.problem["domain"][variable])
        point.append(column.number_input(f"查询坐标 {variable}", min_value=low, max_value=high,
                                        value=(low + high) / 2, format="%.10f", key=f"query_{variable}"))
    derivative_text = st.text_input("附加导数（选填，以逗号分隔，例如 u_x,u_xx）", key="query_derivatives")
    derivatives = tuple(dict.fromkeys(name.strip() for name in derivative_text.replace("，", ",").split(",") if name.strip()))
    if st.button("查询此点", key="query_point"):
        try:
            for name in derivatives:
                expression = Formula(name, variables, fields)
                if expression.jets != {name}:
                    raise ValueError("附加查询只接受未知函数或它的导数。")
            frame = prediction_frame(result, [point], derivatives, sign)
            st.session_state["v4_point_table"] = frame
        except Exception as exc:
            st.error(f"查询未完成：{exc}")
    if "v4_point_table" in st.session_state:
        frame = st.session_state["v4_point_table"]
        st.dataframe(frame, hide_index=True, width="stretch")
        st.caption("表格保留了点击查询时的坐标和分支；切换分支后请重新查询。")
        st.download_button("下载查询数值 CSV", csv_bytes(frame), file_name="point_values.csv", mime="text/csv", key="download_point")
    with st.expander("批量坐标查询"):
        st.caption(f"上传 CSV，坐标列必须为：{', '.join(variables)}。最多 20,000 行。")
        upload = st.file_uploader("坐标 CSV", type=["csv"], key="coordinate_csv")
        if st.button("计算批量坐标", disabled=upload is None, key="query_bulk"):
            try:
                if upload.size > 4_000_000:
                    raise ValueError("坐标文件应小于 4 MB。")
                coordinates = pd.read_csv(io.BytesIO(upload.getvalue()), nrows=20001)
                if not 1 <= len(coordinates) <= 20000 or not set(variables).issubset(coordinates.columns):
                    raise ValueError("坐标列不完整，或行数不在 1 至 20,000 之间。")
                frame = prediction_frame(result, coordinates[variables].to_numpy(dtype=float), sign=sign)
                st.session_state["v4_bulk_table"] = frame
            except Exception as exc:
                st.error(f"批量查询未完成：{exc}")
        if "v4_bulk_table" in st.session_state:
            frame = st.session_state["v4_bulk_table"]
            st.dataframe(frame.head(200), hide_index=True, width="stretch")
            st.download_button("下载全部批量数值 CSV", csv_bytes(frame), file_name="batch_values.csv", mime="text/csv", key="download_bulk")


def _history_panel(result):
    st.write("**求解过程与文件**")
    if result.history:
        history = pd.DataFrame(result.history)
        guard_column = "guard_before" if "guard_before" in history else "guard"
        figure = go.Figure(go.Scatter(x=history["step"], y=history[guard_column], mode="lines+markers"))
        figure.update_layout(xaxis_title="修正次数（从 0 开始）", yaxis_title="修正前独立点分数", height=300)
        if bool((history[guard_column] > 0).all()):
            figure.update_yaxes(type="log")
        st.plotly_chart(figure, width="stretch", key="history_plot")
        display = history.copy()
        display["action"] = display["action"].map(lambda action: ACTION_TEXT.get(action, action))
        st.dataframe(display, hide_index=True, width="stretch")
        st.download_button("下载完整求解记录", json.dumps(result.history, ensure_ascii=False, indent=2),
                           file_name="history.json", mime="application/json", key="download_history")
    else:
        st.caption("当前初始候选已经达标，或在进入迭代前预算用尽，因此没有修正记录。")
    left, right = st.columns(2)
    left.download_button("下载模型 model.json", model_json(result), file_name="model.json",
                         mime="application/json", width="stretch", key="download_model")
    right.download_button("下载物理输入", json.dumps(result.problem, ensure_ascii=False, indent=2),
                          file_name="problem.json", mime="application/json", width="stretch", key="download_problem")
    with st.expander("查看求解统计与局限"):
        st.json(result.diagnostics)
        st.write("六阶是当前表达式与函数导数接口的上限，不代表任意六阶方程都能有效求解。四维结果只能用切片查看。")
        st.write("显式分支来自输入，求解器不会自动保证所有非线性方程分支都被找到；当前方向搜索也可能被更远的能量障碍阻挡。")


def main():
    st.set_page_config(page_title="PINNLab V4 · 高阶响应研究", page_icon="∂", layout="wide")
    st.title("PINNLab V4 · 高阶响应求解研究")
    st.write("输入方程与物理条件，计算连续数值候选，并查看逐点数值、曲线或曲面。")
    st.caption("研究范围：高阶退化下的方向搜索与函数扩充；这是可复核的实验平台，不承诺任意偏微分方程的自动高精度解。")
    config = _settings()
    problem = _input_panel()
    _run_controls(problem, config)
    if "v4_check" in st.session_state:
        st.subheader("本次输入检查")
        _show_analysis(st.session_state["v4_check"])
    bundle = st.session_state.get("v4_bundle")
    if bundle is None:
        st.info("先检查输入条件，或直接开始数值求解。默认案例保留了旧方法曾失败的 Monge–Ampere 问题。")
        return
    # An explicit check and a stored run can coexist, so avoid duplicate
    # download keys while still showing the completed run's own analysis.
    if "v4_check" not in st.session_state:
        _result_header(bundle)
    else:
        st.caption("以下图形属于最近一次已完成的计算。")
    result = bundle["result"]
    if result is None:
        return
    sign = _branch_choice(result, bundle["analysis"])
    tabs = st.tabs(["曲线 / 曲面", "逐点 / 批量数值", "求解记录 / 下载"])
    with tabs[0]: _plot_panel(result, sign)
    with tabs[1]: _query_panel(result, sign)
    with tabs[2]: _history_panel(result)


if __name__ == "__main__":
    main()
