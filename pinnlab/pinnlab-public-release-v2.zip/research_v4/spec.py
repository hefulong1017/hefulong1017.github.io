"""Restricted multi-field, high-order PDE expressions, without Python eval."""
from __future__ import annotations
import ast
import math
import re
import numpy as np
import torch
from .series import Series

FUNCTIONS = ('sin','cos','exp','tanh','sqrt','log','abs')


class Formula:
    def __init__(self, text, variables, fields, parameters=None, allow_fields=True):
        if not isinstance(text,str) or not 0<len(text)<=4000:
            raise ValueError('Expression must contain 1..4000 characters.')
        self.text,self.variables,self.fields=text,list(variables),list(fields)
        self.parameters=parameters or {}
        self.tree=ast.parse(text,mode='eval').body
        if len(list(ast.walk(self.tree)))>400:
            raise ValueError('Expression exceeds node budget.')
        self.jets=set()
        def validate(node):
            if isinstance(node,ast.Constant):
                if type(node.value) not in (int,float) or not math.isfinite(node.value): raise ValueError('Invalid constant.')
            elif isinstance(node,ast.Name):
                n=node.id
                if n in self.variables or n in self.parameters or n in ('pi','e'): return
                head,_,tail=n.partition('_')
                if allow_fields and head in self.fields and ('_' not in n or 1<=len(tail)<=6 and all(a in self.variables for a in tail)):
                    self.jets.add(n); return
                raise ValueError('Unknown symbol: '+n)
            elif isinstance(node,ast.UnaryOp) and isinstance(node.op,(ast.UAdd,ast.USub)): validate(node.operand)
            elif isinstance(node,ast.BinOp) and isinstance(node.op,(ast.Add,ast.Sub,ast.Mult,ast.Div,ast.Pow)):
                validate(node.left); validate(node.right)
                if isinstance(node.op,ast.Pow):
                    e=node.right
                    if isinstance(e,ast.UnaryOp): e=e.operand
                    if not isinstance(e,ast.Constant) or abs(e.value)>16: raise ValueError('Power must be constant and within 16.')
            elif isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id in FUNCTIONS and len(node.args)==1 and not node.keywords:
                validate(node.args[0])
            else: raise ValueError('Unsupported expression syntax.')
        validate(self.tree)

    def __call__(self, points, jets):
        def visit(node):
            if isinstance(node,ast.Constant): return node.value
            if isinstance(node,ast.Name):
                if node.id in self.variables: return points[:,self.variables.index(node.id)]
                if node.id in self.parameters: return self.parameters[node.id]
                if node.id in ('pi','e'): return getattr(math,node.id)
                return jets[node.id]
            if isinstance(node,ast.UnaryOp): return -visit(node.operand) if isinstance(node.op,ast.USub) else visit(node.operand)
            if isinstance(node,ast.Call):
                x=visit(node.args[0]); name=node.func.id
                if isinstance(x,Series): return getattr(x,name)()
                if isinstance(x,torch.Tensor): return getattr(torch,name)(x)
                return getattr(np,name)(x)
            a,b=visit(node.left),visit(node.right)
            if isinstance(node.op,ast.Add): return a+b
            if isinstance(node.op,ast.Sub): return a-b
            if isinstance(node.op,ast.Mult): return a*b
            if isinstance(node.op,ast.Div): return a/b
            return a**b
        return visit(self.tree)

    def affine(self):
        def degree(n):
            if isinstance(n,ast.Constant): return 0
            if isinstance(n,ast.Name): return int(n.id in self.jets)
            if isinstance(n,ast.UnaryOp): return degree(n.operand)
            if isinstance(n,ast.Call): return 0 if degree(n.args[0])==0 else 2
            a,b=degree(n.left),degree(n.right)
            if isinstance(n.op,(ast.Add,ast.Sub)): return max(a,b)
            if isinstance(n.op,ast.Mult): return min(2,a+b)
            if isinstance(n.op,ast.Div): return a if b==0 else 2
            if a==0 and b==0: return 0
            if isinstance(n.right,ast.Constant) and n.right.value in (0,1): return a*int(n.right.value)
            return 2
        return degree(self.tree)<=1


def validate_problem(problem):
    p=dict(problem)
    required=('name','variables','domain','fields','equations','conditions')
    if any(key not in p for key in required): raise ValueError('Incomplete PDE problem.')
    if not 1<=len(p['variables'])<=4 or len(set(p['variables']))!=len(p['variables']) or any(v not in 'xyzt' or len(v)!=1 for v in p['variables']): raise ValueError('Use 1..4 distinct x/y/z/t coordinates.')
    if not 1<=len(p['fields'])<=4 or len(set(p['fields']))!=len(p['fields']) or any(not re.fullmatch('[a-zA-Z][a-zA-Z0-9]*',f) or f in p['variables'] or f in FUNCTIONS or f in ('pi','e') for f in p['fields']): raise ValueError('Use 1..4 distinct field names.')
    reserved=set(p['variables'])|set(p['fields'])|set(FUNCTIONS)|{'pi','e'}
    for name,value in p.get('parameters',{}).items():
        if not re.fullmatch('[a-zA-Z][a-zA-Z0-9]*',name) or name in reserved or type(value) not in (int,float) or not np.isfinite(value): raise ValueError('Invalid or colliding parameter.')
    for v in p['variables']:
        a,b=p['domain'][v]
        if not np.isfinite([a,b]).all() or a>=b: raise ValueError('Invalid domain.')
    if not 1<=len(p['equations'])<=16 or not p['conditions']: raise ValueError('Provide equations and conditions.')
    for text in p['equations']: Formula(text,p['variables'],p['fields'],p.get('parameters'))
    for c in p['conditions']:
        weight=c.get('weight',1.)
        if type(weight) not in (int,float) or not math.isfinite(weight) or weight<=0:
            raise ValueError('Condition weight must be finite and strictly positive.')
        Formula(c['operator'],p['variables'],p['fields'],p.get('parameters'))
        Formula(str(c['target']),p['variables'],p['fields'],p.get('parameters'),False)
        for v,value in c['where'].items():
            if v not in p['variables'] or not p['domain'][v][0]<=value<=p['domain'][v][1]: raise ValueError('Invalid condition location.')
    for c in p.get('branches',[]):
        Formula(c['operator'],p['variables'],p['fields'],p.get('parameters'))
        if ('min' in c)==('max' in c): raise ValueError('A branch inequality needs exactly one of min/max.')
        bound=c['min'] if 'min' in c else c['max']
        if type(bound) not in (int,float) or not math.isfinite(bound):
            raise ValueError('Branch bound must be a finite real number.')
    # Evaluation metadata is never kept inside the fitting specification.
    p.pop('reference',None)
    return p
