"""Conservative, exact admission checks derived only from physical inputs.

This module never fits a model or reads a problem name, reference, outcome label
or optimizer state. Unsupported cases are left unknown. A nonempty symmetry
list is conditional on existence, not an existence or uniqueness theorem.

Certificates use exact SymPy arithmetic built from the already restricted
``Formula`` AST. No user string is passed to ``eval`` or ``sympify``.
"""
from __future__ import annotations

import ast
import math

import sympy as sp
from sympy.calculus.util import continuous_domain

from .spec import Formula, validate_problem


def _number(value):
    if type(value) not in (int, float) or not math.isfinite(value):
        raise ValueError("Admission constants must be finite real numbers.")
    return sp.Rational(str(value))


def _symbolic(formula, symbols, tree=None):
    """Translate a validated AST without parsing an executable string."""
    functions = {"sin": sp.sin, "cos": sp.cos, "exp": sp.exp,
                 "tanh": sp.tanh, "sqrt": sp.sqrt, "log": sp.log, "abs": sp.Abs}
    def visit(node):
        if isinstance(node, ast.Constant):
            return _number(node.value)
        if isinstance(node, ast.Name):
            if node.id in formula.parameters:
                return _number(formula.parameters[node.id])
            if node.id == "pi":
                return sp.pi
            if node.id == "e":
                return sp.E
            return symbols[node.id]
        if isinstance(node, ast.UnaryOp):
            value = visit(node.operand)
            return -value if isinstance(node.op, ast.USub) else value
        if isinstance(node, ast.Call):
            return functions[node.func.id](visit(node.args[0]))
        left, right = visit(node.left), visit(node.right)
        if isinstance(node.op, ast.Add): return left + right
        if isinstance(node.op, ast.Sub): return left - right
        if isinstance(node.op, ast.Mult): return left * right
        if isinstance(node.op, ast.Div): return left / right
        if isinstance(node.op, ast.Pow): return left ** right
        raise ValueError("Unsupported symbolic AST.")
    return visit(formula.tree if tree is None else tree)


def _domain_guards(formula, symbols):
    """Keep original AST domains even when SymPy cancels a rational factor."""
    result = []
    for node in ast.walk(formula.tree):
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Div):
            result.append(("nonzero", _symbolic(formula, symbols, node.right)))
        elif isinstance(node, ast.BinOp) and isinstance(node.op, ast.Pow):
            exponent = _symbolic(formula, symbols, node.right)
            if exponent.is_integer is True and exponent.is_nonnegative is True:
                continue
            kind = "nonzero" if exponent.is_integer is True else "same_domain_argument"
            result.append((kind, _symbolic(formula, symbols, node.left)))
        elif isinstance(node, ast.Call) and node.func.id in ("sqrt", "log"):
            result.append(("same_domain_argument", _symbolic(formula, symbols, node.args[0])))
    return result


def _preserves_domain(guards, substitutions):
    for kind, argument in guards:
        reflected = argument.xreplace(substitutions)
        if _zero(reflected - argument):
            continue
        if kind == "nonzero" and _zero(reflected + argument):
            continue
        return False
    return True


def _simplify(expression):
    return sp.simplify(expression)


def _zero(expression):
    return _simplify(expression) == 0


def _nonzero(expression):
    value = _simplify(expression)
    return not value.has(sp.Integral, sp.nan, sp.zoo, sp.oo, -sp.oo) and value.is_zero is False


def _s(expression):
    return sp.sstr(_simplify(expression))


def _physical(problem):
    # Deliberately whitelist physical keys; in particular do not even fetch a
    # problem's name or any evaluation metadata.
    payload = {key: problem[key] for key in
               ("variables", "domain", "fields", "equations", "conditions")}
    payload["name"] = "physical_admission_input"
    for key in ("parameters", "branches"):
        if key in problem:
            payload[key] = problem[key]
    return validate_problem(payload)


def _parsed(problem):
    variables, fields = problem["variables"], problem["fields"]
    parameters = problem.get("parameters")
    def formula(text, allow_fields=True):
        return Formula(str(text), variables, fields, parameters, allow_fields)
    equations = [formula(text) for text in problem["equations"]]
    conditions = [(condition, formula(condition["operator"]),
                   formula(condition["target"], False)) for condition in problem["conditions"]]
    branches = [(branch, formula(branch["operator"]),
                 formula(branch["min"] if "min" in branch else branch["max"], False))
                for branch in problem.get("branches", [])]
    names = set(variables) | set(fields)
    for expression in equations + [part for _, op, target in conditions + branches for part in (op, target)]:
        names.update(expression.jets)
    symbols = {name: sp.Symbol(name, real=True) for name in names}
    def convert(expression):
        return _symbolic(expression, symbols)
    eqs = [convert(expression) for expression in equations]
    guards = [guard for expression in equations for guard in _domain_guards(expression, symbols)]
    conds = []
    for condition, operator, target in conditions:
        location = {symbols[name]: _number(value) for name, value in condition["where"].items()}
        conds.append((condition, convert(operator).subs(location), convert(target).subs(location)))
        guards.extend((kind, argument.subs(location)) for expression in (operator, target)
                      for kind, argument in _domain_guards(expression, symbols))
    branch_exprs = [convert(operator) - convert(target) for _, operator, target in branches]
    guards.extend(guard for _, operator, target in branches for expression in (operator, target)
                  for guard in _domain_guards(expression, symbols))
    return symbols, eqs, conds, branch_exprs, guards


def _symmetries(problem, symbols, equations, conditions, branches, guards):
    result = []
    equalities = equations + [operator - target for _, operator, target in conditions]
    all_expressions = equalities + branches
    shift = sp.Symbol("C_admission", real=True)
    for field in problem["fields"]:
        symbol = symbols[field]
        identities = [expression.subs(symbol, symbol + shift) - expression for expression in all_expressions]
        if all(_zero(identity) for identity in identities) and _preserves_domain(guards, {symbol: symbol + shift}):
            result.append({"type": "constant_shift", "field": field,
                "transformation": f"{field} -> {field} + C for any real constant C",
                "conditional_on_existence": True, "proves_existence": False,
                "statement": "If a solution exists, adding any real constant to this field preserves every supplied equality and branch inequality.",
                "proof": {"method": "exact symbolic translation identity", "differences": [_s(v) for v in identities],
                          "original_ast_domain_preserved": True, "domain_guard_count": len(guards)},
                "assumptions": "Classical derivatives; exactly the supplied physical problem."})
    # This sufficient test proves zero-set invariance by F(-jet)=+/-F(jet).
    # It deliberately does not guess equivalence from random probe points.
    if not branches and all(_zero(target) for _, _, target in conditions):
        substitutions = {symbol: -symbol for name, symbol in symbols.items()
                         if any(name == field or name.startswith(field + "_") for field in problem["fields"])}
        multipliers = []
        for expression in equalities:
            reflected = expression.xreplace(substitutions)
            if _zero(reflected - expression): multipliers.append(1)
            elif _zero(reflected + expression): multipliers.append(-1)
            else: break
        if len(multipliers) == len(equalities) and _preserves_domain(guards, substitutions):
            result.append({"type": "sign_reflection", "fields": list(problem["fields"]),
                "transformation": {field: "-" + field for field in problem["fields"]},
                "conditional_on_existence": True, "proves_existence": False,
                "proves_distinctness": False, "requires_nonzero_solution_for_distinct_partner": True,
                "statement": "If a solution exists, its simultaneous sign reflection is also a solution; the two are distinct only when at least one field is nonzero.",
                "proof": {"method": "exact residual parity identities", "residual_multipliers": multipliers,
                          "differences": [_s(expression.xreplace(substitutions) - multiplier * expression)
                                          for expression, multiplier in zip(equalities, multipliers)],
                          "original_ast_domain_preserved": True, "domain_guard_count": len(guards)},
                "assumptions": "No branch inequalities, zero supplied condition targets, and classical derivatives."})
    return result


def _linear(expression, symbols, coordinate, field):
    x, u = symbols[coordinate], symbols[field]
    ux, uxx = symbols.get(field + "_" + coordinate), symbols.get(field + "_" + coordinate * 2)
    ux = ux if ux is not None else sp.Symbol(field + "_" + coordinate, real=True)
    uxx = uxx if uxx is not None else sp.Symbol(field + "_" + coordinate * 2, real=True)
    jets = (uxx, ux, u)
    coefficients = [_simplify(sp.diff(expression, jet)) for jet in jets]
    if any(coefficient.free_symbols for coefficient in coefficients):
        return None
    f = _simplify(expression.subs(dict.fromkeys(jets, 0)))
    if f.free_symbols - {x}:
        return None
    if not _zero(expression - sum(coefficient * jet for coefficient, jet in zip(coefficients, jets)) - f):
        return None
    return (*coefficients, f, ux, uxx)


def _endpoint_values(problem, conditions, symbols, coordinate, field, order):
    x = symbols[coordinate]
    jet = symbols.get(field + "_" + coordinate * order) if order else symbols[field]
    if jet is None:
        return {}
    values = {}
    endpoints = tuple(_number(value) for value in problem["domain"][coordinate])
    for condition, operator, target in conditions:
        if coordinate not in condition["where"]:
            continue
        location = _number(condition["where"][coordinate])
        if location not in endpoints:
            continue
        expression = _simplify(operator - target)
        coefficient = _simplify(sp.diff(expression, jet))
        constant = _simplify(expression.subs(jet, 0))
        if coefficient.free_symbols or constant.free_symbols or not _nonzero(coefficient):
            continue
        if _zero(expression - coefficient * jet - constant):
            values[location] = _simplify(-constant / coefficient)
    return values


def _integral(expression, x, left, right):
    """Exact proper integral only; no sampled or principal-value certificate."""
    try:
        interval = sp.Interval(left, right)
        if continuous_domain(expression, x, interval) != interval:
            return None
        value = _simplify(sp.integrate(expression, (x, left, right)))
        if value.has(sp.Integral, sp.nan, sp.zoo, sp.oo, -sp.oo) or value.free_symbols:
            return None
        return value
    except (NotImplementedError, ValueError, TypeError):
        return None


def _certificate(kind, equation_index, x, interval, coefficients, forcing, identity, violation, **extra):
    a, b, c = coefficients
    return {"type": kind, "equation_index": equation_index,
            "coordinate": str(x), "interval": [_s(v) for v in interval],
            "operator": {"a": _s(a), "b": _s(b), "c": _s(c), "f": _s(forcing)},
            "exact_identity": identity, "required_value": "0", "violation": _s(violation),
            "symbolic_verified": True,
            "assumptions": "A classical solution on the closed interval with the supplied endpoint conditions. The forcing and any integration weight used here are continuous on that interval.",
            **extra}


def _linear_admission(problem, symbols, equations, conditions):
    certificates, warnings = [], []
    if len(problem["variables"]) != 1 or len(problem["fields"]) != 1:
        return certificates, warnings
    coordinate, field = problem["variables"][0], problem["fields"][0]
    x = symbols[coordinate]
    left, right = (_number(value) for value in problem["domain"][coordinate])
    length = right - left
    endpoints = (left, right)
    values = _endpoint_values(problem, conditions, symbols, coordinate, field, 0)
    slopes = _endpoint_values(problem, conditions, symbols, coordinate, field, 1)
    for index, expression in enumerate(equations):
        linear = _linear(expression, symbols, coordinate, field)
        if linear is None:
            continue
        a, b, c, forcing, _, _ = linear
        coeffs = (a, b, c)
        if _nonzero(a) and _zero(c) and all(point in slopes for point in endpoints):
            weight = sp.exp(b / a * (x - left))
            integral = _integral(weight * forcing, x, left, right)
            if integral is not None:
                boundary = _simplify(a * (weight.subs(x, right) * slopes[right] - weight.subs(x, left) * slopes[left]))
                mismatch = _simplify(boundary + integral)
                if _nonzero(mismatch):
                    certificates.append(_certificate("neumann_integral_incompatibility", index, x, endpoints,
                        coeffs, forcing, "a*(w*u_x)|_left^right + Integral(w*f, (x,left,right)) = 0; w'=b*w/a", mismatch,
                        integration_weight=_s(weight), weight_identity=_s(a * sp.diff(weight, x) - b * weight),
                        integrand=_s(weight * forcing), compatibility_integral=_s(integral),
                        boundary_term=_s(boundary), endpoint_derivatives=[_s(slopes[point]) for point in endpoints]))
        if _zero(a) and _nonzero(b) and _zero(c) and all(point in values for point in endpoints):
            integral = _integral(forcing, x, left, right)
            if integral is not None:
                boundary = _simplify(b * (values[right] - values[left]))
                mismatch = _simplify(boundary + integral)
                if _nonzero(mismatch):
                    certificates.append(_certificate("first_order_integral_incompatibility", index, x, endpoints,
                        coeffs, forcing, "b*(u(right)-u(left)) + Integral(f, (x,left,right)) = 0", mismatch,
                        integrand=_s(forcing), compatibility_integral=_s(integral), boundary_term=_s(boundary),
                        endpoint_values=[_s(values[point]) for point in endpoints]))
        if not (_nonzero(a) and _zero(b) and all(point in values and _zero(values[point]) for point in endpoints)):
            continue
        frequency_squared = _simplify(c / a)
        if frequency_squared.is_positive is not True:
            continue
        mode = _simplify(sp.sqrt(frequency_squared) * length / sp.pi)
        if mode.is_integer is True and mode.is_positive is True:
            phi = sp.sin(mode * sp.pi * (x - left) / length)
            adjoint = _simplify(a * sp.diff(phi, x, 2) + c * phi)
            endpoints_phi = [_simplify(phi.subs(x, point)) for point in endpoints]
            integral = _integral(phi * forcing, x, left, right)
            if integral is not None and _zero(adjoint) and all(_zero(v) for v in endpoints_phi) and _nonzero(integral):
                certificates.append(_certificate("fredholm_incompatibility", index, x, endpoints,
                    coeffs, forcing, "Integral(phi*(a*u_xx+c*u+f)) = a*(phi*u_x-phi_x*u)|_left^right + Integral(u*(a*phi_xx+c*phi)) + Integral(phi*f) = Integral(phi*f)", integral,
                    mode=_s(mode), null_test_function=_s(phi), adjoint_operator_on_test=_s(adjoint),
                    test_endpoint_values=[_s(v) for v in endpoints_phi], boundary_term="0",
                    integrand=_s(phi * forcing), compatibility_integral=_s(integral)))
            else:
                warnings.append({"type": "exact_dirichlet_resonance", "equation_index": index,
                    "mode": _s(mode), "statement": "The homogeneous Dirichlet operator has an exact null mode. No incompatibility was proved by this check; existence and uniqueness remain undetermined.",
                    "proves_incompatibility": False, "proves_existence": False})
        else:
            # Numeric proximity is a warning only. It can never enter a
            # certificate or change the incompatible flag.
            try:
                mode_value = float(sp.N(mode, 16))
                nearest = round(mode_value)
                if not 1 <= nearest <= 100000:
                    continue
                detuning = _simplify(frequency_squared * length ** 2 / sp.pi ** 2 - nearest ** 2)
                relative = abs(float(sp.N(detuning / nearest ** 2, 16)))
                if 0 < relative <= 1e-4:
                    warnings.append({"type": "near_dirichlet_resonance", "equation_index": index,
                        "nearest_mode": nearest, "relative_eigenvalue_detuning": relative,
                        "exact_normalized_detuning": _s(detuning),
                        "statement": "A small residual may hide large error along the nearby Dirichlet eigenmode. This proximity warning is not a proof of incompatibility or of a solution error bound.",
                        "proves_incompatibility": False, "proves_solution_error_bound": False})
            except (TypeError, ValueError, OverflowError):
                pass
    return certificates, warnings


def analyze(problem):
    """Return exact contradictions, conditional symmetries and stability hints.

    An empty list means this limited analyzer found no applicable result, not
    that the input is feasible, well posed or uniquely solvable. Malformed or
    unsafe physical expressions raise validation errors.
    """
    physical = _physical(problem)
    symbols, equations, conditions, branches, guards = _parsed(physical)
    symmetries = _symmetries(physical, symbols, equations, conditions, branches, guards)
    certificates, warnings = _linear_admission(physical, symbols, equations, conditions)
    return {"incompatible": bool(certificates), "certificates": certificates,
            "symmetries": symmetries, "stability_warnings": warnings}
