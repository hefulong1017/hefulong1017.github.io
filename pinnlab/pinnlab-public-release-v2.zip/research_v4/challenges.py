"""V4 challenge inputs and independent outcome audits; no solver dependency.

``make_problem`` returns physical inputs only: no reference values, analytic
solution, expected outcome or private audit metadata. ``audit_candidate`` is a
separate evaluation path. The tests deliberately include nonunique and
incompatible equations, for which producing a single confident solution is
not a successful outcome. A failed optimizer is not a proof of infeasibility.

Predictor contract: predictor(points, derivatives=()) -> dict of finite arrays,
with every field value (u, v, ...) and requested jets (u_x, u_xxxx, ...).
"""
from __future__ import annotations

import ast
import copy
import math
import re

import numpy as np
from scipy.stats import qmc


def _condition(name, where, operator="u", target="0"):
    return {"name": name, "where": where, "operator": operator, "target": target}


def _problem(name, variables, domain, equations, conditions, branches=(), fields=("u",)):
    return {"name": name, "variables": variables, "domain": domain, "fields": list(fields),
            "equations": equations, "conditions": conditions, "branches": list(branches)}


_INPUTS = {}
_INFO = {}


def _register(problem, label, family, expected="unique", manufactured=False, difficulty="", notes=""):
    case_id = problem["name"]
    _INPUTS[case_id] = problem
    _INFO[case_id] = {"id": case_id, "label": label, "family": family,
                      "expected_outcome": expected, "manufactured": manufactured,
                      "difficulty": difficulty, "notes": notes}


_register(_problem("monge_original", ["x", "y"], {"x": [0., 1.], "y": [0., 1.]},
    ["u_xx*u_yy-u_xy**2-((1+0.1*y**2)*(1+0.1*x**2)-0.04*x**2*y**2)"],
    [_condition("x_lower", {"x": 0.}, target="0.5*y**2"),
     _condition("x_upper", {"x": 1.}, target="0.55*y**2+0.5"),
     _condition("y_lower", {"y": 0.}, target="0.5*x**2"),
     _condition("y_upper", {"y": 1.}, target="0.55*x**2+0.5")],
    [{"name": "convex_x", "operator": "u_xx", "min": 0.},
     {"name": "convex_y", "operator": "u_yy", "min": 0.},
     {"name": "convex_determinant", "operator": "u_xx*u_yy-u_xy**2", "min": 0.}]),
    "原 V3 失败的凸分支 Monge–Ampere", "monge_ampere", manufactured=True,
    difficulty="Zero-field Jacobian degeneracy; admissible convex branch.",
    notes="Exact original V3 operator and boundary data; explicitly a manufactured case, retained to repair a real failure rather than claim generality.")

for _suffix, _branch in (("positive", [{"name": "positive_slope", "operator": "u_x", "min": 0.}]),
                         ("negative", [{"name": "negative_slope", "operator": "u_x", "max": 0.}]),
                         ("ambiguous", [])):
    _register(_problem("eikonal_" + _suffix, ["x"], {"x": [0., 1.]}, ["u_x**2-1"],
                       [_condition("anchor", {"x": 0.})], _branch),
              "Eikonal 斜率分支：" + _suffix, "eikonal",
              expected="nonunique" if _suffix == "ambiguous" else "unique",
              difficulty="Zero-field Jacobian; positive/negative slopes share the PDE.",
              notes="These three are branch variants of ONE family, not three independent equation classes. The unbranched C1 problem admits at least u=x and u=-x.")

for _power in (2, 4):
    _register(_problem(f"degenerate_curvature_power{_power}", ["x"], {"x": [0., 1.]},
        [f"u_xx**{_power}-{2**_power}"],
        [_condition("left", {"x": 0.}), _condition("right", {"x": 1.})],
        [{"name": "convex", "operator": "u_xx", "min": 0.}]),
        f"零 Jacobian 曲率退化：u_xx 的 {_power} 次幂", "degenerate_hessian_power",
        difficulty="At zero, first residual derivatives vanish; for power4 the second and third responses also vanish.",
        notes="Both powers select the convex solution through a declared inequality. They test response order, not extra family coverage.")

_register(_problem("helmholtz_near_resonance", ["x"], {"x": [0., 1.]},
    ["-u_xx-pi**2*(1+0.000001)*u-sin(2*pi*x)"],
    [_condition("left", {"x": 0.}), _condition("right", {"x": 1.})]),
    "近共振 Helmholtz：已知非制造体源", "helmholtz",
    difficulty="Conditioning deteriorates near a Dirichlet eigenvalue; small physical residual need not imply small solution error.",
    notes="A nonresonant second-mode source has a modest exact solution, while an O(1) spurious first mode contributes only O(1e-5) residual. The reference audit must detect this near-null pollution.")

_register(_problem("helmholtz_resonance_incompatible", ["x"], {"x": [0., 1.]},
    ["-u_xx-pi**2*u-sin(pi*x)"],
    [_condition("left", {"x": 0.}), _condition("right", {"x": 1.})]),
    "真共振 Helmholtz：Fredholm 不相容", "helmholtz", expected="incompatible",
    difficulty="No H2 solution with both exact zero Dirichlet data; a residual minimizer is not a solution.",
    notes="The forcing has nonzero inner product with the null eigenfunction sin(pi*x). Incompatibility is analytic, not inferred from training failure.")

_register(_problem("heat_high_frequency", ["x", "t"], {"x": [0., 1.], "t": [0., .02]},
    ["u_t-0.02*u_xx"],
    [_condition("left", {"x": 0.}), _condition("right", {"x": 1.}),
     _condition("initial", {"t": 0.}, target="sin(17*pi*x)+0.35*sin(43*pi*x)")]),
    "无源高频热扩散与早期快衰减", "heat",
    difficulty="Native high-frequency initial data and disparate decay scales; fixed low-frequency dictionaries are insufficient.",
    notes="No manufactured body source. Modes 17 and 43 are prescribed initial data; a separate early-time audit prevents late-time decay from hiding error.")

_register(_problem("convection_boundary_layer", ["x"], {"x": [0., 1.]}, ["0.001*u_xx-u_x"],
    [_condition("left", {"x": 0.}), _condition("right", {"x": 1.}, target="1")]),
    "原生对流扩散右端薄层", "convection_diffusion",
    difficulty="A physical boundary layer of width approximately 1e-3 near x=1.",
    notes="Homogeneous PDE and nonzero boundary data, not a manufactured source. Independent predeclared near-boundary probes supplement uniform probes.")

_register(_problem("poisson_neumann_incompatible", ["x"], {"x": [0., 1.]}, ["-u_xx-1"],
    [_condition("left_flux", {"x": 0.}, "-u_x"), _condition("right_flux", {"x": 1.}, "u_x")]),
    "Poisson 零通量与非零总源不相容", "poisson", expected="incompatible",
    difficulty="Global flux/source compatibility cannot be fixed by more neurons or points.")

_register(_problem("poisson_neumann_ambiguous", ["x"], {"x": [0., 1.]}, ["-u_xx"],
    [_condition("left_flux", {"x": 0.}, "-u_x"), _condition("right_flux", {"x": 1.}, "u_x")]),
    "纯 Neumann 的常数不唯一性", "poisson", expected="nonunique",
    difficulty="A constant null space remains without a value or mean anchor.",
    notes="Do not silently add a mean-zero condition and call it part of the original problem.")

_register(_problem("transport_overconstrained", ["x"], {"x": [0., 1.]}, ["u_x-1"],
    [_condition("left", {"x": 0.}), _condition("right", {"x": 1.})]),
    "一阶输运的矛盾双端值", "transport", expected="incompatible",
    difficulty="The integral of u_x must equal the endpoint difference, inconsistent with the supplied derivative.")

_register(_problem("beam_fourth_order", ["x"], {"x": [0., 1.]}, ["u_xxxx-24"],
    [_condition("left_value", {"x": 0.}), _condition("left_slope", {"x": 0.}, "u_x"),
     _condition("right_value", {"x": 1.}), _condition("right_slope", {"x": 1.}, "u_x")]),
    "常载荷两端固支四阶梁", "biharmonic_beam",
    difficulty="Fourth derivatives and four independent value/slope constraints.",
    notes="A classical constant-load closed-form consistency test. Its polynomial solution is not evidence of difficult arbitrary high-order generalization.")

_register(_problem("sixth_order_clamped", ["x"], {"x": [0., 1.]}, ["u_xxxxxx+720"],
    [_condition(f"{side}_{order}", {"x": value}, operator)
     for side, value in (("left", 0.), ("right", 1.))
     for order, operator in (("value", "u"), ("slope", "u_x"), ("curvature", "u_xx"))]),
    "六阶常载荷与六个端点条件", "sixth_order_boundary_problem",
    difficulty="Sixth-order jet consistency and preservation of all endpoint constraints.",
    notes="Interface/order test with an analytic polynomial solution, not a claim of broadly difficult PDE performance.")

_register(_problem("coupled_oscillator", ["x"], {"x": [0., 2*math.pi]}, ["u_x-v", "v_x+u"],
    [_condition("u_initial", {"x": 0.}, "u"), _condition("v_initial", {"x": 0.}, "v", "1")],
    fields=("u", "v")), "两场耦合一阶振子系统", "coupled_oscillator",
    difficulty="Two unknowns and two coupled residual blocks with independent initial values.",
    notes="This is an ODE system in one coordinate. It verifies a coupled-system interface and must not be counted as an additional difficult PDE family.")

_register(_problem("coupled_product_degenerate", ["x"], {"x": [0., 1.]},
    ["u*v-1", "u_x", "v_x"],
    [_condition("equal_anchor", {"x": 0.}, "u-v")],
    [{"name": "positive_u", "operator": "u", "min": 0.},
     {"name": "positive_v", "operator": "v", "min": 0.}], fields=("u", "v")),
    "乘积耦合零响应退化", "coupled_product_degeneracy",
    difficulty="At u=v=0, perturbing either field alone cannot change the product residual; a coupled direction is required.",
    notes="A coupled algebraic/derivative system, not an extra difficult PDE family. The only condition ties the fields without supplying either value; declared nonnegative branches select u=v=1.")


def list_challenges():
    """Return JSON-compatible research metadata, separate from training inputs."""
    return copy.deepcopy(list(_INFO.values()))


def get_challenge(case_id):
    try:
        return copy.deepcopy(_INFO[case_id])
    except KeyError:
        raise KeyError(f"Unknown V4 challenge: {case_id}") from None


def make_problem(case_id):
    """Physical input only, with no reference/expected-outcome/oracle fields."""
    get_challenge(case_id)
    return copy.deepcopy(_INPUTS[case_id])


def _points(problem, count, seed, where=None):
    unit = qmc.Sobol(len(problem["variables"]), scramble=True, seed=int(seed)).random_base2(
        int(math.ceil(math.log2(count))))[:count]
    bounds = np.array([problem["domain"][v] for v in problem["variables"]])
    points = bounds[:, 0] + unit*(bounds[:, 1]-bounds[:, 0])
    for variable, value in (where or {}).items():
        points[:, problem["variables"].index(variable)] = value
    return points


def _names(problem):
    expressions = problem["equations"] + [c["operator"] for c in problem["conditions"]]
    expressions += [b["operator"] for b in problem["branches"]]
    names = set(problem["fields"])
    for expression in expressions:
        for node in ast.walk(ast.parse(expression, mode="eval")):
            if isinstance(node, ast.Name):
                for field in problem["fields"]:
                    if re.fullmatch(re.escape(field)+r"_[xyzt]{1,6}", node.id):
                        names.add(node.id)
    return sorted(names)


def _expression(source, points, problem, jets):
    """Independent numeric AST interpreter; never Python eval/exec."""
    functions = {"sin": np.sin, "cos": np.cos, "tanh": np.tanh, "exp": np.exp,
                 "log": np.log, "sqrt": np.sqrt, "abs": np.abs}
    env = {name: points[:, i] for i, name in enumerate(problem["variables"])}
    env.update(pi=math.pi, e=math.e)
    env.update(jets)
    def visit(node):
        if isinstance(node, ast.Constant) and type(node.value) in (int, float):
            return node.value
        if isinstance(node, ast.Name) and node.id in env:
            return env[node.id]
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
            return visit(node.operand) * (-1 if isinstance(node.op, ast.USub) else 1)
        if isinstance(node, ast.BinOp):
            left, right = visit(node.left), visit(node.right)
            if isinstance(node.op, ast.Add): return left+right
            if isinstance(node.op, ast.Sub): return left-right
            if isinstance(node.op, ast.Mult): return left*right
            if isinstance(node.op, ast.Div): return left/right
            if isinstance(node.op, ast.Pow): return left**right
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in functions and len(node.args)==1 and not node.keywords:
            return functions[node.func.id](visit(node.args[0]))
        raise ValueError("Unsupported audit expression syntax or unknown symbol")
    with np.errstate(over="raise", divide="raise", invalid="raise"):
        result = np.asarray(visit(ast.parse(source, mode="eval").body)) + np.zeros(len(points))
    if result.shape != (len(points),) or not np.isfinite(result).all():
        raise FloatingPointError("Invalid audit expression result")
    return result


def _request(predictor, points, names, fields):
    values = predictor(points, derivatives=tuple(name for name in names if name not in fields))
    result = {}
    for name in names:
        value = np.asarray(values[name], dtype=float).reshape(-1)
        if len(value) != len(points) or not np.isfinite(value).all():
            raise FloatingPointError(f"Non-finite/missing-shape predictor jet: {name}")
        result[name] = value
    return result


def _reference_values(case_id, points):
    """Private audit reference; never returned in make_problem/list metadata."""
    x = points[:, 0]
    if case_id == "monge_original":
        y = points[:, 1]
        return {"u": .5*(x*x+y*y)+.05*x*x*y*y}
    if case_id in ("eikonal_positive", "eikonal_negative"):
        return {"u": x if case_id.endswith("positive") else -x}
    if case_id.startswith("degenerate_curvature_power"):
        return {"u": x*x-x}
    if case_id == "helmholtz_near_resonance":
        return {"u": np.sin(2*math.pi*x)/(math.pi**2*(3-1e-6))}
    if case_id == "heat_high_frequency":
        t = points[:, 1]
        return {"u": sum(amplitude*np.sin(mode*math.pi*x)*np.exp(-.02*(mode*math.pi)**2*t)
                          for mode, amplitude in ((17, 1.), (43, .35)))}
    if case_id == "convection_boundary_layer":
        return {"u": (np.exp((x-1)/.001)-math.exp(-1000)) / (-math.expm1(-1000))}
    if case_id == "beam_fourth_order": return {"u": x*x*(1-x)**2}
    if case_id == "sixth_order_clamped": return {"u": x**3*(1-x)**3}
    if case_id == "coupled_oscillator": return {"u": np.sin(x), "v": np.cos(x)}
    if case_id == "coupled_product_degenerate": return {"u": np.ones(len(x)), "v": np.ones(len(x))}
    return None


def _witness(case_id):
    if case_id == "helmholtz_resonance_incompatible":
        return {"type": "Fredholm compatibility", "value": .5,
                "statement": "Integrating (-u_xx-pi^2*u)=sin(pi*x) against sin(pi*x) gives 0=1/2 for exact zero Dirichlet data.",
                "residual_l2_lower_bound_if_conditions_exact": 1/math.sqrt(2),
                "assumptions": "Classical/H2 solution on [0,1], exact endpoint data."}
    if case_id == "poisson_neumann_incompatible":
        return {"type": "flux-source compatibility", "value": 1.,
                "statement": "Integral of -u_xx equals minus the two outward fluxes (zero), but integral of the source is one.",
                "residual_l2_lower_bound_if_conditions_exact": 1.,
                "assumptions": "Classical/H2 solution on [0,1], exact outward Neumann data."}
    if case_id == "transport_overconstrained":
        return {"type": "fundamental theorem compatibility", "value": 1.,
                "statement": "u(1)-u(0)=integral(u_x)=1 conflicts with equal zero endpoints.",
                "residual_l2_lower_bound_if_conditions_exact": 1.,
                "assumptions": "Absolutely continuous solution with exact endpoint values."}
    if case_id == "eikonal_ambiguous":
        return {"type": "explicit multiplicity", "statement": "Both C1 functions u=x and u=-x satisfy the same input; no slope branch was supplied."}
    if case_id == "poisson_neumann_ambiguous":
        return {"type": "constant nullspace", "statement": "Every u=C satisfies the input; no value or mean condition removes the nullspace."}
    return None


def _reference_metrics(jets, reference, fields):
    if reference is None: return None
    truth = np.concatenate([reference[field] for field in fields])
    values = np.concatenate([jets[field] for field in fields])
    error = values-truth
    return {"relative_l2": float(np.linalg.norm(error)/np.linalg.norm(truth)),
            "rmse": float(np.sqrt(np.mean(error**2))), "max_abs_error": float(np.max(np.abs(error))),
            "normalized_max_abs_error": float(np.max(np.abs(error))/max(1., float(np.max(np.abs(truth)))))}


def audit_candidate(case_id, predictor=None, reported_status="solution", count=1024, seed=84105):
    """Audit a fixed candidate or a reported nonunique/incompatible outcome.

    No optimizer is called. Unique cases need physics, conditions, branch AND
    independent reference checks. ``undetermined`` avoids false success but is
    not counted as solving the case. An incompatible label is accepted here
    only for a case with an explicit analytic witness, never from stagnation.
    """
    if type(count) is not int or count < 32:
        raise ValueError("Audit count must be an integer >=32.")
    aliases = {"success": "solution", "infeasible": "incompatible", "non_unique": "nonunique",
               "not_converged": "undetermined"}
    reported_status = aliases.get(reported_status, reported_status)
    if reported_status not in ("solution", "nonunique", "incompatible", "undetermined", "failed"):
        raise ValueError("Unknown reported outcome status.")
    info, problem = get_challenge(case_id), make_problem(case_id)
    result = {"id": case_id, "expected_outcome": info["expected_outcome"],
              "reported_status": reported_status, "accepted_solution": False, "successful_handling": False,
              "physics_consistent": None, "count": count, "seed": seed,
              "witness": _witness(case_id), "audit_error": None,
              "interpretation": "Finite independent-point diagnostics, not a general error or existence certificate."}
    physics_pass = False
    reference_pass = False
    if predictor is not None:
        try:
            names = _names(problem)
            points = _points(problem, count, seed)
            jets = _request(predictor, points, names, problem["fields"])
            equations = [_expression(expr, points, problem, jets) for expr in problem["equations"]]
            equation_metrics = [{"rmse": float(np.sqrt(np.mean(r*r))), "max_abs": float(np.max(np.abs(r)))} for r in equations]
            result["equations"] = equation_metrics
            condition_metrics = {}
            for index, condition in enumerate(problem["conditions"]):
                coordinates = _points(problem, min(count, 256), seed+100+index, condition["where"])
                condition_jets = _request(predictor, coordinates, names, problem["fields"])
                error = (_expression(condition["operator"], coordinates, problem, condition_jets)
                         - _expression(condition["target"], coordinates, problem, {}))
                condition_metrics[condition["name"]] = {"rmse": float(np.sqrt(np.mean(error*error))),
                                                         "max_abs": float(np.max(np.abs(error)))}
            result["conditions"] = condition_metrics
            branches = {}
            for branch in problem["branches"]:
                value = _expression(branch["operator"], points, problem, jets)
                violation = np.maximum(branch.get("min", -np.inf)-value, 0.)
                violation = np.maximum(violation, value-branch.get("max", np.inf))
                branches[branch["name"]] = {"minimum": float(np.min(value)), "maximum": float(np.max(value)),
                                             "max_violation": float(np.max(violation))}
            result["branches"] = branches
            if case_id == "monge_original":
                a, d, b = jets["u_xx"], jets["u_yy"], jets["u_xy"]
                result["minimum_hessian_eigenvalue"] = float(np.min(.5*(a+d-np.sqrt((a-d)**2+4*b*b))))
            physics_pass = (all(m["rmse"]<=1e-4 and m["max_abs"]<=1e-3 for m in equation_metrics)
                            and all(m["rmse"]<=1e-5 and m["max_abs"]<=1e-4 for m in condition_metrics.values())
                            and all(m["max_violation"]<=1e-6 for m in branches.values()))
            metrics = _reference_metrics(jets, _reference_values(case_id, points), problem["fields"])
            result["reference_errors"] = metrics
            reference_pass = metrics is not None and metrics["relative_l2"]<=1e-3 and metrics["normalized_max_abs_error"]<=1e-2
            if case_id in ("convection_boundary_layer", "heat_high_frequency"):
                focus = _points(problem, max(256, count//4), seed+1000)
                if case_id == "convection_boundary_layer": focus[:, 0] = 1-.01*(1-focus[:, 0])
                else: focus[:, 1] *= .1
                focus_jets = _request(predictor, focus, names, problem["fields"])
                focus_metrics = _reference_metrics(focus_jets, _reference_values(case_id, focus), problem["fields"])
                focus_residual = [_expression(expr, focus, problem, focus_jets) for expr in problem["equations"]]
                focus_max = max(float(np.max(np.abs(r))) for r in focus_residual)
                result["focused_audit"] = {"region": "x in [.99,1]" if case_id=="convection_boundary_layer" else "t in [0,.002]",
                                             "count": len(focus), "reference_errors": focus_metrics, "residual_max": focus_max}
                reference_pass = reference_pass and focus_metrics["relative_l2"]<=1e-3 and focus_metrics["normalized_max_abs_error"]<=1e-2
                physics_pass = physics_pass and focus_max<=1e-3
            result["physics_consistent"] = bool(physics_pass)
        except Exception as exc:
            result.update(audit_error=f"{type(exc).__name__}: {exc}", physics_consistent=False)
    expected = info["expected_outcome"]
    if expected == "unique":
        result["accepted_solution"] = bool(reported_status=="solution" and physics_pass and reference_pass)
        result["successful_handling"] = result["accepted_solution"]
    elif expected == "nonunique":
        result["successful_handling"] = bool(reported_status=="nonunique" and (predictor is None or physics_pass))
    elif expected == "incompatible":
        result["successful_handling"] = reported_status=="incompatible" and result["witness"] is not None
    result["correctly_avoided_false_success"] = bool(reported_status!="solution" or result["accepted_solution"])
    return result
