function [EER]=TESTCompact(m,n,a,b,alpha,T,s)   %%%%%%%%%%%  [EER]=TESTCompact(10,10,1,2,2,1,0.1) dui
h1=(b-a)/m;  %%%  �ռ䲽��
h2=s/n;      %%%  ʱ�䲽��
j=n;
x=a:h1:b;
% j=(s-mod(s,h2))/h2;
 J=floor(T/h2);  %%% ��[0,T]��ȡ��ʱ�䲽���������������������T��
t=-s:h2:J*h2;
r=alpha*h2/(h1^2);  %%% ������
%%%%  ����ϵ������
z=ones(1,m-1)*(5/6+r);
e1=ones(1,m-2)*(1/12-r/2);
%%%%  ��ֵ
for k=1:j+1
    for i=1:m+1
          u(i,k)=(x(i)^4/8-x(i))*(t(k)^3-2*t(k)-1);
    end
end
%%%%  �߽�ֵ
for k=j+2:J+n+1
    u(1,k)=-(7/8)*(t(k)^3-2*t(k)-1);
    u(m+1,k)=0;
end
%%%%%%
for k=j+1:J+n+1
    for i=1:m+1
         G(k-j,i)=-alpha*(3/2)*x(i)^2*(t(k)^3-2*t(k)-1)+(x(i)^4/8-x(i))*(3*t(k)^2-2)-(x(i)^4/8-x(i))^2*(t(k)^3-2*t(k)-1)*((t(k)-s)^3-2*(t(k)-s)-1);
    end
end
for k=j+1:J+n
    for i=1:m+1
        GG(k-j,i)=(G(k+1-j,i)+G(k-j,i))/2;
    end
end
%%%%  ѭ����
%%%%%%%%%%%%%%%  ������u(x,t)��u(x,t-s)��Compact��ʽ  f(u(x,t-s))=u(x,t)*u(x,t-s)
for k=j+1:J+n
    for i=2:m-2
        F(i,k-j)=(1/12+r/2)*(u(i,k)+u(i+2,k))+(5/6-r)*u(i+1,k)+(h2/48)*((3*u(i,k)-u(i,k-1))*(u(i,k+1-j)+u(i,k-j))+10*((3*u(i+1,k)-u(i+1,k-1))*(u(i+1,k+1-j)+u(i+1,k-j)))+(3*u(i+2,k)-u(i+2,k-1))*(u(i+2,k+1-j)+u(i+2,k-j)))+(h2/12)*(GG(k-j,i)+10*GG(k-j,i+1)+GG(k-j,i+2));
        F(1,k-j)=(1/12+r/2)*(u(1,k)+u(3,k))+(5/6-r)*u(2,k)-(1/12-r/2)*u(1,k+1)+(h2/48)*((3*u(1,k)-u(1,k-1))*(u(1,k+1-j)+u(1,k-j))+10*((3*u(2,k)-u(2,k-1))*(u(2,k+1-j)+u(2,k-j)))+(3*u(3,k)-u(3,k-1))*(u(3,k+1-j)+u(3,k-j)))+(h2/12)*(GG(k-j,1)+10*GG(k-j,2)+GG(k-j,3));
        F(m-1,k-j)=(1/12+r/2)*(u(m-1,k)+u(m+1,k))+(5/6-r)*u(m,k)-(1/12-r/2)*u(m+1,k+1)+(h2/48)*((3*u(m-1,k)-u(m-1,k-1))*(u(m-1,k+1-j)+u(m-1,k-j))+10*(3*u(m,k)-u(m,k-1))*(u(m,k+1-j)+u(m,k-j))+(3*u(m+1,k)-u(m+1,k-1))*(u(m+1,k+1-j)+u(m+1,k-j)))+(h2/12)*(GG(k-j,m-1)+10*GG(k-j,m)+GG(k-j,m+1));
    end
    Y=XINsanduijiaoxian(z,e1,e1,F(:,k-j));
    for i=1:m-1
       u(i+1,k+1)=Y(i);%%%%%%%  ��ֵ��
    end
end
%%%%%%%%%%%  ��ȷ�� u(x,t)=(x^4-5x)*(t^3+6)
for k=1:J+n+1
    for i=1:m+1
        U(i,k)=(x(i)^4/8-x(i))*(t(k)^3-2*t(k)-1);
    end
end
EER=max(max(abs(U-u)));
eer=abs(U-u);
%%%%%%%%%%%%  ������ u(x,t-s)��Compact��ʽ  f(u(x,t-s))=[u(x,t-s)]^2