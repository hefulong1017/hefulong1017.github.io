function [x,t,eer]=XCZCN(m,n,a,b,alpha,T,s)   %%%%%%%%%%%  [EER]=XCZCN(10,1,1,2,2,1,0.1) 
h1=(b-a)/m;  %%%  �ռ䲽��
h2=s/n;      %%%  ʱ�䲽��
j=n;
x=a:h1:b;
% j=(s-mod(s,h2))/h2;
 J=floor(T/h2);  %%% ��[0,T]��ȡ��ʱ�䲽���������������������T��
t=-s:h2:J*h2;
r=(alpha*h2)/(2*h1^2);  %%% ������
%%%%  ����ϵ������
z=ones(1,m-1)*(1+2*r);
e1=ones(1,m-2)*(-r);
%%%%  ��ֵ
for k=1:j+1
    for i=1:m+1
          u(i,k)=(x(i)^4/8-x(i))*(t(k)^3-2*t(k)-1);
    end
end
%%%%  �߽�ֵ
for k=j+2:J+n+1
    u(1,k)=-(7/8)*(t(k)^3-2*t(k)-1);
    u(m+1,k)=0;
end
%%%%%%
for k=j+1:J+n+1
    for i=1:m-1
% %%%%%%%%%%%%  ������ u(x,t-s)��C-N��ʽ  f(u(x,t-s))=[u(x,t-s)]^2
%         G(k-j,i)=-alpha*(3/2)*x(i+1)^2*(t(k)^3-2*t(k)-1)+(x(i+1)^4/8-x(i+1))*(3*t(k)^2-2)-(x(i+1)^4/8-x(i+1))^2*((t(k)-s)^3-2*(t(k)-s)-1)^2;
%%%%%%%%%  ������ u(x,t)��u(x,t-s)��C-N��ʽ  f(u(x,t-s))=u(x,t)*u(x,t-s)
        G(k-j,i)=-alpha*(3/2)*x(i+1)^2*(t(k)^3-2*t(k)-1)+(x(i+1)^4/8-x(i+1))*(3*t(k)^2-2)-(x(i+1)^4/8-x(i+1))^2*(t(k)^3-2*t(k)-1)*((t(k)-s)^3-2*(t(k)-s)-1);
    end
end
for k=j+1:J+n
    for i=1:m-1
        GG(k-j,i)=(G(k-j,i)+G(k+1-j,i))/2;
    end
end
%%%%  ѭ����
%%%%%%%%%%%%%%%  ������ u(x,t-s)��C-N��ʽ  f(u(x,t-s))=[u(x,t-s)]^2
% for k=j+1:J+n
%     for i=2:m-2
%         F(i,k-j)=r*u(i,k)+(1-2*r)*u(i+1,k)+r*u(i+2,k)+(h2/4)*(u(i+1,k+1-j)+u(i+1,k-j))^2+h2*GG(k-j,i);
%         F(1,k-j)=r*u(1,k)+(1-2*r)*u(2,k)+r*u(3,k)+r*u(1,k+1)+(h2/4)*(u(2,k+1-j)+u(2,k-j))^2+h2*GG(k-j,1);
%         F(m-1,k-j)=r*u(m-1,k)+(1-2*r)*u(m,k)+r*u(m+1,k)+r*u(m+1,k+1)+(h2/4)*(u(m,k+1-j)+u(m,k-j))^2+h2*GG(k-j,m-1);
%     end
%     Y=XINsanduijiaoxian(z,e1,e1,F(:,k-j));
%     for i=1:m-1
%        u(i+1,k+1)=Y(i);%%%%%%%  ��ֵ��
%     end
% end
%%%%%%%%%%%%  ������ u(x,t)�� u(x,t-s)��C-N��ʽ f(u(x,t),u(x,t-s))=u(x,t)*u(x,t-s)
for k=j+1:J+n
    for i=2:m-2
        F(i,k-j)=r*u(i,k)+(1-2*r)*u(i+1,k)+r*u(i+2,k)+(h2/4)*(3*u(i+1,k)-u(i+1,k-1))*(u(i+1,k+1-j)+u(i+1,k-j))+h2*GG(k-j,i);
        F(1,k-j)=r*u(1,k)+(1-2*r)*u(2,k)+r*u(3,k)+r*u(1,k+1)+(h2/4)*(3*u(2,k)-u(2,k-1))*(u(2,k+1-j)+u(2,k-j))+h2*GG(k-j,1);
        F(m-1,k-j)=r*u(m-1,k)+(1-2*r)*u(m,k)+r*u(m+1,k)+r*u(m+1,k+1)+(h2/4)*(3*u(m,k)-u(m,k-1))*(u(m,k+1-j)+u(m,k-j))+h2*GG(k-j,m-1);
    end
    Y=XINsanduijiaoxian(z,e1,e1,F(:,k-j));
    for i=1:m-1
       u(i+1,k+1)=Y(i);%%%%%%%  ��ֵ��
    end
end
%%%%%%%%%%%  ��ȷ�� u(x,t)=(x^4-5x)*(t^3+6)
for k=1:J+n+1
    for i=1:m+1
        U(i,k)=(x(i)^4/8-x(i))*(t(k)^3-2*t(k)-1);
    end
end
EER=max(max(abs(U-u)));
eer=abs(U-u);